import React, { useCallback } from "react"
import CloseIcon from "../../assets/icon/close_icon"

const NotifHeader = ({navigate, show, setShow, location, isFiat}) => {
    const handleToAccount = useCallback(() =>  navigate(`/history-txn/pending#${isFiat ? 'fiat' : 'crypto'}`), [navigate])
    // const isOnActivity = location.pathname === '/setting/txn-activity-all' 
    const isOnPage = location.pathname.includes('/history-txn')
    return (
      <div className={`w-full ${(!show || isOnPage) ? "hidden" : 'flex'} bg-kuning_notif py-3 fixed items-center justify-center md:top-20 top-16`}>
        <p className="text-center font-quicksand font-semibold text-hitam_2">Kamu memiliki transaksi tertunda. Untuk menyelesaikan transaksi, silahkan pindah ke halaman Sejarah Transaksi, atau <a onClick={handleToAccount} className="cursor-pointer font-bold text-hijau_hutan">Klik Disini</a></p>
        <div className="md:ml-16 ml-2 md:mr-0 mr-4 cursor-pointer" onClick={() => setShow(false)}>
        <CloseIcon size={4} color="#222222"/>
        </div>
      </div>
    )
  }

  export default NotifHeader