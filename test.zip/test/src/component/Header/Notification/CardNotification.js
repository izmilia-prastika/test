import ButtonText from '../../Text/ButtonText'
import { SMALL_THUMBNAIL_IMAGE_TYPE } from '../../../utils/constants/renderImgTypes'
import formatDistance from 'date-fns/formatDistance';
import MailOpen from '../../../assets/icon/mail_open_icon'
import MailClosed from '../../../assets/icon/mail_closed_icon'
import { NOTIFICATION_BID_AUCTION, NOTIFICATION_BID_AUCTION_EXPIRED, NOTIFICATION_BUY, NOTIFICATION_MAKE_OFFER } from '../../../utils/constants/notificationTypes'
import { useState } from 'react';
import { UserImage } from '../../../assets';
const CardNotification = ({
    accountByBuyerId, 
    isRead, 
    type, 
    createdAt,
    handleCardClick, 
    id, 
    handleClickMark, 
    ref,
    isLast,
    assetByAssetId,
  }) => {
      // console.log("TES",isLast)
      const timeDistance = formatDistance(new Date(), new Date(createdAt))
      const [isHover, setIsHover] = useState(false)
      let name
      let dateTitle
      let distance
      let typeTitle
      let url
      //Get Buyer Addr or Name
      if(accountByBuyerId?.userName){
        name = accountByBuyerId?.userName
      } else {
        name = accountByBuyerId?.address.substr(0,5) + "..." + accountByBuyerId?.address.substr(accountByBuyerId?.address?.length - 4)
      }
  
      //Set title notif and url
      switch (type) {
        case NOTIFICATION_BUY:
          typeTitle = `${name} membeli aset Anda`
          url = '/profile-page#sold'
          break;
        case NOTIFICATION_MAKE_OFFER:
          typeTitle = `${name} menawar aset Anda`
          url = '/profile-page#incoming'
          break;
        case NOTIFICATION_BID_AUCTION:
          typeTitle = `${name} menawar lelang aset Anda`
          url = '/profile-page#auction'
          break;
        case NOTIFICATION_BID_AUCTION_EXPIRED:
          typeTitle = `Lelang aset  kadaluarsa`
          url = '/profile-page#auction'
          break;
        default:
          break;
      }
      
      //Set caption
      if(timeDistance.includes('less than a minute')){
        dateTitle = 'Kurang dari semenit yang lalu'
        distance = ''
      } else if(timeDistance.includes('minute')){
        dateTitle = 'menit yang lalu'
        distance = timeDistance.substring(0,2)
      } else if(timeDistance.includes('hour')){
        dateTitle = 'jam yang lalu'
        distance = timeDistance.substring(8,5)
      } else if(timeDistance.includes('day')){
        dateTitle = 'hari yang lalu'
        distance = timeDistance.substring(0,2)
      } else if(timeDistance.includes('month')){
        dateTitle = 'bulan yang lalu'
        distance = timeDistance.substring(6,2)
      } 
      // console.log("Rendered Card", assetByAssetId?.thumbnailUrl)
      return(
          <div ref={ref} onClick={() => handleCardClick(id, url, isRead)}  className={`w-full ${isRead ? isHover ? 'bg-gray-50' :'bg-white' : isHover ? 'bg-gray-50' :'bg-hijau_notif'} px-4 ${!isLast && 'border-b'} border-gray-200 py-4 flex items-center justify-between group`} onMouseEnter={()=>setIsHover(true)} onMouseLeave={()=>setIsHover(false)}>
            <div className='flex items-center'>
              <div className='rounded-full overflow-hidden'>
                  <img src={assetByAssetId?.thumbnailUrl ? assetByAssetId?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} alt="" className='h-10 w-10 rounded-full overflow-hidden'/>
              </div>
              <div className='flex flex-col ml-3'>
                  <p className='font-quicksand font-semibold text-sm text-hitam_2 mb-1'>{typeTitle}</p>
                  <div className='flex'>
                      <p className='font-quicksand font-regular text-xs text-gray-700'>{distance} {dateTitle}</p>
                      {(isHover && !isRead) && <ButtonText 
                                      classstyle='font-quicksand font-regular text-xs  cursor-pointer' 
                                      onClick={(e)=>handleClickMark(id, e)} tx="Tandai Sudah dibaca"
                                      color='text-gray-700 ml-2 group-hover:text-hijau_hutan'
                                    />}
                  </div>
              </div>
            </div>
              <div className='flex flex-col items-end gap-x-3'>
                {isRead ? <MailOpen /> : <MailClosed />}
              </div>
          </div>
      )
  }

export default CardNotification