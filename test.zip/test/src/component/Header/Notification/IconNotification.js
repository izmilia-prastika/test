import {useContext, useEffect, useRef, useState} from 'react'
import { NotifIcon, NotifIconExist} from "../../../assets"
import authContext from '../../../context/Auth/authContext'
import notificationContext from '../../../context/AssetUtilityNotification/assetUtilityNotificationContext'
import EmptyStateSection from '../../Panel/EmptyState'
import { useLocation, useNavigate } from 'react-router-dom'
import CardNotification from './CardNotification'
import NotificationMobile from './NotificationMobile'
import ButtonText from '../../Text/ButtonText'


const NotificationBar = ({
  show, 
  setShow, 
  dataNotif, 
  handleCardClick, 
  handleClickMark, 
  setGetAgain, 
  handleClickReadAll,
  unRead
}) => {
    const length = dataNotif?.length
    const isEmpty = length === 0
    const innerRef = useRef()
    const handleScroll = () => {
      if (innerRef?.current) {
          const { scrollTop, scrollHeight, clientHeight } = innerRef?.current;
          if (Math.ceil(scrollTop) + Math.ceil(clientHeight) >= scrollHeight) {
              setGetAgain(true);
              // console.log('WADU')
          } 
      }
  };
  // console.log("TES", dataNotif)
    return (
      <div onScroll={handleScroll} ref={innerRef} className={`w-bar_notification h-96 overflow-y-auto absolute right-4 py-4 bg-white shadow-md rounded-lg ${show ? 'block' : 'hidden'}`}>
        <div className='flex justify-between items-center px-4 mb-2'>
          <p className="font-quicksand font-bold text-lg">Notifikasi</p>
          {unRead && <ButtonText 
            tx='Tandai semua sudah dibaca' 
            classstyle='font-quicksand font-regular text-xs cursor-pointer' 
            color="text-hijau_hutan"
            onClick={handleClickReadAll}
            />}
        </div>
        {!isEmpty ? dataNotif?.map(({accountByAccountId, accountByBuyerId, assetByAssetId, isRead, type, createdAt, id}, idx) => 
            <CardNotification
                // ref={ref}
                key={idx}
                id={id}
                accountByAccountId={accountByAccountId}
                accountByBuyerId={accountByBuyerId}
                isRead={isRead}
                type={type}
                createdAt={createdAt}
                handleCardClick={handleCardClick}
                handleClickMark={handleClickMark}
                isLast={idx === (length - 1)}
                assetByAssetId={assetByAssetId}
            /> ) : <EmptyStateSection text={"Belum ada notifikasi untuk kamu"} className="w-96"/>}
      </div>
    )
  }

  const IconNotification = ({show, handleClick, setShow, isMobile = false}) => {
    const NotifContext = useContext(notificationContext)
    const AuthContext = useContext(authContext)
    const [dataNotif, setDataNotif] = useState([])
    const [loading, setLoading] = useState(false)
    const [isThereUnread, setUnread] = useState(false)
    const [getAgain, setGetAgain] = useState(false)
    const location = useLocation()
    const ref = useRef()
    const navigate = useNavigate()
    // const cekIsRead = dataNotif?.filter((el)=> el.isRead === false)
    //   if(cekIsRead?.length > 0) {
    //     isThereUnread = true
    //   } else {
    //     isThereUnread = false
    //   }

    const setFalse = () => {
      setShow(false)
    }

    const fetchLoad = async () => {
      const fetchAgain = await NotifContext.getAll({
        first: 5,
        after: NotifContext?.pageInfo?.endCursor,
        accountId: AuthContext?.auth?.user?.id,
      })
      setDataNotif(dataNotif.concat(fetchAgain?.nodes))
    }
  
    const handleClickMark = async (id, event) => {
      setLoading(true)
      // console.log("TES", id, event)
      event.stopPropagation();
      try{
        // console.log('TEs', id)
        await NotifContext.update(id, {isRead: true})
        setLoading(false)
      } catch(err){
        setLoading(false)
      }
    }

    const handleClickReadAll = async () => {
      setLoading(true)
      try{
        // console.log('TEs', id)
        await NotifContext.updateBatchToRead(AuthContext?.auth?.user?.id)
        setLoading(false)
      } catch(err){
        setLoading(false)
      }
    }
  
    const handleClickCard = async (id, url, isRead) => {
        // console.log('TES', id, url)
        if(!isRead){
          await NotifContext.update(id, {isRead: true})
        }
        if(url){
          navigate(url)
          setShow(false)
        }
    }

      useEffect(() => {
        const handleClickOutside = (event) => {
          if (!ref?.current?.contains(event.target)) {
              setFalse()
              // event.stopPropagation()
          }
        };
        document.addEventListener("mousedown", handleClickOutside);
      // eslint-disable-next-line react-hooks/exhaustive-deps
      }, [ref]);

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(() => {
        // console.log(NotifContext?.pageInfo?.endCursor, "TES")
        if(getAgain && NotifContext?.pageInfo?.endCursor !== null){
          fetchLoad()
          setGetAgain(false)
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [getAgain])

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(async () => {
    if(!loading){
    if(AuthContext?.auth?.user?.id !== undefined){
      const fetchNotif = await NotifContext.getAll({
        first: isMobile ? 10 : 5,
        after: null,
        accountId: AuthContext?.auth?.user?.id,
      })
      const fetchUnread = await NotifContext.getUnread(AuthContext?.auth?.user?.id)
      if(fetchUnread?.total > 0){
        setUnread(true)
      }else{
        setUnread(false)
      }
      setDataNotif(fetchNotif?.nodes)
    }}
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show, location.pathname, loading])
    
    return (
      <div ref={ref} className="inline-block relative">
        <img src={isThereUnread ? NotifIconExist : NotifIcon} alt="" className="ml-2 h-8 w-8 cursor-pointer" onClick={handleClick}/>
        {!isMobile ? <NotificationBar 
            show={show} 
            dataNotif={dataNotif} 
            handleCardClick={handleClickCard} 
            setShow={setShow}
            handleClickMark={handleClickMark}
            setGetAgain={setGetAgain}
            handleClickReadAll={handleClickReadAll}
            unRead={isThereUnread}
            // innerRef={innerRef}
            /> : <NotificationMobile 
            toggleMenu={show}
            dataNotif={dataNotif} 
            handleCardClick={handleClickCard} 
            setShow={setShow}
            handleClickMark={handleClickMark}
            setGetAgain={setGetAgain}
            handleClickReadAll={handleClickReadAll}
            unRead={isThereUnread}
            />}
      </div>
    )
  }

export default IconNotification