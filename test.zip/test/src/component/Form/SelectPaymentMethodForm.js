import React from "react";
import InputRadioWithImage from "../Input/InputRadioWithImage";

const SelectPaymentMethodForm = ({ title, formParam, totalPrice, customDiv, row="md:grid-cols-2", ...props }) => {
    return (
        <div className={`flex flex-col items-start w-full border-b-2 ${customDiv} border-gray-200 md:px-10 px-0`}>
            <p className="md:text-base text-sm text-hitam font-quicksand md:font-bold font-medium mb-5">{title}</p>
            <div className={`grid ${row} grid-cols-1 md:gap-x-10 gap-6 md:mb-8 mb-4 w-full`}>
                {/* {formParam.map((prop,key) => */}
                {formParam.filter(param => totalPrice < param.maximumLimit).map((prop, key) =>
                    <InputRadioWithImage key={key} {...prop} checked={prop?.value === props?.methodPayment} />)}
            </div>
        </div>
    )
}

export default SelectPaymentMethodForm