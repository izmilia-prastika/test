import React, { useContext, useEffect, useState } from "react";
import WireframeIcon from "../../assets/icon/wireframe_icon";
import RoundedButton from "../Button/RoundedButton";
import Card from "../Card/Card";
import Input from "../Input/Input";
import InputFileWithLabel from "../Input/InputFileWithLabel";
import InputRoundedFileWithLabel from "../Input/InputRoundedFileWithLabel";
import InputWithLabel from "../Input/InputWithLabel";
import ButtonText from "../Text/ButtonText";
import LabelText from "../Text/LabelText";
// import { create as ipfsHttpClient } from 'ipfs-http-client'
import accountContext from "../../context/Account/accountContext";
import authContext from "../../context/Auth/authContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import assetContext from "../../context/Asset/assetContext";
import { renderFileUploadPath } from "../../utils/helper";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import { ACCOUNTS_FOLDER } from "../../utils/constants/folderTypes";
import GrayInstagramIcon from "../../assets/icon/gray_instagram_icon";
import GrayFacebookIcon from "../../assets/icon/gray_facebook_icon";
import GrayTwitterIcon from "../../assets/icon/gray_twitter_icon";
import { UserImage } from "../../assets";


const MobileView = ({ formInput, 
    updateFormInput, 
    onChange, 
    fileUrl, 
    loadingFile, 
    onChangeBanner, 
    fileBannerUrl, 
    loadingFileBanner, 
    onSubmit,
    loading}) => {
    return (
        <div className="grid grid-cols-1 px-4 pb-6">
            <InputWithLabel
                placeholder="Masukan username.."
                value={formInput?.userName}
                onChange={e => updateFormInput({ ...formInput, userName: e.target.value })}
                tx="Username" className="mb-6" />
            <InputWithLabel
                value={formInput?.email}
                placeholder="Masukan email.."
                onChange={e => updateFormInput({ ...formInput, email: e.target.value })}
                tx="Email" className="mb-10" />
            <InputRoundedFileWithLabel itemsAlign="start" tx="Gambar Profil"
                labelConstraint="PNG, GIF, JPEG, WEBP. Max 2MB"
                accept="image/png, image/gif, image/jpeg, image/webp"
                onChange={onChange}
                value={fileUrl}
                loading={loadingFile}
                right={false}
            />
            <InputFileWithLabel
                onChange={onChangeBanner}
                accept="image/png, image/gif, image/jpeg, image/webp"
                value={fileBannerUrl}
                loading={loadingFileBanner}
                height={144}
                labelConstraint="PNG, GIF, JPEG, WEBP. Max 2MB"
                className="font-quicksand text-lg mt-8"
                text="Unggah banner"
                textSublabel="Banner akan tampil di halaman koleksi-mu (Ukuran 1400x400)"
            />
            <LabelText text="Website and Social Media" classstyle="mb-5 mt-8" />
            <div className="gap-y-4 grid grid-flow-row">
                <Input
                    value={formInput?.socialMediaUrl?.web}
                    onChange={e => updateFormInput({
                        ...formInput, socialMediaUrl: {
                            ...formInput?.socialMediaUrl,
                            web: e.target.value
                        }
                    })}
                    appendleft={
                        <WireframeIcon className="self-center cursor-pointer " />
                    }
                    customPositionIcon = "top-4"
                />
                <Input
                    value={formInput?.socialMediaUrl?.instagram}
                    onChange={e => updateFormInput({
                        ...formInput, socialMediaUrl: {
                            ...formInput?.socialMediaUrl,
                            instagram: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayInstagramIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    customPositionIcon = "top-4"
                />
                <Input
                    value={formInput?.socialMediaUrl?.facebook}
                    onChange={e => updateFormInput({
                        ...formInput, socialMediaUrl: {
                            ...formInput?.socialMediaUrl,
                            facebook: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayFacebookIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    customPositionIcon = "top-4"
                />
                <Input
                    value={formInput?.socialMediaUrl?.twitter}
                    onChange={e => updateFormInput({
                        ...formInput, socialMediaUrl: {
                            ...formInput?.socialMediaUrl,
                            twitter: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayTwitterIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    customPositionIcon = "top-4"
                />
            </div>
            <RoundedButton disabled={loading} onClick={onSubmit} color={loading ? "bg-gray-500" : "bg-hijau_hutan"} className="w-full self-end py-4 mt-10">
            {(loading || assetContext.loading) ? <ButtonText tx='loading...' />
                    :
                    <ButtonText tx="Simpan" />
                }
            </RoundedButton>
        </div>
    )
}


const SUPPORTED_FORMAT = ["jpeg", "jpg", "png", "mpeg", "mp4", "gif", "webp"]
const IMAGE_SIZE_LIMIT = 20971520
const IMAGE = "image"
const SettingProfileForm = () => {
    const AccountContext = useContext(accountContext)
    const AuthContext = useContext(authContext)
    const AssetContext = useContext(assetContext)
    const responsive = useContext(ResponsiveContext)
    const navigate = useNavigate()
    const [fileUrl, setFileUrl] = useState(null)
    const [fileBannerUrl, setFileBannerUrl] = useState(null)
    const [isBannerUpdated, setIsBannerUpdate] = useState(false)
    const [isPPUpdated, setIsPPUpdate] = useState(false)
    const [loading, setLoading] = useState(false)
    const [loadingFile, setLoadingFile] = useState(false)
    const [loadingFileBanner, setLoadingFileBanner] = useState(false)

    const [formInput, updateFormInput] = useState({
        userName: '', email: "", socialMediaUrl: {
            instagram: "",
            twitter: "",
            facebook: "",
            web: ""
        }, slug: ''
    })

    useEffect(() => {
        AccountContext?.getAccountById(AuthContext?.auth?.user?.id)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        // const profileUrlFile = AccountContext?.account?.profilePictureUrl && await toDataUrl(AccountContext?.account?.profilePictureUrl + SMALL_THUMBNAIL_IMAGE_TYPE)
        // const bannerUrlFile = AccountContext?.account?.bannerUrl && await toDataUrl(AccountContext?.account?.bannerUrl + MEDIUM_THUMBNAIL_IMAGE_TYPE)
        setFileUrl(AccountContext?.account?.profilePictureUrl ? AccountContext?.account?.profilePictureUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage)
        // await setFileUrl(profileUrlFile)
        setFileBannerUrl(AccountContext?.account?.bannerUrl ? AccountContext?.account?.bannerUrl + SMALL_THUMBNAIL_IMAGE_TYPE : null)
        // await setFileBannerUrl(bannerUrlFile)
        updateFormInput(
            {
                userName: AccountContext?.account?.userName,
                email: AccountContext?.account?.email,
                socialMediaUrl: AccountContext?.account?.socialMediaUrl && JSON.parse(AccountContext?.account?.socialMediaUrl),
            }
        )
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [AccountContext?.account, AccountContext?.accounts])

    async function onChange(e) {
        setLoadingFile(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileUrl(file)
                setLoadingFile(false)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
                setLoadingFile(false)
            }
        } else {
            toast.info("Format file tidak mendukung")
            setLoadingFile(false)
        }
        setIsPPUpdate(true)
    }

    async function onChangeBanner(e) {
        setLoadingFileBanner(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileBannerUrl(file)
                setLoadingFileBanner(false)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
                setLoadingFileBanner(false)
            }
        } else {
            toast.info("Format file tidak mendukung")
            setLoadingFileBanner(false)
        }
        setIsBannerUpdate(true)
    }

    const onSubmit = async () => {
        setLoading(true)
        const { userName, email, socialMediaUrl } = formInput
        let profileImage
        let inputFile = await new FormData()
        if(isPPUpdated){
            // upload LogoURL
            await inputFile.append('file', fileUrl)
            await inputFile.append('path', renderFileUploadPath(ACCOUNTS_FOLDER, AuthContext?.auth?.user?.address))
            profileImage = await AssetContext?.uploadAsset(inputFile)
        }

        // upload BannerURL
        let bannerImage
        if(isBannerUpdated){
            inputFile = await new FormData()
            await inputFile.append('file', fileBannerUrl)
            await inputFile.append('path', renderFileUploadPath(ACCOUNTS_FOLDER, AuthContext?.auth?.user?.address))
            bannerImage = await AssetContext?.uploadAsset(inputFile)
        }

        const accountData = {
            userName,
            // address,
            email,
            bannerUrl: bannerImage?.url,
            // isVerified,
            profilePictureUrl: profileImage?.url,
            socialMediaUrl: JSON.stringify(socialMediaUrl),
            updatedAt: new Date()
        }
        AccountContext.update(AuthContext?.auth?.user?.id, accountData)
        setLoading(false)
        navigate('/profile-page')
    }
    return (
        !responsive ? <Card className={"rounded-lg flex flex-col setting-main-card pl-11 pt-12 pr-20 pb-16"} width={responsive ? "100%" : 1080} height={responsive ? "100%" : 750}>
            <div className="justify-between inline-flex">
                <div className="w-96">
                    <InputWithLabel
                        placeholder="Masukan username.."
                        value={formInput?.userName || ""}
                        onChange={e => updateFormInput({ ...formInput, userName: e.target.value })}
                        tx="Username" className="mb-6" />
                    <InputWithLabel
                        value={formInput?.email || ""}
                        placeholder="Masukan email.."
                        onChange={e => updateFormInput({ ...formInput, email: e.target.value })}
                        tx="Email" className="mb-10" />
                    <LabelText text="Website and Social Media" classstyle="mb-5" />
                    <div className="gap-y-4 grid grid-flow-row">

                        <Input
                            value={formInput?.socialMediaUrl?.web || ""}
                            onChange={e => updateFormInput({
                                ...formInput, socialMediaUrl: {
                                    ...formInput?.socialMediaUrl,
                                    web: e.target.value
                                }
                            })}
                            appendleft={
                                <WireframeIcon className="self-center cursor-pointer " />
                            }
                            customPositionIcon = "top-4"
                        />
                        <Input
                            value={formInput?.socialMediaUrl?.instagram || ""}
                            onChange={e => updateFormInput({
                                ...formInput, socialMediaUrl: {
                                    ...formInput?.socialMediaUrl,
                                    instagram: e.target.value
                                }
                            })}
                            appendleft={
                                <GrayInstagramIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                            }
                            customPositionIcon = "top-4"
                        />
                        <Input
                            value={formInput?.socialMediaUrl?.facebook || ""}
                            onChange={e => updateFormInput({
                                ...formInput, socialMediaUrl: {
                                    ...formInput?.socialMediaUrl,
                                    facebook: e.target.value
                                }
                            })}
                            appendleft={
                                <GrayFacebookIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                            }
                            customPositionIcon = "top-4"
                        />
                        <Input
                            value={formInput?.socialMediaUrl?.twitter || ""}
                            onChange={e => updateFormInput({
                                ...formInput, socialMediaUrl: {
                                    ...formInput?.socialMediaUrl,
                                    twitter: e.target.value
                                }
                            })}
                            appendleft={
                                <GrayTwitterIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                            }
                            customPositionIcon = "top-4"
                        />
                    </div>

                </div>
                <div className="flex-col flex w-full pl-11">
                    <InputRoundedFileWithLabel right itemsAlign="start" tx="Gambar Profil"
                        labelConstraint="PNG, GIF, JPEG, WEBP. Max 2MB"
                        accept="image/png, image/gif, image/jpeg, image/webp"
                        onChange={onChange}
                        value={fileUrl}
                        loading={loadingFile}
                    />
                    <InputFileWithLabel
                        onChange={onChangeBanner}
                        accept="image/png, image/gif, image/jpeg, image/webp"
                        value={fileBannerUrl}
                        loading={loadingFileBanner}
                        height={213}
                        labelConstraint="PNG, GIF, JPEG, WEBP. Max 2MB"
                        className="font-quicksand text-lg mt-8"
                        text="Unggah banner"
                        textSublabel="Banner akan tampil di halaman koleksi-mu (Ukuran 1400x400)"
                    />
                </div>
            </div>
            <RoundedButton disabled={loading} onClick={onSubmit} color={loading ? "bg-gray-500" : "bg-hijau_hutan"} className="w-28 self-end py-4 mt-10">
                {(loading || assetContext.loading) ? <ButtonText tx='loading...' />
                    :
                    <ButtonText tx="Simpan" />
                }
            </RoundedButton>
        </Card> :
            <MobileView
                loading={loading}
                formInput={formInput}
                updateFormInput={updateFormInput}
                onChange={onChange}
                fileUrl={fileUrl}
                loadingFile={loadingFile}
                onChangeBanner={onChangeBanner}
                fileBannerUrl={fileBannerUrl}
                loadingFileBanner={loadingFileBanner}
                onSubmit={onSubmit}
            />
    )
}

export default SettingProfileForm