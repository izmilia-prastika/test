import React, { useContext, useEffect, useState } from 'react'
import RoundedButton from '../Button/RoundedButton'
import InputDropdownWithLabel from '../Input/InputDropdownWithLabel'
import InputFileWithLabel from '../Input/InputFileWithLabel'
import InputWithLabel from '../Input/InputWithLabel'
import ButtonText from '../Text/ButtonText'

import assetContext from '../../context/Asset/assetContext'
import collectionContext from '../../context/Collection/collectionContext'
import categoryContext from '../../context/Category/categoryContext'
import authContext from '../../context/Auth/authContext'
import { useNavigate, useParams } from 'react-router'
import InputRoundedFileWithLabel from '../Input/InputRoundedFileWithLabel'
import Input from '../Input/Input'
import WireframeIcon from '../../assets/icon/wireframe_icon'
import LabelText from '../Text/LabelText'
import classNames from 'classnames'
import { toast } from 'react-toastify'
import { renderFileUploadPath } from '../../utils/helper'
import { COLLECTIONS_FOLDER } from '../../utils/constants/folderTypes'
import GrayTwitterIcon from '../../assets/icon/gray_twitter_icon'
import GrayFacebookIcon from '../../assets/icon/gray_facebook_icon'
import GrayInstagramIcon from '../../assets/icon/gray_instagram_icon'
import { useForm } from 'react-hook-form'
import CollectionValidation from '../../utils/validation/CollectionFormValidation'
import _ from 'lodash'
import { SMALL_THUMBNAIL_IMAGE_TYPE } from '../../utils/constants/renderImgTypes'

const SUPPORTED_FORMAT = ["jpeg", "jpg", "png", "mpeg", "mp4", "gif", "webp"]
const IMAGE_SIZE_LIMIT = 20971520
const IMAGE = "image"

const UpdateCollectionForm = ({ responsive }) => {
    const { control, register, formState: { errors }, handleSubmit, watch, reset } = useForm({
        resolver: CollectionValidation
    })
    const [formInput, updateFormInput] = useState({
        price: '0', name: '', description: '', socialMedia: {
            instagram: "",
            twitter: "",
            facebook: "",
            web: ""
        }, slug: ''
    })
    const [fileUrl, setFileUrl] = useState(null)
    const [fileBannerUrl, setFileBannerUrl] = useState(null)
    const [loading, setLoading] = useState(false)
    const [category, setCategory] = useState(null)
    const [loadingFile, setLoadingFile] = useState(false)
    const [loadingFileBanner, setLoadingFileBanner] = useState(false)


    const CollectionContext = useContext(collectionContext);
    const CategoryContext = useContext(categoryContext);
    const AuthContext = useContext(authContext);
    const AssetContext = useContext(assetContext)
    // const { socket } = SocketContext

    const navigate = useNavigate();
    const params = useParams()

    async function onChange(e) {
        setLoadingFile(true)
        const file = e.target.files[0]
        const format = file.type.split("/")[1]
        const type = file.type.split("/")[0]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileUrl(file)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFile(false)
    }

    async function onChangeBanner(e) {
        setLoadingFileBanner(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileBannerUrl(file)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFileBanner(false)
    }

    useEffect(() => {
        async function fetchData() {
            await CategoryContext.getAllCategories()
            const res = await CollectionContext?.getCollection(params?.id)
    
            await setFileUrl(res?.logoUrl + SMALL_THUMBNAIL_IMAGE_TYPE)
            await setFileBannerUrl(res?.bannerUrl + SMALL_THUMBNAIL_IMAGE_TYPE)
            await updateFormInput(
                {
                    name: res?.name,
                    description: res?.description,
                    socialMedia: JSON.parse(res?.socialMediaUrl),
                    slug: res?.slug
                }
            )
            await setCategory({
                value: res?.categoryId,
                name: CategoryContext?.categories?.find(category => category?.id === res?.categoryId)?.name
            })
            // if (!_.isNil(res?.logoUrl)) return await toDataUrl(res?.logoUrl + SMALL_THUMBNAIL_IMAGE_TYPE, function (x) {
            reset({
                name: res?.name,
                description: res?.description,
                category: {
                    value: res?.categoryId,
                    name: CategoryContext?.categories?.find(category => category?.id === res?.categoryId)?.name
                },
                fileUrl: res?.logoUrl,
                // fileBannerUrl: CollectionContext?.collection?.bannerUrl,
            })
            // })
        }
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params?.id])

    const onSubmit = async (data) => {
        try {
            // upload LogoURL
            setLoading(true)
            let logoImage = null
            let inputFile
            if (!_.isNil(data?.fileUrlUpdate)) {
                inputFile = await new FormData()
                await inputFile.append('file', fileUrl)
                await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
                logoImage = await AssetContext?.uploadAsset(inputFile)
            }
            // upload BannerURL
            let bannerImage = null
            if (!_.isNil(data?.fileBannerUrl)) {
                inputFile = await new FormData()
                await inputFile.append('file', fileBannerUrl)
                await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
                bannerImage = await AssetContext?.uploadAsset(inputFile)
            }

            const collectionData = {
                ownerId: AuthContext?.auth?.user?.id,
                categoryId: parseInt(category?.value),
                name: formInput?.name,
                description: formInput?.description,
                isVerified: false,
                socialMediaUrl: JSON.stringify(formInput?.socialMedia),
                slug: formInput?.slug,
                createdAt: new Date()
            }
            const logoData = { logoUrl: logoImage?.url }
            const bannerUrlData = { bannerUrl: bannerImage?.url }

            CollectionContext.updateCollection(CollectionContext?.collection?.id, { ...collectionData, ...(logoImage?.url && logoData), ...(bannerImage?.url && bannerUrlData) })
            await CollectionContext?.getCollectionByOwnerId(AuthContext?.auth?.user?.id)
            setLoading(false)
            navigate('/my-collection')
        } catch (error) {
            setLoading(false)
            console.log('ERR : ', error);
        }
    }
    React.useEffect(() => {
        const subscription = watch((value, { name, type }) => console.log(value, name, type));
        return () => subscription.unsubscribe();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [watch]);

    const backGround = classNames("grid md:gap-4 gap-6 grid-cols-1 md:pt-16 md:px-16 px-4 container", { "create-nft-form-background": !responsive })
    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div className={backGround} style={{ width: responsive ? '100%' : "815px" }}>

                <InputRoundedFileWithLabel
                    name="fileUrlUpdate"
                    control={control}
                    onChange={onChange}
                    value={fileUrl}
                    loading={loadingFile}
                    classstyle="font-quicksand md:text-lg text-base font-bold mb-4"
                    tx='marketplace.createNft.upload' />
                <InputFileWithLabel
                    name="fileBannerUrl"
                    control={control}
                    responsive={responsive}
                    onChange={onChangeBanner}
                    value={fileBannerUrl}
                    loading={loadingFileBanner}
                    classstyle="font-quicksand md:text-lg text-base font-bold mb-4"
                    text="Unggah banner"
                    textSublabel="Banner akan tampil di halaman koleksi-mu (Ukuran 1400x400)"
                />
                <InputWithLabel
                    errors={errors}
                    register={register}
                    name="name"
                    onChange={e => {
                        updateFormInput({ ...formInput, name: e.target.value, slug: `${e.target.value?.replace(/\s/g, '-')}-${AuthContext?.auth?.user?.id}` })
                    }}
                    defaultValue={formInput.name}
                    value={formInput.name}
                    placeholder="Masukkan nama asetmu"
                    tx='marketplace.createNft.name' />
                <InputWithLabel
                    errors={errors}
                    name="description"
                    register={register}
                    onChange={e => updateFormInput({ ...formInput, description: e.target.value })}
                    defaultValue={formInput.description}
                    value={formInput.description}
                    placeholder="Masukkan deskripsi asetmu"
                    tx='marketplace.createNft.description' />
                {/* SLUG DI HIDE DULU */}
                {/*   <InputWithLabel
                onChange={e => updateFormInput({ ...formInput, slug: e.target.value })}
                placeholder="https://codenftmarket/collection/..."
                subLabel='Isi nama url yang kamu mau (Hanya berisi huruf kecil, angka, dan -)'
                value={formInput?.slug}
                text='URL' /> */}
                <InputDropdownWithLabel tx='marketplace.createNft.category' data={
                    CategoryContext.categories.map(({ name, id }) => ({
                        value: id,
                        name
                    }))
                }
                    control={control}
                    name="category"
                    value={category}
                    setValue={setCategory}
                    subLabel="Pilih kategori sesuai aset digitalmu."
                    placeholder="Pilih Kategori"
                />
                <LabelText text="Website and Social Media" />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            web: e.target.value
                        }
                    })}
                    value={formInput.socialMedia.web}
                    appendleft={
                        <WireframeIcon className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan alamat website..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            instagram: e.target.value
                        }
                    })}
                    value={formInput.socialMedia.instagram}
                    appendleft={
                        <GrayInstagramIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Instagram..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            facebook: e.target.value
                        }
                    })}
                    value={formInput.socialMedia.facebook}
                    appendleft={
                        <GrayFacebookIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Facebook..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            twitter: e.target.value
                        }
                    })}
                    value={formInput.socialMedia.twitter}
                    appendleft={
                        <GrayTwitterIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Twitter..."
                />
                <div className="flex md:justify-end justify-center">
                    <RoundedButton type="submit" disabled={loading} color={loading ? "bg-gray-500" : "bg-hijau_hutan"} className="mb-6 py-4 px-10 md:w-auto w-full">
                        {/* <RoundedButton onClick={createMarket} classstyle="mb-10 w-1/4  "> */}
                        {(loading || assetContext.loading) ? <ButtonText tx='loading...' />
                            : <ButtonText tx='Ubah' />
                        }
                    </RoundedButton>
                </div>
            </div>
        </form>
    )
}

export default UpdateCollectionForm