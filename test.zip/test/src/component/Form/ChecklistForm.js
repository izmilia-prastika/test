import React from "react";
import ChecklistInput from "../Input/ChecklistInput";

const ChecklistForm = ({
  value,
  label,
  subLabel,
  last,
  className,
  setValue,
}) => {
  return (
    <div
      className={`flex flex-row justify-center content-center items-center self-start mb-4 ${className}`}
    >
      <ChecklistInput setValue={setValue} className="mr-5" value={value} />
      <div className="flex flex-col self-start -mt-1 justify-start w-full">
        {label && (
          <p className="font-quicksand md:text-base text-xs font-semibold mb-2">
            {label}
          </p>
        )}
        <p className="font-quicksand md:text-sm text-xs font-medium">
          {subLabel}
        </p>
        {last || <hr style={{ borderTopWidth: "0.8px" }} />}
      </div>
    </div>
  );
};

export default ChecklistForm;
