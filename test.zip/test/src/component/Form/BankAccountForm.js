import React from "react";
import { BankAccountImg } from "../../assets";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
// import ExclamationIcon from "../../assets/icon/exclamation_icon";
import RoundedButton from "../Button/RoundedButton";
import Card from "../Card/Card";
import ExclamationInfo from "../Info/ExclamationInfo";
import ButtonText from "../Text/ButtonText";
import FormTitleText from "../Text/FormTitleText";

const MobileBankForm = ({clickAddBank, isLoading, isPending, isEdit}) => {
    return(
        <Card className="bg-hijau_soft py-6 shadow-md rounded-lg">
            <div className="flex items-center pb-4 border-b px-5">
                <img src={BankAccountImg} alt="Bank Account" className="h-12 w-12 mr-3"/>
                <p className="font-quicksand font-medium text-xs">Rekening Bank akan digunakan untuk mentransfer pembeli yang dilakukan menggunakan mata uang Rupiah</p>
            </div>
            <div className="px-5 pt-4 mb-6 flex flex-col gap-y-4">
                <ExclamationInfo value="Akun Rekening Bank yang aktif maksimal berjumlah 1 (satu) buah" />
                <ExclamationInfo value="Data Rekening Bank anda akan tersimpan aman di Blockchain" />
            </div>
            <div className="inline-flex  w-full justify-end">
                <RoundedButton color={isLoading ? "bg-hijau_kristal" : "bg-hijau_hutan"} disabled={isLoading} onClick={clickAddBank} className="px-6 py-2 mr-4">
                    <div className="flex">
                        <ButtonText tx={isEdit ? isPending ? "Lanjutkan Pembayaran" : "Ubah Rekening Bank" : isPending ? "Lanjutkan Pembayaran" : "Tambah Rekening Bank"} />
                        {isLoading && <SpinCircleLogo className="ml-2"/>}
                    </div>
                </RoundedButton> 
            </div>
        </Card>
    )
}

const BankAccountForm = ({clickAddBank, responsive, isEdit, isLoading, isPending}) =>{
    return(
        !responsive ?
        <Card className="setting-main-card pt-10 px-10 mb-2 pb-10" width={1070}>
            <FormTitleText classstyle="mb-4" tx="Daftar Rekening Bank" />
            <p className="font-quicksand font-normal text-base mb-2 text-hitam">Rekening Bank akan digunakan untuk mentransfer pembeli yang dilakukan menggunakan mata uang Rupiah</p>
            <ExclamationInfo value="Data Rekening Bank anda akan tersimpan aman di Blockchain dan maksimal berjumlah 1 akun rekening" />
            <ExclamationInfo value="Tiap 1 kali pembayaran gas fee berlaku untuk 3 kali validasi bank" />
            <div className="inline-flex  w-full justify-end">
                <RoundedButton color={isLoading ? "bg-hijau_kristal" : "bg-hijau_hutan"} disabled={isLoading} onClick={clickAddBank} className="px-6 py-4">
                    <div className="flex">
                        <ButtonText tx={isEdit ? isPending ? "Lanjutkan Pembayaran" : "Ubah Rekening Bank" : isPending ? "Lanjutkan Pembayaran" : "Tambah Rekening Bank"} />
                        {isLoading && <SpinCircleLogo className="ml-2"/>}
                    </div>
                </RoundedButton> 
            </div>
        </Card> : 
        <MobileBankForm 
            clickAddBank={clickAddBank}
            isLoading={isLoading}
            isPending={isPending} 
            isEdit={isEdit}   
            />
    )
}

export default BankAccountForm