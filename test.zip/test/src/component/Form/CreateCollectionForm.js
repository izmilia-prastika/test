import { useContext, useEffect, useState } from 'react'
import RoundedButton from '../Button/RoundedButton'
import InputDropdownWithLabel from '../Input/InputDropdownWithLabel'
import InputFileWithLabel from '../Input/InputFileWithLabel'
import InputWithLabel from '../Input/InputWithLabel'
import ButtonText from '../Text/ButtonText'

import assetContext from '../../context/Asset/assetContext'
import collectionContext from '../../context/Collection/collectionContext'
import categoryContext from '../../context/Category/categoryContext'
import authContext from '../../context/Auth/authContext'
import InputSwitchWithLabel from '../Input/InputSwitchWithLabel'
import { useNavigate } from 'react-router'
import InputRoundedFileWithLabel from '../Input/InputRoundedFileWithLabel'
import Input from '../Input/Input'
import WireframeIcon from '../../assets/icon/wireframe_icon'
import CreateVerifiedForm from './CreateVerifiedForm'
import LabelText from '../Text/LabelText'
import classNames from 'classnames'
import { toast } from 'react-toastify'
import { renderFileUploadPath } from '../../utils/helper'
import { COLLECTIONS_FOLDER } from '../../utils/constants/folderTypes'
import GrayTwitterIcon from '../../assets/icon/gray_twitter_icon'
import GrayFacebookIcon from '../../assets/icon/gray_facebook_icon'
import GrayInstagramIcon from '../../assets/icon/gray_instagram_icon'
// import socketContext from '../../context/Socket/socketContext'
import { useForm } from 'react-hook-form'
import CollectionValidation from '../../utils/validation/CollectionFormValidation'
import _ from 'lodash'
import postProcessingContext from '../../context/Postprocessing/postProcessingContext'

const SUPPORTED_FORMAT = ["jpeg", "jpg", "png", "mpeg", "mp4", "gif", "webp"]
const IMAGE_SIZE_LIMIT = 20971520
const IMAGE = "image"

const CreateCollectionForm = ({ responsive }) => {
    const { control, register, formState: { errors }, handleSubmit } = useForm({
        resolver: CollectionValidation
    })
    const [formInput, updateFormInput] = useState({
        price: '0', name: '', description: '', socialMedia: {
            instagram: "",
            twitter: "",
            facebook: "",
            web: ""
        }, slug: ''
    })

    const [verifiedFormInput, updateVerifiedFormInput] = useState({
        name: "",
        address: "",
        phone: "",
        idCardFile: "",
        requirementFile: "",
    })
    const [fileUrl, setFileUrl] = useState(null)
    const [fileBannerUrl, setFileBannerUrl] = useState(null)
    const [loading, setLoading] = useState(false)
    const [isVerifying, setIsVerifying] = useState(false)
    const [category, setCategory] = useState(null)
    const [loadingFile, setLoadingFile] = useState(false)
    const [loadingFileBanner, setLoadingFileBanner] = useState(false)


    const CollectionContext = useContext(collectionContext);
    const CategoryContext = useContext(categoryContext);
    const AuthContext = useContext(authContext);
    const AssetContext = useContext(assetContext)
    const PostProcessingContext = useContext(postProcessingContext)
    // const SocketContext = useContext(socketContext)
    // const { socket } = SocketContext

    const navigate = useNavigate();

    async function onChange(e) {
        setLoadingFile(true)
        const file = e.target.files[0]
        const format = file.type.split("/")[1]
        const type = file.type.split("/")[0]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileUrl(file)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFile(false)
    }

    async function onChangeBanner(e) {
        setLoadingFileBanner(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                setFileBannerUrl(file)
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFileBanner(false)
    }

    useEffect(() => {
        CollectionContext.getAllCollections()
        CategoryContext.getAllCategories()

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onSubmit = async () => {
        try {
            // upload LogoURL
            setLoading(true)
            let inputFile = await new FormData()
            await inputFile.append('file', fileUrl)
            await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
            const logoImage = await AssetContext?.uploadAsset(inputFile)

            // upload BannerURL
            let bannerImage = null
            if(!_.isNil(fileBannerUrl)){
                inputFile = await new FormData()
                await inputFile.append('file', fileBannerUrl)
                await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
                bannerImage = await AssetContext?.uploadAsset(inputFile)
            }

            const collectionData = {
                ownerId: AuthContext?.auth?.user?.id,
                categoryId: parseInt(category?.value),
                name: formInput?.name,
                description: formInput?.description,
                logoUrl: logoImage?.url,
                bannerUrl: bannerImage?.url,
                isVerified: false,
                isRequestVerification: isVerifying,
                socialMediaUrl: JSON.stringify(formInput?.socialMedia),
                slug: formInput?.slug,
                createdAt: new Date()
            }

            if (isVerifying) {
                // const res = await CollectionContext.createCollection(collectionData)

                // upload LogoURL
                inputFile = await new FormData()
                await inputFile.append('file', verifiedFormInput?.idCardFile)
                await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
                const IdCardImage = await AssetContext?.uploadAsset(inputFile)

                // upload BannerURL
                inputFile = await new FormData()
                await inputFile.append('file', verifiedFormInput?.requirementFile)
                await inputFile.append('path', renderFileUploadPath(COLLECTIONS_FOLDER, AuthContext?.auth?.user?.address))
                const requirementImage = await AssetContext?.uploadAsset(inputFile)

                const verificationData = {
                    // collectionId: res?.id,
                    namaPic: verifiedFormInput?.name,
                    noTelpPic: verifiedFormInput?.phone,
                    alamatEmailPic: verifiedFormInput?.address,
                    buktiKepemilikanAsetUrl: requirementImage?.url,
                    ktpNpwpUrl: IdCardImage?.url
                }

                // CollectionContext?.requestCollectionVerification(verificationData)
                await PostProcessingContext.createCollection({collectionData, verificationData})

            } else {
                await CollectionContext.createCollection(collectionData)
            }
            await CollectionContext?.getCollectionByOwnerId(AuthContext?.auth?.user?.id)
            setLoading(false)
            navigate('/my-collection')
        } catch (error) {
            setLoading(false)
            console.log('ERR : ', error);
        }
    }

    const backGround = classNames("grid md:gap-4 gap-6 grid-cols-1 md:pt-10 md:px-16 container", { "create-nft-form-background": !responsive })
    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div className={backGround} style={{ width: responsive ? '100%' : "815px" }}>

                <InputRoundedFileWithLabel
                    name="fileUrl"
                    control={control}
                    onChange={onChange}
                    value={fileUrl}
                    loading={loadingFile}
                    classstyle="font-quicksand md:text-lg text-base font-bold mb-4"
                    tx='Unggah Foto Koleksi' 
                    />
                <InputFileWithLabel
                    name="fileBannerUrl"
                    control={control}
                    responsive={responsive}
                    onChange={onChangeBanner}
                    value={fileBannerUrl}
                    loading={loadingFileBanner}
                    classstyle="font-quicksand md:text-lg text-base font-bold mb-2"
                    text="Unggah banner"
                    textSublabel="Banner akan tampil di halaman koleksi-mu (Ukuran 1400x400)"
                    leftLabel={true}
                />
                <InputWithLabel
                    errors={errors}
                    register={register}
                    name="name"
                    onChange={e => {
                        updateFormInput({ ...formInput, name: e.target.value, slug: `${e.target.value?.replace(/\s/g, '-')}-${AuthContext?.auth?.user?.id}` })
                    }}
                    placeholder="Masukkan nama koleksimu"
                    tx='marketplace.createNft.name' />
                <InputWithLabel
                    errors={errors}
                    name="description"
                    register={register}
                    onChange={e => updateFormInput({ ...formInput, description: e.target.value })}
                    placeholder="Masukkan deskripsi koleksimu"
                    tx='marketplace.createNft.description' />
                {/* SLUG DI HIDE DULU */}
                {/*   <InputWithLabel
                onChange={e => updateFormInput({ ...formInput, slug: e.target.value })}
                placeholder="https://codenftmarket/collection/..."
                subLabel='Isi nama url yang kamu mau (Hanya berisi huruf kecil, angka, dan -)'
                value={formInput?.slug}
                text='URL' /> */}
                <InputDropdownWithLabel className="md:w-1/2 w-full" tx='marketplace.createNft.category' data={
                    CategoryContext.categories.map(({ name, id }) => ({
                        value: id,
                        name
                    }))
                }
                    control={control}
                    name="category"
                    value={category}
                    setValue={setCategory}
                    subLabel="Pilih kategori koleksimu."
                    placeholder="Pilih Kategori"
                />
                <LabelText text="Website and Social Media" />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            web: e.target.value
                        }
                    })}
                    appendleft={
                        <WireframeIcon className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan alamat website..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            instagram: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayInstagramIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Instagram..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            facebook: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayFacebookIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Facebook..."
                    customPositionIcon="top-4"
                />
                <Input
                    onChange={e => updateFormInput({
                        ...formInput, socialMedia: {
                            ...formInput?.socialMedia,
                            twitter: e.target.value
                        }
                    })}
                    appendleft={
                        <GrayTwitterIcon width='30' height='30' fill='#808080' className="self-center cursor-pointer " />
                    }
                    placeholder="Masukan Twitter..."
                    customPositionIcon="top-4"
                />
                <InputSwitchWithLabel control={control} name="isVerifying" label={"Request Verifikasi ?"} value={isVerifying} onChange={() => setIsVerifying(!isVerifying)} />
                <p className='text-sm text-hitam_2 font-quicksand'>Kamu dapat meminta memverifikasi kepada tim code.id terhadap koleksi yang kamu buat,</p>
                <p className='text-sm text-hitam_2 font-quicksand'>Verifikasi membutuhkan waktu 1 sampai 2 Minggu tergantung kepada banyaknya permintaan verifikasi
                    dari pengguna lain.</p>
                <p className='text-sm text-hitam_2 font-quicksand'>Harap diisi seluruh Link Sosial Media dan Website karena akan menjadi pertimbangan apakah verifikasi
                    akan disetujui atau tidak.</p>
                {isVerifying &&
                    <CreateVerifiedForm errors={errors} control={control} register={register} responsive={responsive} formInput={verifiedFormInput} updateFormInput={updateVerifiedFormInput} />
                }
                <div className="flex md:justify-end justify-center">
                    <RoundedButton type="submit" disabled={loading} color={loading ? "bg-gray-500" : "bg-hijau_hutan"} className="mb-6 py-4 px-10 md:w-auto w-full">
                        {/* <RoundedButton onClick={createMarket} classstyle="mb-10 w-1/4  "> */}
                        {(loading || assetContext.loading) ? <ButtonText tx='loading...' />
                            : <ButtonText tx='Simpan' />
                        }
                    </RoundedButton>
                </div>
            </div>
        </form>
    )
}

export default CreateCollectionForm