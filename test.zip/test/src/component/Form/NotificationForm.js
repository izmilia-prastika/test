import React, { useContext, useEffect, useState } from "react";
import authContext from "../../context/Auth/authContext";
import notificationContext from "../../context/AssetUtilityNotification/assetUtilityNotificationContext";
import { NOTIFICATION_BID_AUCTION, NOTIFICATION_BUY, NOTIFICATION_MAKE_OFFER } from "../../utils/constants/notificationTypes";
import RoundedButton from "../Button/RoundedButton";
import Card from "../Card/Card";
import ButtonText from "../Text/ButtonText";
import ChecklistForm from "./ChecklistForm";
import _ from "lodash"

const NotificationMobile = ({isBuyActive, setIsBuyActive, isMakeOfferActive, setIsMakeOfferActive, isBidActive, setIsBidActive, handleSubmit}) => {
    return (
        <div className="flex flex-col px-4 justify-between h-full" >
            <div className="grid grid-flow-row gap-y-5">
                <ChecklistForm value={isBuyActive} setValue={setIsBuyActive} label={"Aset Terjual"} subLabel={"Notifikasi saat seorang membeli aset kamu"} />
                <ChecklistForm value={isMakeOfferActive} setValue={setIsMakeOfferActive} label={"Aktifitas Penawaran"} subLabel={"Notifikasi saat seorang melakukan penawaran aset kamu"} />
                <ChecklistForm value={isBidActive} setValue={setIsBidActive} label={"Aktifitas Penawaran Lelang"} subLabel={"Notifikasi saat ada aktifitas lelang"} last />
            </div>
            <div className="flex flex-col items-end pt-5">
                <RoundedButton onClick={handleSubmit} className="py-3 px-11 md:w-auto w-full">
                    <ButtonText tx="Simpan" />
                </RoundedButton>
            </div>
        </div>
    )
}

const NotificationForm = ({responsive}) => {
    const NotificationContext = useContext(notificationContext)
    const AuthContext = useContext(authContext)
    const [isBuyActive, setIsBuyActive] = useState(false)
    const [isMakeOfferActive, setIsMakeOfferActive] = useState(false)
    const [isBidActive, setIsBidActive] = useState(false)
    useEffect(() => {
        async function fetchData(){
            const res = await NotificationContext?.getAll({ accountId: AuthContext?.auth?.user?.id })
            setIsBuyActive(res?.find(notification => notification.type === NOTIFICATION_BUY)?.isActive)
            setIsMakeOfferActive(res?.find(notification => notification.type === NOTIFICATION_MAKE_OFFER)?.isActive)
            setIsBidActive(res?.find(notification => notification.type === NOTIFICATION_BID_AUCTION)?.isActive)
        }
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleSubmit = async () => {

        const buyDataForm = {
            accountId: AuthContext?.auth?.user?.id,
            isActive: isBuyActive,
            type: NOTIFICATION_BUY,
        }
        const makeOfferDataForm = {
            accountId: AuthContext?.auth?.user?.id,
            isActive: isMakeOfferActive,
            type: NOTIFICATION_MAKE_OFFER,
        }
        const bidDataForm = {
            accountId: AuthContext?.auth?.user?.id,
            isActive: isBidActive,
            type: NOTIFICATION_BID_AUCTION,
        }
        if (_.isNil(NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_BUY)?.id)) {
            await NotificationContext?.create(buyDataForm)
        } else {
            await NotificationContext?.update(
                NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_BUY)?.id,
                buyDataForm
            )
        }
        if (_.isNil(NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_BID_AUCTION)?.id)) {
            await NotificationContext?.create(bidDataForm)
        } else {
            await NotificationContext?.update(
                NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_BID_AUCTION)?.id,
                bidDataForm
            )
        }
        if (_.isNil(NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_MAKE_OFFER)?.id)) {
            await NotificationContext?.create(makeOfferDataForm)
        } else {
            await NotificationContext?.update(
                NotificationContext?.notifications?.find(notification => notification.type === NOTIFICATION_MAKE_OFFER)?.id,
                makeOfferDataForm
            )
        }
    }

    return (
        !responsive ? 
        <Card className="setting-main-card md:px-11 px-4 md:pt-10 pt-6" width={1070} height={420}>
            <p className="font-quicksand font-semibold text-hitam text-lg text-center mb-7">Notifikasi</p>
            <div className="grid grid-flow-row gap-y-5">
                <ChecklistForm value={isBuyActive} setValue={setIsBuyActive} label={"Aset Terjual"} subLabel={"Notifikasi saat seorang membeli aset kamu"} />
                <ChecklistForm value={isMakeOfferActive} setValue={setIsMakeOfferActive} label={"Aktifitas Penawaran"} subLabel={"Notifikasi saat seorang melakukan penawaran aset kamu"} />
                <ChecklistForm value={isBidActive} setValue={setIsBidActive} label={"Aktifitas Penawaran Lelang"} subLabel={"Notifikasi saat ada aktifitas lelang"} last />
            </div>
            <div className="flex flex-col items-end pt-5">
                <RoundedButton onClick={handleSubmit} className="py-4 px-11 md:w-auto w-full">
                    <ButtonText tx="Simpan" />
                </RoundedButton>
            </div>
        </Card> : <NotificationMobile 
                    isBuyActive={isBuyActive} 
                    setIsBuyActive={setIsBuyActive} 
                    isMakeOfferActive={isMakeOfferActive} 
                    setIsMakeOfferActive={setIsMakeOfferActive}
                    isBidActive={isBidActive}
                    setIsBidActive={setIsBidActive}    
                    handleSubmit={handleSubmit}
                    />
    )
}

export default NotificationForm