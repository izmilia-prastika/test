import { useState } from "react";
import InputFileWithLabel from "../Input/InputFileWithLabel";
import InputWithLabel from "../Input/InputWithLabel";
import { toast } from "react-toastify";

const IMAGE_SIZE_LIMIT = 20971520
const SUPPORTED_FORMAT = ["jpeg", "jpg", "png", "mpeg", "mp4", "gif", "webp"]
const IMAGE = "image"

const CreateVerifiedForm = ({ formInput, updateFormInput, responsive, control, register, errors }) => {
    const [loadingRequirement, setLoadingFileRequirement] = useState(false)
    const [loadingIDCard, setLoadingFileIDCard] = useState(false)

    async function onChangeIDCard(e) {
        setLoadingFileIDCard(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                updateFormInput({ ...formInput, idCardFile: file })
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFileIDCard(false)
    }

    async function onChangeRequirement(e) {
        setLoadingFileRequirement(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format) && type === IMAGE) {
            if (size <= IMAGE_SIZE_LIMIT) {
                updateFormInput({ ...formInput, requirementFile: file })
            } else {
                toast.info("Ukuran file tidak boleh lebih dari 20 mb")
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFileRequirement(false)
    }

    return (<div className="grid gap-4 grid-cols-1 py-4">
        <InputWithLabel
            errors={errors}
            register={register}
            name="namePic"
            onChange={e => updateFormInput({ ...formInput, name: e.target.value })}
            placeholder="Masukkan nama PIC"
            text="Nama PIC" />
        <InputWithLabel
            errors={errors}
            register={register}
            name="address"
            onChange={e => updateFormInput({ ...formInput, address: e.target.value })}
            placeholder="Masukkan alamat email"
            text="Alamat Email PIC" />
        <InputWithLabel
            errors={errors}
            register={register}
            name="phone"
            onChange={e => updateFormInput({ ...formInput, phone: e.target.value })}
            placeholder="Masukkan Nomor Telepon"
            text="No Telp/Hp PIC" />

        <InputFileWithLabel
            control={control}
            name="idCardFile"
            responsive={responsive}
            width={responsive ? "100%" : 500}
            onChange={onChangeIDCard}
            value={formInput?.idCardFile}
            loading={loadingRequirement}
            classstyle="mb-2 self-start"
            text='KTP/NPWP PIC' />
        <InputFileWithLabel
            control={control}
            name="requirementFile"
            responsive={responsive}
            width={responsive ? "100%" : 500}
            onChange={onChangeRequirement}
            value={formInput?.requirementFile}
            loading={loadingIDCard}
            classstyle="mb-2 self-start"
            text='Bukti File Pembuatan Aset' />
    </div>
    )
}

export default CreateVerifiedForm