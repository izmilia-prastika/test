import React from 'react'
import LabelText from '../Text/LabelText'
import SubLabelText from '../Text/SubLabelText';

const GroupLabelForm = (props) => {
    const { textSublabel, children, className ,classLabel} = props

    return (
        <div className={`flex flex-col items-start justify-between ${className}`} >
            <LabelText classstyle={`self-start mb-1 ${classLabel}`} {...props} />
            {textSublabel &&
                <SubLabelText classstyle="self-start mb-2" tx={textSublabel} />
            }
            {children}
        </div>
    )
}

export default GroupLabelForm