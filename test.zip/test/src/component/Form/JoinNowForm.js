import React, { useContext, useState } from "react";
import authContext from "../../context/Auth/authContext";
import exclusivePartnerContext from "../../context/ExclusivePartner/exclusivePartnerContext";
import RoundedButton from "../Button/RoundedButton";
import InputFileWithLabel from "../Input/InputFileWithLabel";
import InputWithLabel from "../Input/InputWithLabel";
import ButtonText from "../Text/ButtonText";
import { create as ipfsHttpClient } from 'ipfs-http-client'
import Swal from "sweetalert2";
import classNames from "classnames";
import { useForm } from "react-hook-form";
import JoinNowValidation from "../../utils/validation/JoinNowFormValidation";

const client = ipfsHttpClient('https://ipfs.infura.io:5001/api/v0')

const JoinNowForm = ({ responsive }) => {
    const { control, register, formState: { errors }, handleSubmit, reset } = useForm({
        resolver: JoinNowValidation
    })

    const [formInput, updateFormInput] = useState({
        namaPic: "",
        alamatPic: "",
        noTelpPic: "",
        alamatEmailPic: "",
        ktpNpwpUrl: "",
        buktiKepemilikanAsetUrl: "",
    })

    const [loadingIdCard, setLoadingIdCard] = useState(false)
    const [loadingFileDocument, setLoadingFileDocument] = useState(false)

    const ExclusivePartnerContext = useContext(exclusivePartnerContext)
    const AuthContext = useContext(authContext)

    const submit = async () => {
        const inputForm = {
            ...formInput,
            accountId: AuthContext?.auth?.user?.id
        }
        try {
            await ExclusivePartnerContext.requestExclusivePartner(inputForm)
            updateFormInput({
                namaPic: "",
                alamatPic: "",
                noTelpPic: "",
                alamatEmailPic: "",
                ktpNpwpUrl: "",
                buktiKepemilikanAsetUrl: "",
            })
            reset({
                namaPic: "",
                alamatPic: "",
                noTelpPic: "",
                alamatEmailPic: "",
                ktpNpwpUrl: "",
                buktiKepemilikanAsetUrl: "",
            })
            Swal.fire(
                'Permintaan Dikirim!',
                'Permintaan anda akan diverifikasi dalam waktu kurang lebih 7 hari kerja',
                'success'
            )
        } catch (error) {
            Swal.fire(
                'Permintaan Gagal!',
                error,
                'error'
            )
        }
    }

    async function onChangeIDCard(e) {
        const file = e.target.files[0]
        try {
            setLoadingIdCard(true)
            const added = await client.add(
                file, {
                progress: (prog) => console.log(`received: ${prog}`)
            })
            const url = `https://ipfs.infura.io/ipfs/${added.path}`
            updateFormInput({ ...formInput, ktpNpwpUrl: url })
            setLoadingIdCard(false)

        } catch (error) {
            console.log('Error uploading file:', error)
        }
    }

    async function onChangeDocument(e) {
        const file = e.target.files[0]
        try {
            setLoadingFileDocument(true)
            const added = await client.add(
                file, {
                progress: (prog) => console.log(`received: ${prog}`)
            })
            const url = `https://ipfs.infura.io/ipfs/${added.path}`
            updateFormInput({ ...formInput, buktiKepemilikanAsetUrl: url })
            setLoadingFileDocument(false)
        } catch (error) {
            console.log('Error uploading file:', error)
        }
    }

    const colClass = classNames({ "flex flex-row space-x-10 mb-10": !responsive }, { "flex flex-col gap-y-4": responsive })
    return (
        <form onSubmit={handleSubmit(submit)}>
            <div className="grid gap-4 grid-cols-1 md:pt-24 pt-0 md:px-36 px-4 shadow-lg pb-24" >
                <InputWithLabel
                    name="namaPic"
                    register={register}
                    errors={errors}
                    onChange={e => updateFormInput({ ...formInput, namaPic: e.target.value })}
                    placeholder="Masukkan nama PIC"
                    text="Nama PIC" />
                <InputWithLabel
                    name="alamatEmailPic"
                    register={register}
                    errors={errors}
                    onChange={e => updateFormInput({ ...formInput, alamatEmailPic: e.target.value })}
                    placeholder="Masukkan alamat email"
                    text="Alamat Email PIC" />
                <InputWithLabel
                    name="noTelpPic"
                    register={register}
                    errors={errors}
                    onChange={e => updateFormInput({ ...formInput, noTelpPic: e.target.value })}
                    placeholder="Masukkan Nomor Telepon"
                    text="No Telp/Hp PIC" />
                <InputWithLabel
                    name="alamatPic"
                    register={register}
                    errors={errors}
                    onChange={e => updateFormInput({ ...formInput, alamatPic: e.target.value })}
                    placeholder="Masukkan alamat "
                    text="Alamat Rumah/Perusahaan PIC" />
                <div className={colClass}>

                    <InputFileWithLabel
                        control={control}
                        name="ktpNpwpUrl"
                        width={"100%"}
                        height={responsive ? 144 : "auto"}
                        onChange={onChangeIDCard}
                        value={formInput?.ktpNpwpUrl}
                        loading={loadingIdCard}
                        className="font-quicksand text-lg"
                        text='KTP/NPWP PIC' />
                    <InputFileWithLabel
                        control={control}
                        name="buktiKepemilikanAsetUrl"
                        height={responsive ? 144 : "auto"}
                        onChange={onChangeDocument}
                        value={formInput?.buktiKepemilikanAsetUrl}
                        loading={loadingFileDocument}
                        width={"100%"}
                        className="self-end font-quicksand text-lg"
                        text='Bukti File Kepemilikan Aset' />
                </div>
                <RoundedButton className="md:py-4 py-3 self-center justify-self-center md:w-64 w-full" type="submit">
                    <ButtonText tx="Kirim Sekarang" classstyle="text-lg"/>
                </RoundedButton>
            </div>
        </form >
    )
}

export default JoinNowForm