import React, { useEffect } from "react";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
import { useController, useForm } from "react-hook-form";

const AdderInput = ({
    name="adderInput",
    required,
    value, onChange, handleClickSubstract, handleClickAdd, disableSubstract, disableAdder, width, className ,...props}) => {
    const { control } = useForm()
    const { field } = useController({
        control: props?.control || control,
        name,
        rules: { required }
    })
    useEffect(() => {
        field.onChange(value)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value])
    return (
        <div className={className}>
            <div className={`flex flex-row items-center`}>
                <RoundedButton
                    onClick={handleClickSubstract}
                    className={`py-0 px-0 h-6 w-6 mr-4 ${disableSubstract && 'opacity-80'} `}>
                    <ButtonText tx="-" />
                </RoundedButton>
                <input
                    value={value}
                    onChange={onChange}
                    className="mr-4 md:shadow text-center appearance-none border w-14 border-gray-200 rounded-md  py-2  text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    style={{
                        width: width
                    }}
                />
                <RoundedButton
                    onClick={handleClickAdd}
                    className={`py-0 px-0 h-6 w-6 md:mr-4 ${disableAdder && 'opacity-80'} `}>
                    <ButtonText tx="+" />
                </RoundedButton>
            </div>
        </div>
    )
}

export default AdderInput