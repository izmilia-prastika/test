import { useCallback, useContext, useEffect, useRef, useState } from "react";
import { MagnifierLogoImg, UserImage } from "../../assets";
// import filterContext from "../../context/Filter/filterContext";
import { useNavigate } from "react-router-dom";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import articleContext from "../../context/Article/articleContext";
import InputRounded from "./InputRounded";

const TOP_COUNT = 5
const TYPING_DELAY = 1000
const InputSmartArticles = ({setShowMenuMobile}) => {
    const ref = useRef()
    const ArticleContext = useContext(articleContext)
    const [search, setSearchs] = useState(null)
    const [show, setShow] = useState(false)
    const navigate = useNavigate()
    const navToDetail = useCallback((slug, id) => navigate(`/article/${slug}/${id}`), [navigate])

    useEffect(() => {
        /* eslint-disable */

        const timeOutId = setTimeout(async () => {
            let input = {}
            if (!!search) {
                // await FilterContext?.getTopAccounts({ first: TOP_COUNT, searchFilter: search })
                // await FilterContext?.getTopCollections({ first: TOP_COUNT, searchFilter: search })
                // await FilterContext?.getTopAssets({ first: TOP_COUNT, searchFilter: search })
                input = [
                    {
                        "index": "articles",
                        "limit": TOP_COUNT
                    },
                ]
                await ArticleContext?.getSearch(input, search)
                setShow(true)
            } else {
                setShow(false)
            }
            // implement elastic search
            // await console.log(ArticleContext.topArticle, "TES")
        }, TYPING_DELAY);
        return () => clearTimeout(timeOutId);
    }, [search]);
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (!ref?.current?.contains(event.target)) {
                setShow(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
    }, [ref]);

    const handleInput = (e) => {
        setSearchs(e.target.value)
    }

    const handleOnFocus = () => {
        setShow(true)
    }

return (
    <div ref={ref} className="md:w-auto w-full flex relative">
        <InputRounded
            placeholder="Cari judul artikel disini..."
            appendleft={<MagnifierLogoImg />}
            className="w-full"
            inputstyle="md:h-12 h-10 md:w-96 w-full pl-12 font-quicksand bg-gray-100 border-gray-400 placeholder-shown:italic focus:border-oranye"
            onFocus={handleOnFocus}
            onChange={handleInput}
            onKeyDown={async e => {
            if (e.keyCode === 13) {
                e.preventDefault();
                e.stopPropagation();
                // await ArticleContext?.setSearchAsset(search)
                // await ArticleContext?.setSearchTag("")
                // navigate('/assets')
            }
            }}
            customAppendLeft="md:top-4 top-3"
        />
        <ul className={` absolute ${!show && 'hidden'} md:w-4/5 w-11/12 border-gray-200 border-2 overflow-y-auto h-auto md:right-24 md:top-12 top-10 right-4 max-h-96 mt-2 bg-white rounded-md z-40 text-gray-700 pt-1`}>
                {
                    ArticleContext?.loadingSearch && search &&
                    <li className="flex flex-row items-center justify-center bg-white">
                        <p className="rounded-t mr-2 bg-white py-2 px-4 cursor-pointer block whitespace-no-wrap">Mencari Data</p>
                        <SpinCircleLogo />
                    </li>
                }
                {
                    (!ArticleContext?.loadingSearch && !search) && 
                    <li className="flex flex-row items-center justify-center bg-white">
                        <p className="bg-white py-2 px-4 cursor-pointer font-quicksand">Silahkan ketik judul artikel</p>
                    </li>
                }
                {
                    ArticleContext?.topArticle.length !== 0 && search && 
                    <li>
                        <p className="font-semibold font-quicksand px-4 pt-3 pb-2">Hasil Pencarian Artikel</p>
                    </li>
                }
                {
                    ArticleContext?.topArticle.length !== 0 && search &&
                    ArticleContext?.topArticle?.map(({title, id, thumbnail_url, slug}, idx) => 
                    <li className="flex flex-row px-4 py-3 justify-start items-center hover:bg-gray-300 cursor-pointer" key={idx} onClick={() => navToDetail(slug, id)}>
                        <img alt="article" src={!!thumbnail_url ? thumbnail_url + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} className="object-cover h-8 w-8 rounded-full mr-3"/>
                        <p className="line-clamp-1 font-quicksand">{title}</p>
                    </li>
                    )
                }
        </ul>
    </div>
)
}

InputSmartArticles.defaultProps = {
    setShowMenuMobile : () => {},
}

export default InputSmartArticles