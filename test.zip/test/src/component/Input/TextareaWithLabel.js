import React from 'react'
import ErrorFormText from '../Text/ErrorFormText'
import LabelText from '../Text/LabelText'
import SubLabelText from '../Text/SubLabelText'

const TextareaWithLabel = ({ name, register, required, errors, ...props }) => {
    const { subLabel, className } = props
    return (
        <>
            <div className={`flex flex-col ${className}`}>
                <LabelText {...props} />
                {subLabel &&
                    <SubLabelText text={subLabel} />
                }
                <textarea  {...props} {...(register && register(name, { required }))} className={`
            md:shadow appearance-none border  ${errors?.[name] ? "border-red-500" : "border-gray-200"} rounded-md bg-transparent p-4  text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline
                `}
            />
            </div>
            <ErrorFormText tx={errors?.[props?.name] && (errors?.[props?.name]?.message )} />
        </>
    )
}

export default TextareaWithLabel