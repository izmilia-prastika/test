import React from 'react'
import ErrorFormText from '../Text/ErrorFormText'
import LabelText from '../Text/LabelText'
import SubLabelText from '../Text/SubLabelText'

const InputWithLabel = ({ name, register, required, errors, defaultValue, ...props }) => {
    const { subLabel, className } = props
    const registerHook = register && register(name, { required })
    const onChange = (e) => {
        registerHook?.onChange(e)
        props?.onChange(e)
    }
    return (
        <div className={`flex flex-col ${className}`}>
            <div className='flex flex-col'>
                <LabelText {...props} />
                {subLabel &&
                    <SubLabelText text={subLabel} />
                }

                <input {...props} {...(registerHook)} defaultValue={defaultValue} onChange={onChange} className={`
            md:shadow order-7 appearance-none border  rounded-md bg-transparent md:p-4 p-3 text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline
             ${errors?.[name] ? "border-red-500" : "border-gray-200"}
                `}
                />
            </div>
            <ErrorFormText tx={errors?.[name] && (errors?.[name]?.message)} />
        </div>
    )
}

export default InputWithLabel