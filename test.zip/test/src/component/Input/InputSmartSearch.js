import { useContext, useEffect, useRef, useState } from "react";
import { MagnifierLogoImg } from "../../assets";
import filterContext from "../../context/Filter/filterContext";
import Input from "./Input";
import _ from 'lodash'
import { useNavigate, createSearchParams } from "react-router-dom";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";

const TOP_COUNT = 5
const TYPING_DELAY = 1000
const InputSmartSearch = ({setShowMenuMobile}) => {
    const ref = useRef()
    const FilterContext = useContext(filterContext)
    const [search, setSearchs] = useState(FilterContext?.searchAsset)
    const [show, setShow] = useState(false)
    const navigate = useNavigate()

    useEffect(() => {

        const timeOutId = setTimeout(async () => {
            /* eslint-disable */

            let input = {}
            if (search) {
                // await FilterContext?.getTopAccounts({ first: TOP_COUNT, searchFilter: search })
                // await FilterContext?.getTopCollections({ first: TOP_COUNT, searchFilter: search })
                // await FilterContext?.getTopAssets({ first: TOP_COUNT, searchFilter: search })
                input = [
                    {
                        "index": "assets",
                        "limit": TOP_COUNT
                    },
                    {
                        "index": "collections",
                        "limit": TOP_COUNT
                    },
                    {
                        "index": "tags",
                        "limit": TOP_COUNT
                    },
                    {
                        "index": "accounts",
                        "limit": TOP_COUNT
                    }
                ]
                setShow(true)
            } else {
                input = [
                    {
                        "index": "top_tags"
                    }
                ]
            }
            // implement elastic search
            await FilterContext?.getSearch(input, search)
        }, TYPING_DELAY);
        return () => clearTimeout(timeOutId);
    }, [search]);
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (!ref?.current?.contains(event.target)) {
                setShow(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
           // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ref]);

    const handleInput = (e) => {
        setSearchs(e.target.value)

    }

    const handleOnFocus = () => {
        setShow(true)
    }
    return (
        <div ref={ref}>
            <Input
                placeholder="Jelajahi NFT Saya"
                appendleft={<MagnifierLogoImg />}
                className="md:h-9 h-10 pl-8 font-quicksand md:text-base text-sm"
                onFocus={handleOnFocus}
                onChange={handleInput}
                onKeyDown={async e => {
                    if (e.keyCode === 13) {
                        e.preventDefault();
                        e.stopPropagation();
                        await FilterContext?.setSearchAsset(search)
                        await FilterContext?.setSearchTag("")
                        navigate('/assets')
                    }
                }}
                />
            <ul className={` absolute ${!show && 'hidden'} md:w-2/5 w-11/12 border-gray-200 border-2 overflow-y-auto max-h-96 rounded-md z-30 text-gray-700 pt-1`}>
                {
                    FilterContext?.loading &&
                    <li className="flex flex-row items-center justify-center bg-white">
                        <p className="rounded-t mr-2 bg-white py-2 px-4 cursor-pointer block whitespace-no-wrap">Mencari Data</p>
                        <SpinCircleLogo />
                    </li>
                }
                {
                    !search &&
                    <li key={"labelTags"}>
                        <p className="rounded-t bg-white py-2 px-4 block font-bold whitespace-no-wrap">Tag terpopuler</p>
                    </li>
                }
                {
                    !search &&
                    <ul className="inline-flex flex-wrap px-4 bg-white w-full">
                        {FilterContext?.topTags?.map((tag, i) =>
                            <li className="flex flex-row items-center cursor-pointer mr-2 mb-4 rounded bg-abu_f2 px-4 justify-start hover:bg-gray-400"
                                key={i + "tag"} onClick={async () => {
                                    await FilterContext?.setSearchAsset("")
                                    await FilterContext?.setSearchTag(tag?.key)
                                    setShow(false)
                                    setShowMenuMobile(false)
                                    setSearchs("")
                                    navigate({ pathname: '/assets', search: `${createSearchParams({
                                        tag: tag?.key
                                    })}`}, { replace: true })
                                }}>
                                <p className="rounded-t py-2 block whitespace-no-wrap">{tag?.key}</p>
                            </li>
                        )}
                    </ul>
                }
                {
                    !_.isEmpty(FilterContext?.tags) && search &&
                    <li key={"labelTags"}>
                        <p className="rounded-t bg-white py-2 px-4 block font-bold whitespace-no-wrap">Tag</p>
                    </li>
                }

                {
                    search &&
                    <ul className="inline-flex flex-wrap px-4 bg-white w-full">
                        {FilterContext?.tags?.map((tag, i) =>
                            <li className="flex flex-row items-center cursor-pointer mr-2 rounded mb-4 bg-abu_f2 px-4 justify-start hover:bg-gray-400"
                                key={i + "tag"} onClick={async () => {
                                    await FilterContext?.setSearchAsset("")
                                    await FilterContext?.setSearchTag(tag?.title)
                                    setShow(false)
                                    setShowMenuMobile(false)
                                    setSearchs("")
                                    navigate({ pathname: '/assets', search: `${createSearchParams({
                                        tag: tag?.title
                                    })}`}, { replace: true })
                                }}>
                                <p className="rounded-t py-2 block whitespace-no-wrap">{tag?.title}</p>
                            </li>
                        )}
                    </ul>
                }
                {
                    !_.isEmpty(FilterContext?.topAssets) && search &&
                    <li key={"labelAssets"}>
                        <p className="rounded-t bg-white font-bold py-2 px-4 block whitespace-no-wrap">Nama Aset</p>
                    </li>
                }
                {
                    search && FilterContext?.topAssets?.map((asset, i) =>
                        <li className="flex flex-row items-center cursor-pointer px-4 justify-start hover:bg-gray-400 bg-white"
                            key={i + "assets"} onClick={() => {
                                navigate(`/asset/${asset?.id}`)
                                setShowMenuMobile(false)
                                setShow(false)
                                setSearchs("")
                            }}>
                            <img alt="asset" src={asset?.thumbnail_url+SMALL_THUMBNAIL_IMAGE_TYPE} className="h-4 w-4 mr-2 rounded-full" />
                            <p className="rounded-t py-2 block whitespace-no-wrap">{asset?.name}</p>
                        </li>
                    )
                }
                {
                    !_.isEmpty(FilterContext?.topCollections) && search &&
                    <li key={"labelCollections"}>
                        <p className="rounded-t bg-white font-bold py-2 px-4 block whitespace-no-wrap">Nama Koleksi</p>
                    </li>
                }
                {
                    search && FilterContext?.topCollections?.map((collection, i) =>
                        <li className="flex flex-row items-center cursor-pointer  px-4 justify-start hover:bg-gray-400 bg-white"
                            key={i + "collection"} onClick={() => {
                                navigate(`/collection/${collection?.id}`)
                                setShowMenuMobile(false)
                                setShow(false)
                                setSearchs("")
                            }}>
                            <img alt="collection" src={collection?.logo_url+SMALL_THUMBNAIL_IMAGE_TYPE} className="h-4 w-4 mr-2 rounded-full" />

                            <p className="rounded-t  py-2 block whitespace-no-wrap">{collection?.name}</p>
                        </li>
                    )
                }
                {
                    !_.isEmpty(FilterContext?.topAccounts) && search &&
                    <li key={"labelAccount"}>
                        <p className="rounded-t bg-white py-2 px-4 block font-bold whitespace-no-wrap">Nama Akun</p>
                    </li>
                }
                {
                    search && FilterContext?.topAccounts?.map((account, i) =>
                        <li className="flex flex-row items-center cursor-pointer  px-4 justify-start hover:bg-gray-400 bg-white"
                            key={i + "account"} onClick={() => {
                                navigate(`/account/${account?.id}`)
                                setShowMenuMobile(false)
                                setShow(false)
                                setSearchs("")
                            }}>
                            <img alt="account profile" src={account?.profile_picture_url+SMALL_THUMBNAIL_IMAGE_TYPE} className="h-4 w-4 mr-2 rounded-full" />
                            <p className="rounded-t py-2 block whitespace-no-wrap">{account?.user_name}</p>
                        </li>
                    )
                }
            </ul>
        </div>
    )
}

InputSmartSearch.defaultProps = {
    setShowMenuMobile : () => {},
}

export default InputSmartSearch