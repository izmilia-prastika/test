import React, { useRef } from 'react'
import SpinCircleLogo from '../../assets/animation/spin_circle_logo';
import RoundedButton from '../Button/RoundedButton';
import ButtonText from '../Text/ButtonText';
import LabelText from '../Text/LabelText'
import { Controller } from 'react-hook-form'
import ErrorFormText from '../Text/ErrorFormText';
import { useForm } from 'react-hook-form';

const InputRoundedFileWithLabel = ({ name = "inputRoundedFile", required, itemsAlign = "center", labelConstraint = "PNG, GIF, JPEG. Max 20MB", defaultValue, accept, ...props }) => {
    const { onChange, value, loading, classstyle, right } = props
    const propValue = value
    const inputReference = useRef();
    const fileUploadAction = () => inputReference?.current?.click();
    const changeImg = () => {
        inputReference.current.click()
    }
    const { control } = useForm()

    return (

        <Controller
            name={name}
            control={props?.control || control}
            defaultValue={defaultValue}
            rules={{
                required
            }}
            render={({ field, fieldState: { error } }) => {
                const {value, ...newField} = field
                return (
                    <div className={`flex flex-col items-${itemsAlign}`}>
                        <LabelText classstyle={`mb-7 ${classstyle}`} {...props} />
                        {!loading ?

                            <div className={` w-full flex ${right ? "flex-row items-center" : "flex-col items-center"}`}>
                                <input
                                    {...newField}
                                    type="file"
                                    hidden
                                    ref={inputReference}
                                    name="Asset"
                                    className="my-4 hidden"
                                    onChange={(e) => {
                                        field.onChange(e)
                                        onChange(e)
                                    }}
                                    accept={accept}
                                />
                                {!propValue ?
                                    <div className={`border-dashed ${error ? "border-red-500" : "border-abu_c7"} border-2 rounded-full md:h-40 h-32 md:w-40 w-32 mb-5 ${right && "mr-4"}`}>

                                    </div>
                                    :
                                    <img alt='show' src={propValue instanceof Blob ? URL.createObjectURL(propValue) : propValue} onClick={changeImg} className={`rounded-full cursor-pointer md:h-40 h-32 md:w-40 w-32  mb-5 ${right && "mr-4"}`} />
                                }
                                <div className={`flex flex-col mb-4 ${right ? "items-start" : "items-center"}`}>
                                    <p className="font-quicksand text-xs font-medium text-hitam_2 mb-4">
                                        {labelConstraint}
                                    </p>
                                    <RoundedButton type="button" onClick={fileUploadAction} color="bg-transparent" className={`border-hijau_hutan px-11 py-2 border-2 w-max`}>
                                        <ButtonText color="text-hijau_hutan">
                                            Pilih File
                                        </ButtonText>
                                    </RoundedButton>
                                </div>
                            </div>
                            :
                            <div className="flex flex-col items-center py-16">
                                <SpinCircleLogo />
                            </div>
                        }
                        <ErrorFormText tx={error?.message} />
                    </div>
                )
            }}
        />
    )
}

export default InputRoundedFileWithLabel