import React from 'react'
import GroupLabelForm from '../Form/GroupLabelForm'
import CalendarInput from './CalendarInput'

const CalendarInputWithLabel = (props) => {
    return(
        <GroupLabelForm classLabel="mb-4" {...props}>
            <CalendarInput {...props} />
        </GroupLabelForm>
    )
}

export default CalendarInputWithLabel