import React from "react";
import GroupLabelForm from "../Form/GroupLabelForm";
import InputTags from "./InputTags";

const InputTagsWithLabel = (props) => {
    return (
        <GroupLabelForm
            {...props}>
            <InputTags {...props} />
        </GroupLabelForm>
    )
}

export default InputTagsWithLabel