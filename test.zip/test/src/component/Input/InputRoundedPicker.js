import React from "react";
import classNames from "classnames";
import ChecklistIcon from "../../assets/icon/checklist_icon";

const InputRoundedPicker = ({ className, disabled, isActive, value, logo, text, onClick }) => {
    const handleOnclick = () => !disabled && onClick(value)
    return (
        <div onClick={handleOnclick} className={`md:rounded-full rounded-lg cursor-pointer md:shadow-none shadow-md ${classNames({
            "w-full": !className?.includes("w-"),
            "py-4": !className?.includes("py-"),
            "px-8": !className?.includes("px-"),
        })} ${disabled 
            ? "bg-gray-200 md:border-2 border"
            : isActive
            ? "bg-hijau_mint border-hijau_tua md:border-2 border"
            : "md:bg-pink_kuning bg-white"}
             ${className}`}>
            <div className="flex flex-row justify-between items-center">
                <div className={`grid grid-flow-col gap-4 text-lg items-center ${disabled? "text-white" : "text-hitam"}`}>
                    {logo}
                    {text}
                </div>
                {isActive && <ChecklistIcon />}
            </div>
        </div>
    )
}

export default InputRoundedPicker