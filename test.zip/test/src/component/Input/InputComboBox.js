import React, { useEffect, useRef } from 'react'
import { useState } from 'react'
import ChevronDownIcon from '../../assets/icon/chevron_down_icon';
import LabelText from '../Text/LabelText';

const InputComboBox = ({ suggestions, setValue, isEdit, validation, modalParent, ...props }) => {
    const [filteredSuggestions, setFilteredSuggestions] = useState([]);
    const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [input, setInput] = useState("");
    const ref = useRef()

    useEffect(() => {
        const handleClickOutside = (event) => {
          if (!ref?.current?.contains(event.target)) {
            setShowSuggestions(false);
          }
        };
        document.addEventListener("mousedown", handleClickOutside);
      }, [ref]);

    useEffect(()=> {
        setInput("")
    }, [modalParent])


    const onChange = (e) => {
        const userInput = e.target.value;
        const unLinked = suggestions.filter(
          (suggestion) =>
            suggestion.name.toLowerCase().indexOf(userInput.toLowerCase()) > -1
        );
        setInput(e.target.value);
        setFilteredSuggestions(unLinked);
        setActiveSuggestionIndex(0);
        setShowSuggestions(true);
      };
      const onClickSuggest = (e) => {
        setFilteredSuggestions([]);
        setValue(e)
        setInput(e.name);
        setActiveSuggestionIndex(0);
        setShowSuggestions(false);
      };

      const onClickDropDown = () => {
        setFilteredSuggestions(suggestions)
        setShowSuggestions(!showSuggestions)
      }

      const SuggestionsListComponent = ({showSuggestions}) => {
        return filteredSuggestions.length !== 0 ? (
          <ul className={`${showSuggestions ? "absolute" : "hidden"} w-full bg-white border-gray-200 border-2 overflow-y-auto max-h-48 rounded-md z-30 text-gray-700 pt-1`}>
            {filteredSuggestions.map((suggestion, index) => {
              let className;
              // Flag the active suggestion with a class
              if (index === activeSuggestionIndex) {
                className = "suggestion-active py-2 px-4 hover:bg-gray-200 cursor-pointer";
              } else { className = "py-2 px-4 hover:bg-gray-200 cursor-pointer"}
              return (
                <li className={className} key={suggestion.name} onClick={() => onClickSuggest(suggestion)}>
                  {suggestion.name}
                </li>
              );
            })}
          </ul>
        ) : (
          <div className={`${!showSuggestions && "hidden"} mt-2`}>
            <p className='font-quicksand text-oranye'>Nama bank tidak ditemukan, silahkan cari lagi</p>
          </div>
        );
      };
    return (
     <div ref={ref} className='relative'>
        <LabelText {...props} />
        <div className='flex realtive'>
            <input
                // ref={ref}
                type="text"
                onChange={onChange}
                // onKeyDown={onClick}
                placeholder="Ketik nama bank..."
                value={input}
                className={` w-full
                md:shadow order-7 appearance-none border  rounded-md bg-transparent md:p-4 p-3 text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline`}
            />
            <div className='absolute md:top-9 top-8 p-4 right-2 cursor-pointer' onClick={onClickDropDown}>
                <ChevronDownIcon />
            </div>
        </div>
        <div className='relative'>
            <SuggestionsListComponent showSuggestions={showSuggestions}/>
        </div>
     </div>
    )
}

export default InputComboBox