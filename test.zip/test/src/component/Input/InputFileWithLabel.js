import React, { useEffect, useRef } from 'react'
import SpinCircleLogo from '../../assets/animation/spin_circle_logo';
import { MUSIC_FILE_TYPE, VIDEO_FILE_TYPE } from '../../utils/constants/assetFileType';
import RoundedButton from '../Button/RoundedButton';
import ButtonText from '../Text/ButtonText';
import LabelText from '../Text/LabelText'
import SubLabelText from '../Text/SubLabelText';
import ReactAudioPlayer from 'react-audio-player';
import { Controller, useForm } from 'react-hook-form'
import ErrorFormText from '../Text/ErrorFormText';

const InputFileWithLabel = ({ name = "inputFile", required, height = "320px", leftLabel = false, defaultValue, ...props }) => {
    const { onChange,
        value,
        loading,
        width,
        textSublabel,
        className,
        labelConstraint = "PNG, GIF, JPEG. Max 20MB",
        accept,
        responsive,
        type
    } = props
    const newValue = value
    const { control } = useForm()
    const inputReference = useRef();
    const fileUploadAction = () => inputReference?.current?.click();
    const changeImg = () => {
        inputReference.current.click()
    }
    const videoRef = useRef();
    const previousUrl = useRef(value);

    useEffect(() => {
        if (previousUrl.current === value) {
            return;
        }

        if (videoRef.current) {
            videoRef.current.load();
        }

        previousUrl.current = value;
    }, [value]);

    return (
        <div className={`flex flex-col ${leftLabel ? "items-start" : "items-center"} ${className}`} style={{
            width: width
        }}>
            <Controller
                name={name}
                control={props?.control || control}
                rules={{
                    required
                }}
                defaultValue={defaultValue}
                render={({ field, fieldState: { error } }) => {
                    const { control, ...newField } = field
                    return (<>
                        <LabelText classstyle="self-start" {...props} />
                        {!!textSublabel && <SubLabelText classstyle="self-start mb-4 mt-1" tx={textSublabel} />}
                        <div style={responsive ? { height: "200px" } : { height: height }} className={`border-dashed ${error ? "border-red-500" : "border-abu_adad"} md:border-2 border ${!value ? "md:py-20 pb-10" : "py-0"} w-full flex flex-col rounded items-center ${!value ? "justify-end" : "justify-center"}`}>
                            <input
                                {...newField}
                                type="file"
                                hidden
                                ref={inputReference}
                                className={`my-4 hidden`}
                                onChange={(e) => {
                                    field.onChange(e)
                                    onChange && onChange(e)
                                }}
                                accept={accept}
                            />

                            {!newValue ?
                                <>
                                    <p className="font-quicksand text-sm leading-5 whitespace-pre-line text-center text-hitam_2 mb-4">
                                        {labelConstraint}
                                    </p>
                                    <RoundedButton onClick={fileUploadAction} color="transparent" className="border-hijau_hutan px-11 py-2 md:border-2 border w-max">
                                        <ButtonText color="text-hijau_hutan">
                                            Pilih File
                                        </ButtonText>
                                    </RoundedButton>
                                </> : loading ?
                                    <div className="flex flex-col items-center py-16">
                                        <SpinCircleLogo />
                                    </div> : newValue !== null ?
                                        // check file extension
                                        type === VIDEO_FILE_TYPE ?
                                            <video ref={videoRef} onClick={changeImg} className="object-cover cursor-pointer max-h-full max-w-full" autoPlay={true}>
                                                <source src={URL.createObjectURL(newValue)} type="video/mp4" />
                                            </video>
                                            :
                                            type === MUSIC_FILE_TYPE ?
                                                <div className='flex flex-col items-center'>
                                                    <RoundedButton onClick={changeImg} className="w-28 py-2 mb-4">
                                                        <ButtonText tx="Ubah File" />
                                                    </RoundedButton>
                                                    <ReactAudioPlayer
                                                        src={URL.createObjectURL(newValue)}
                                                        autoPlay={false}
                                                        controls
                                                    />
                                                </div>
                                                :
                                                <img src={newValue instanceof Blob ? URL.createObjectURL(newValue) : newValue} onClick={changeImg} className='rounded object-fill cursor-pointer max-h-full max-w-full ' alt='asset' />
                                        : <>
                                            <p className="font-quicksand text-xs text-hitam_2 mb-4">
                                                {labelConstraint}
                                            </p>
                                            <RoundedButton onClick={fileUploadAction} color="bg-transparent" className="border-hijau_hutan px-11 py-2 border-2 w-max">
                                                <ButtonText color="text-hijau_hutan">
                                                    Pilih File
                                                </ButtonText>
                                            </RoundedButton>
                                        </>

                            }
                        </div>
                        <ErrorFormText tx={error?.message} />
                    </>
                    )
                }}
            />
        </div>
    )
}

export default InputFileWithLabel