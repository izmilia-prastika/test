import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useController, useForm } from "react-hook-form";
import ErrorFormText from "../Text/ErrorFormText";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const InputSwitchWithLabel = ({
    name="inputSwitch",
    required,
    loading = false,
    ...props}) => {
    const { t } = useTranslation();
    const { label, tx, value, onClick,defaultChecked,onChange } = props
    const translatedText = tx && t(tx)
    const {control} = useForm()
    const { field, fieldState:{error} } = useController({
        control: props?.control || control,
        name,
        rules: { required }
    })
    useEffect(() => {
        field.onChange(value)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value])
    const showLabel = translatedText || label
    return (
        <label className="flex items-center justify-start cursor-pointer">
            <div className="mr-3 font-quicksand text-hitam font-bold md:text-base text-sm">
                {showLabel}
            </div>
            <div className="relative">
                <input type="checkbox" {...props} defaultChecked={defaultChecked} checked={value} onChange={onChange} onClick={onClick} id="toggleB" className="sr-only" />
                <div className="block dot-bg bg-gray-200 w-14 h-8 rounded-full"></div>
                <div className="dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition"></div>
            </div>
            {loading && <SpinCircleLogo customSpace="ml-3"/>}
            <ErrorFormText tx={error?.message} />
        </label>
    )
}

export default InputSwitchWithLabel