import React, { useCallback } from "react"
import ReactTags from "react-tag-autocomplete"
import { Controller } from 'react-hook-form'
import ErrorFormText from "../Text/ErrorFormText"

const InputTags = ({
    className,
    onDelete,
    onAddition,
    tags,
    name,
    control,
    required,
    ...props }) => {

    const onDeleteTags = useCallback((tagIndex, onChange) => {
        onChange(tags.filter((_, i) => i !== tagIndex))
        onDelete(tagIndex)
    }, [tags])

    const onAdditionTags = useCallback((newTag, onChange) => {
        onChange([...tags, newTag])
        onAddition(newTag)
    }, [tags])

    return (
        <Controller
            name={name}
            control={control || []}
            rules={{ required }}
            render={({ field, fieldState: { error } }) =>
                <div className={`${error && "error"} w-full flex flex-col`}>
                    <ReactTags
                        className={`
            md:shadow order-7 appearance-none border ${error && "error"} rounded-md bg-transparent p-4  text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline
            ${className}`}
                        onDelete={(tagIndex) => onDeleteTags(tagIndex, field.onChange)}
                        onAddition={(newTag) => onAdditionTags(newTag, field.onChange)}
                        tags={tags}
                        {...props} />
                    <ErrorFormText tx={error?.message} />
                </div>
            }
        />
    )
}

export default InputTags