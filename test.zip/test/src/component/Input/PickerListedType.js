import React from "react";
import { AuctionLogo, PriceTagLogo } from "../../assets";
import { AUCTION, FIX_PRICE } from "../../utils/constants/listedType";
import { Controller, useForm } from 'react-hook-form'
import ErrorFormText from "../Text/ErrorFormText";

const PickerListedType = ({ onChange, value, className, name, required, ...props }) => {
    const isAuction = value === AUCTION
    const { control } = useForm()
    return (
        <Controller
            name={name}
            control={props?.control || control}
            rules={required}
            render={({ field, fieldState: { error } }) =>
                <div className={`grid grid-flow-col gap-4 self-start ${className}`}>
                    <div onClick={() => {
                        field.onChange(FIX_PRICE)
                        onChange(FIX_PRICE)
                    }} className={`rounded-xl shadow-md ${onChange && "cursor-pointer"}`}>
                        <div className={`${isAuction ? "inactive-picker-background" : "bg-hijau_kristal"} rounded-t-xl px-8 py-4`}>
                            <div className="w-12 h-12 circle-picker-background items-center justify-center rounded-full ">
                                <PriceTagLogo className="self-center items-center align-middle h-full w-full flex justify-center" />
                            </div>
                        </div>
                        <div className="p-4">
                            <p className="font-quicksand font-normal text-sm text-hitam text-center">
                                Harga Tetap
                            </p>
                        </div>
                    </div>
                    <div onClick={() => {
                        field.onChange(AUCTION)
                        onChange(AUCTION)
                    }} className={`rounded-xl shadow-md ${onChange && "cursor-pointer"}`}>
                        <div className={`rounded-b-none rounded-t-xl ${isAuction ? "bg-hijau_kristal" : "inactive-picker-background"} px-8 py-4`}>
                            <div className="w-12 h-12 circle-picker-background items-center justify-center rounded-full ">
                                <AuctionLogo className="self-center items-center align-middle h-full w-full flex justify-center" />
                            </div>
                        </div>
                        <div className="p-4">
                            <p className="font-quicksand font-normal text-sm text-hitam text-center">
                                Lelang
                            </p>
                        </div>
                    </div>
                    <ErrorFormText tx={error?.message} />
                </div>
            }
        />
    )
}

export default PickerListedType