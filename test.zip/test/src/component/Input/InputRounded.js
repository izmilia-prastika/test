import classNames from 'classnames'
import React from 'react'

const InputRounded = ({className, appendleft, inputstyle, placeholder, customAppendLeft = "top-3", ...props }) => {
    return (
        <div className={`dropdown inline-block relative ${className}`} >
            {appendleft &&
                <div className={`absolute ${customAppendLeft} left-5`} >
                    {appendleft}
                </div>
            }
            <input
                {...props}
                placeholder={placeholder}
                className={`w-full text-black rounded-3xl font-semibold bg-transparent
            ${classNames({
                    "py-2": !inputstyle?.includes('py'),
                    "px-10": !inputstyle?.includes('px'),
                    "border border-gray-300":!inputstyle?.includes('border'),
                })}
             inline-flex items-center
             ${inputstyle}
            `}>
            </input>
        </div >
    )
}

export default InputRounded