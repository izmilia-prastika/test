import classNames from "classnames";
import React from "react";

const Input = (props) => {
    const { className, appendleft, customPositionIcon="top-2.5"} = props
    return (
        <div className="inline-block relative 2xl:w-72 lg:w-48 w-full">
            {appendleft &&
                // <div className="absolute left-3 top-3">
                <div className={`absolute left-3 ${customPositionIcon}`}>
                    {appendleft}
                </div>
                // </div>
            }
            <input {...props} className={`${className} w-full p-4 ${classNames({
                'shadow appearance-none border border-gray-200 focus:border-oranye rounded-md': !className?.includes('border-'),
                'pl-16': appendleft && !className?.includes('pl-')
            })}`} />
        </div>
    )
}

export default Input