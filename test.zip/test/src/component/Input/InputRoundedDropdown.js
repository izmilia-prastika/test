import React, { useEffect, useRef, useState, useContext } from "react";
import {
  CheckboxChecklistLogoImg,
  CheckboxEmptyLogoImg,
  EmptyState,
  MagnifierLogoImg,
} from "../../assets";
// import LabelText from "../Text/LabelText";
import InputRounded from "./InputRounded";
import PropTypes from "prop-types";
// import { values } from "lodash";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ModalDropdown from "../Modal/ModalDropdown";
import ModalTitleText from "../Text/ModalTitleText";
import classNames from "classnames";
// import CircleChecklistIcon from "../../assets/icon/circle_checklist_icon";
import ChecklistNonCircle from "../../assets/icon/checklist_non_circle_icon";
import CloseIcon from "../../assets/icon/close_icon";
import SortIcon from "../../assets/icon/sort_icon";

const EmptyStateDropDown = () => {
  return (
    <div className="p-4 justify-center items-center flex flex-col">
        <img alt="no data" className="h-24 w-24" src={EmptyState}/>
        <p className="font-quicksand">Maaf, data belum tersedia</p>
    </div>
  )
}

const InputRoundedDropdown = (props) => {
  const {
    className,
    searchAble,
    selected,
    onChange,
    value,
    data,
    initValue,
    multi,
    setGetAgain
  } = props;
  const [show, setShow] = useState(false);
  const onChangeInput = (e) => onChange(e);
  const [searchInput, setSearchInput] = useState("");
  const [sortSelected, setSortSelected] = useState("");
  const responsive = useContext(ResponsiveContext);
  const isSort = props.placeholder === "Sort By";
  const isSortResponsive = responsive && isSort
  const ref = useRef();
  const listRef = useRef()
  // const data = []
  const isShowSearch = searchAble && data?.length > 0 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!ref?.current?.contains(event.target)) {
        setShow(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
  }, [ref]);
  
  const handleScroll = () => {
    if (listRef?.current) {
        const { scrollTop, scrollHeight, clientHeight } = listRef?.current;
        console.log('zap scroll',scrollTop, scrollHeight, clientHeight);
        if (Math.ceil(scrollTop) + Math.ceil(clientHeight) >= scrollHeight) {
            setGetAgain(true);
            // console.log('WADU')
        } 
    }
};
  return (
    <div ref={ref} className={`inline-block relative ${className}`}>
      <button
        onClick={() => setShow(!show)}
        className={`md:text-base text-xs w-full ${multi && selected.length !== 0 ? "text-white bg-hitam" : "md:text-hitam_2 text-gray-600 bg-transparent"}  rounded-3xl font-quicksand md:font-semibold font-medium inline-flex items-center justify-between ${!isSortResponsive ? "md:border-1.5 border md:border-gray-300 border-gray-400 py-2 px-4" : "p-1"}`}
      >
        {isSortResponsive ? (
          <div>
            <SortIcon />
          </div>
        ) : multi ? (
          <div className="inline-flex">
            <span className="mr-1 line-clamp-1">{props?.placeholder}</span>
            {selected.length !== 0 && (
              <span className="self-center text-xs">({selected.length})</span>
            )}
          </div>
        ) : (
          <span className="mr-1 line-clamp-1">{value?.name ?? props?.placeholder}</span>
        )}
        {!isSortResponsive && (
          <svg
            className="fill-current h-4 w-4"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />{" "}
          </svg>
        )}
      </button>
      {!responsive ? (
        <ul
        onScroll={handleScroll} ref={listRef}
          className={`absolute ${
            !show && "hidden"
          } rounded-dropdown-styling overflow-y-auto w-72 max-h-96 z-50 text-gray-700 py-4 mt-4`}
        > 
          { isShowSearch && (
            <li className="bg-white pb-2 px-4">
              <InputRounded
                inputstyle="border-0 bg-abu"
                onChange={(e) => setSearchInput(e.target.value)}
                appendleft={<MagnifierLogoImg />}
                placeholder="Cari disini..."
              />
            </li>
          )}
          {initValue && (
            <li
              className="bg-white hover:bg-gray-200 px-6 font-quicksand py-2 font-medium"
              onClick={() => props?.setValue(null)}
            >
              {initValue}
            </li>
          )}
          {data?.length > 0 ? data
            ?.filter((data) =>
              searchInput.toLocaleLowerCase() !== ""
                ? data.name
                    .toLocaleLowerCase()
                    .includes(searchInput.toLocaleLowerCase())
                : true
            )
            ?.map((data, key) =>
              multi ? (
                <li
                  key={key}
                  className="flex flex-row w-full bg-white items-center cursor-pointer py-2 px-8"
                  onClick={() => onChangeInput(data)}
                >
                  {selected?.includes(data.value) ? (
                    <CheckboxChecklistLogoImg />
                  ) : (
                    <CheckboxEmptyLogoImg />
                  )}
                  <p className="rounded-t bg-white ml-2 block whitespace-no-wrap font-quicksand hover:text-hijau_hutan">
                    {data.name}
                  </p>
                </li>
              ) : (
                <li
                  key={key}
                  onClick={() => {props?.setValue(data); !multi && setShow(false)}}
                  className="bg-white hover:bg-gray-200 px-6"
                >
                  <p className="rounded-t py-2 cursor-pointer block whitespace-no-wrap font-quicksand">
                    {data.name}
                  </p>
                </li>
              ) 
            ) : <EmptyStateDropDown />}
        </ul>
      ) : (
        <ModalDropdown show={show} setShow={setShow} responsive={responsive}>
          <div className="w-full pb-4">
            <div>
              <div className="flex items-center w-full justify-end">
                <CloseIcon
                  size={4}
                  viewBox={20}
                  onClick={() => setShow(!show)}
                />
              </div>
              <div className="flex items-start w-full justify-center">
                <ModalTitleText
                  tx={props.placeholder}
                  classstyle="mb-4 text-base"
                />
              </div>
              {searchAble && (
                <InputRounded
                  placeholder={`Cari`}
                  className="w-full"
                  inputstyle="border-0 bg-abu mb-2"
                  onChange={(e) => setSearchInput(e.target.value)}
                  appendleft={<MagnifierLogoImg />}
                />
              )}
            </div>
            <div onScroll={handleScroll} ref={listRef} className="overflow-y-auto  pb-4" style={{ maxHeight: "240px" }}>
              {initValue && (
                //<li className="flex flex-row w-full bg-white items-center cursor-pointer py-2 " onClick={() => props?.setValue(null)}>{initValue}</li>
                <li
                  className="bg-white hover:bg-gray-200 px-6"
                  onClick={() => props?.setValue(null)}
                >
                  <div
                    className={classNames(
                      "h-12 shadow-md w-full rounded-md border flex items-center justify-between pr-4"
                    )}
                  >
                    <p
                      className={classNames(
                        "rounded-t bg-white text-sm ml-2 text-gray-600 font-quicksand block whitespace-no-wrap pl-2"
                      )}
                    >
                      {initValue}
                    </p>
                  </div>
                </li>
              )}
              {data
                ?.filter((data) =>
                  searchInput.toLocaleLowerCase() !== ""
                    ? data.name
                        .toLocaleLowerCase()
                        .includes(searchInput.toLocaleLowerCase())
                    : true
                )
                ?.map((data, key) => {
                  const isSelected = selected?.includes(data.value);
                  const isSortSelected = sortSelected === data.name;
                  return multi ? (
                    <li
                      key={key}
                      className="flex flex-row w-full bg-white items-center cursor-pointer py-2 "
                      onClick={() => onChangeInput(data)}
                    >
                      <div
                        className={classNames(
                          "h-12 shadow-md w-full rounded-md border flex items-center justify-between pr-4",
                          { "border-hijau_hutan": isSelected }
                        )}
                      >
                        <p
                          className={classNames(
                            "rounded-t bg-white text-sm ml-2 text-gray-600 font-quicksand block whitespace-no-wrap pl-2",
                            { "text-hijau_hutan": isSelected }
                          )}
                        >
                          {data.name}
                        </p>
                        {isSelected && <ChecklistNonCircle />}
                      </div>
                    </li>
                  ) : (
                    <li
                      key={key}
                      onClick={() => {
                        props?.setValue(data);
                        setSortSelected(data.name);
                      }}
                      className="flex flex-row w-full bg-white items-center cursor-pointer py-2"
                    >
                      <div
                        className={classNames(
                          "h-12 shadow-md w-full rounded-md border flex items-center justify-between pr-4",
                          { "border-hijau_hutan": isSortSelected }
                        )}
                      >
                        <p
                          className={classNames(
                            "rounded-t bg-white text-sm ml-2 text-gray-600 font-quicksand block whitespace-no-wrap pl-2",
                            { "text-hijau_hutan": isSortSelected }
                          )}
                        >
                          {data.name}
                        </p>
                        {isSortSelected && <ChecklistNonCircle />}
                      </div>
                    </li>
                  );
                })}
            </div>
          </div>
        </ModalDropdown>
      )}
    </div>
  );
};

InputRoundedDropdown.propTypes = {
  searchAble: PropTypes.bool,
  selected: PropTypes.array,
};

InputRoundedDropdown.defaultProps = {
  searchAble: false,
  selected: [],
};
export default InputRoundedDropdown;
