import React, { lazy, useContext, useRef, useState, useEffect } from "react";
import PropTypes from "prop-types";
import { Slider } from "primereact/slider";
import InputNumberRounded from "./InputNumberRounded";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ModalDropdown from "../Modal/ModalDropdown";
import ModalTitleText from "../Text/ModalTitleText";
import CloseIcon from "../../assets/icon/close_icon";
import { MaticTokenIcon } from "../../assets";
// import { useClickOutside } from "../../hooks/useClickOutside";

const RoundedButton = lazy(() =>
  import("../../component/Button/RoundedButton")
);
const ButtonText = lazy(() => import("../../component/Text/ButtonText"));

const InputRoundedSliderDropdown = (props) => {
  const { className, onChange, value, setValue, handleApplyButton, onSlideEnd, priceBoundary } = props;
  const [show, setShow] = useState(false);
  const ref = useRef();
  // useClickOutside(ref, show, setShow);

  const onChangeData = (e) => {
    onChange(e);
  };

  const handleToggle = () => {
    setShow(!show)
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!ref?.current?.contains(event.target)) {
        setShow(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
  }, [ref]);

  const Responsive = useContext(ResponsiveContext);
  return (
    <div className={` inline-block relative ${className}`} ref={ref}>
      <button
        onClick={handleToggle}
        className="md:text-base text-xs w-full md:text-hitam_2 text-gray-600 rounded-3xl md:border-1.5 border md:border-gray-300 border-gray-400 font-quicksand md:font-semibold font-medium py-2 px-4 inline-flex items-center  justify-between"
      >
        <span className="mr-1">{value?.name ?? props?.placeholder}</span>
        <svg
          className="fill-current h-4 w-4"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
        >
          <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />{" "}
        </svg>
      </button>
      {!Responsive ? (
        <ul
          ref={ref}
          className={`rounded-dropdown-styling absolute ${!show && "hidden"
            } mt-4 z-30 text-gray-700 pt-1 `}
        >
          <div className="flex flex-col rounded-lg bg-white items-center py-5 px-6 ">
            <Slider
              value={value}
              onChange={(e) => onChangeData(e.value)}
              min={priceBoundary[0]}
              max={priceBoundary[1]}
              onSlideEnd={onSlideEnd}
              range
              className="w-72 mb-"
            />
            <div className="flex flex-row justify-between w-full mt-4 items-center">
              {/* <div className='bg-gray-200 rounded-full justify-center'>
                            <p className='font-quicksand text-sm text-hitam_2 text-center py-2'> {value[0]}</p>
                        </div>
                        <div className='bg-gray-200 rounded-full justify-center'>
                            <p className='font-quicksand text-sm text-hitam_2 text-center py-2'> {value[1]}</p>
                        </div> */}

              <InputNumberRounded
                value={value[0]}
                thousandSeparator={true}
                onValueChange={(values) => {
                  const { value } = values;
                  setValue((prop) => [value, prop[1]]);
                }}
              />
              <img src={MaticTokenIcon} className="h-6 w-6" alt=""/>
              <InputNumberRounded
                value={value[1]}
                thousandSeparator={true}
                onValueChange={(values) => {
                  const { value } = values;
                  // console.log('zap',value);
                  setValue((prop) => [prop[0], value]);
                }}
              />
            </div>
            <div className="flex flex-row w-full justify-center">
              <RoundedButton
                onClick={(e) => {
                  setShow(false);
                  handleApplyButton();
                }}
                className="md:px-6 px-0 mt-5 py-3 md:w-auto w-full"
              >
                <ButtonText classstyle="text-sm font-bold" tx="Terapkan" />
              </RoundedButton>
            </div>
          </div>
        </ul>
      ) : (
        <ModalDropdown show={show} setShow={setShow} responsive={Responsive}>
          <div className="flex flex-col bg-white items-center w-full">
            <div className="flex items-start w-full justify-between mb-4">
              <ModalTitleText
                tx={props.placeholder}
                classstyle="mb-4 text-base"
              />
              <CloseIcon size={6} viewBox={24} onClick={() => setShow(!show)} />
            </div>
            <Slider
              value={value}
              onChange={(e) => onChangeData(e.value)}
              range
              className="w-72 mb-"
            />
            <div className="flex flex-row justify-between w-full mt-8">
              <InputNumberRounded
                value={value[0]}
                thousandSeparator={true}
                onValueChange={(values) => {
                  const { value } = values;
                  setValue((prop) => [value, prop[1]]);
                }}
              />
              <InputNumberRounded
                value={value[1]}
                thousandSeparator={true}
                onValueChange={(values) => {
                  const { value } = values;
                  setValue((prop) => [prop[0], value]);
                }}
              />
            </div>
            <div className="flex flex-row w-full justify-end">
              <RoundedButton
                onClick={(e) => {
                  setShow(false);
                  handleApplyButton();
                }}
                className="md:px-5 px-0 mt-5 py-3 md:w-auto w-full"
              >
                <ButtonText classstyle="text-sm font-bold" tx="Terapkan" />
              </RoundedButton>
            </div>
          </div>
        </ModalDropdown>
      )}
    </div>
  );
};

InputRoundedSliderDropdown.propTypes = {
  searchAble: PropTypes.bool,
  selected: PropTypes.bool,
};

InputRoundedSliderDropdown.defaultProps = {
  searchAble: false,
  selected: false,
};
export default InputRoundedSliderDropdown;
