import React from "react";
import { CheckboxChecklistLogoImg, CheckboxEmptyLogoImg } from "../../assets";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const ChecklistInput = ({ setValue, value = false, otherProces, loading = false, ...props }) => {
    const handleCheck = () => setValue(!value)
    return (
        <div {...props} onClick={otherProces ? otherProces : handleCheck}>
            { !loading ? value ?
                <CheckboxChecklistLogoImg />
                    :
                <CheckboxEmptyLogoImg />
            : <SpinCircleLogo customSpace="-mr-2"/>
            }
        </div>
    )
}


export default ChecklistInput