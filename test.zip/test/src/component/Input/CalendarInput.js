import React, { useEffect } from 'react'
import { Calendar } from 'primereact/calendar';
import { useController, useForm } from "react-hook-form";

const CalendarInput = ({
    name="calendarInput",
    required,
    className,...props}) => {
    const {value} = props
    const { control } = useForm()
    const { field, fieldState: { error } } = useController({
        control: props?.control || control,
        name,
        rules: { required }
    })
    
    useEffect(() => {
        field.onChange(value)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value])

    return (
        <Calendar {...props} inputClassName={`md:shadow appearance-none border  rounded-md bg-transparent md:p-4 p-3 text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline
        ${className}  ${error ? "border-red-500" : "border-gray-200"}`} className={`w-full flex`} id="time24" showTime showSeconds />
    )
}

export default CalendarInput