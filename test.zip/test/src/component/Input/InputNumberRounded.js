import React from "react";
import NumberFormat from "react-number-format";

const InputNumberRounded = ({ className, ...props }) => {
    return (
        <div className={className} >
            <NumberFormat
                className='md:bg-white bg-gray-100 border w-28 md:border-gray-300 border-gray-100 rounded-full justify-center font-quicksand text-sm text-hitam_2 text-center py-2 leading-tight focus:outline-none focus:shadow-outline'
                {...props}
            />
        </div>
    )
}
export default InputNumberRounded