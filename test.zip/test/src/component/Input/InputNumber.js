import React, { useContext } from "react";
import NumberFormat from "react-number-format";
import { MaticTokenIcon } from "../../assets";
import socketContext from "../../context/Socket/socketContext";
import { Controller } from 'react-hook-form'
import ErrorFormText from "../Text/ErrorFormText";
import classNames from "classnames";

const InputNumber = ({ name, register, control, required, className, showIdr = true, onValueChange, classIdr, ...props }) => {
    const SocketContext = useContext(socketContext)
    const { matic_price } = SocketContext
    return (
        <Controller

            name={name}
            control={control || []}
            rules={{ required }}
            render={({ field, fieldState: { error } }) =>
                <div className={className} >
                    <NumberFormat
                        className={`md:shadow appearance-none border ${error?.type ? "border-red-500" : "border-gray-200"} rounded-md w-full px-4 md:py-4 py-2 h-full text-gray-700 mt-2 leading-tight focus:outline-none focus:shadow-outline`}
                        {...props} onValueChange={(values) => {
                            const { value } = values;
                            const number = parseFloat(value)
                            field.onChange(number)
                            console.log('zap input number', number);
                            onValueChange(values)
                        }}
                    />
                    {
                        showIdr &&
                        <div className={`absolute flex right-0 bg-gray-100 h-full top-2 border-t-2 md:pl-5 pl-3 md:pt-0 -pt-1 rounded-r-lg
                            ${classNames({
                            "w-38 md:w-6/12": !classIdr?.includes("w-")
                        })}${classIdr}`}>
                        <div className="absolute md:top-1.5 top-0 md:-left-12 -left-8">
                            <div className=' h-full bg-white md:w-8 w-6 py-2 left-0 items-center justify-end'>
                                <img src={MaticTokenIcon} className='md:h-8 md:w-8 w-6' alt="matic token" />
                            </div>
                        </div>
                            {/* <img src={MaticTokenIcon} className='h-full w-32' /> */}
                            <NumberFormat value={Math.ceil(parseFloat(props?.value) * matic_price)} displayType={'text'} thousandSeparator={true}
                                renderText={(value, props) => <div className='flex w-full items-center justify-end'>
                                    <p className='pr-4 w-full font-quicksand font-bold text-right text-hitam md:text-base text-xs'>( IDR {value} )</p>
                                </div>
                                }
                            />
                        </div>
                    }
                    <ErrorFormText tx={error?.message} />
                </div>
            }
        />
    )
}
export default InputNumber