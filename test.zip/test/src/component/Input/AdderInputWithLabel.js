import React from "react";
import GroupLabelForm from "../Form/GroupLabelForm";
import ErrorFormText from "../Text/ErrorFormText";
import AdderInput from "./AdderInput";

const AdderInputWithLabel = ({ errors, ...props }) => {
    return (
        <GroupLabelForm
            {...props}
        >
            <AdderInput
                {...props}
            />
            <ErrorFormText tx={errors?.[props?.name]&& (errors?.[props?.name]?.message )} />
        </GroupLabelForm>
    )
}

export default AdderInputWithLabel