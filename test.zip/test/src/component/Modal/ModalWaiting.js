import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo"
import { useContext} from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
// import RoundedButton from "../Button/RoundedButton";
// import ButtonText from "../Text/ButtonText";
import ButtonModal from "./ButtonModal";
import P from './P';
import InfoIcon from "../../assets/icon/info_icon";

const ModalWaiting = ({loading, invoiceUrl, text, textButton, title, showButton, ...props}) => {
  const responsive = useContext(ResponsiveContext)
  let showInvoice
  if(invoiceUrl !== null){
      showInvoice = true
  } else {
    showInvoice = false
  }
  const handleInvoice = () => {
    window.open(invoiceUrl, '_blank', 'noopener,noreferrer')
  }

  return (
    <Modal backdrop={false} responsive={responsive} {...props} >
      <CardModal>
        <ModalTitleText text={title === null ? "Menunggu Pembayaran" : title} />
        <SpinCircleLogo type="big"/>
        <P fontSize="md:text-lg text-base">
          {text === null ? "Harap lakukan proses pembayaran pada tab invoice yang baru saja terbuka. Jika sudah selesai, anda akan dialihkan pada proses berikutnya" : text}
        </P>
        {showInvoice &&<div className="p-5 bg-gray-100 w-full rounded-lg mb-6">
        <div className="flex">
              <InfoIcon className="self-start mr-2" />
               <p className="font-quicksand text-base font-medium text-hitam">
                Jika halaman invoice tidak terbuka, silahkan{" "}
                <span
                  className="cursor-pointer text-hijau_hutan underline hover:text-hijau_muda"
                  onClick={handleInvoice}
                >
                  Klik Disini
                </span>
              </p>
            </div>
          </div>}
        {showButton && <ButtonModal buttonStyle={`${!loading ? "bg-hijau_hutan" : "bg-hijau_kristal"} py-4 md:w-1/2 w-full mt-4`} onClick={()=>props?.setShow(false)} tx={textButton ? textButton : "Menunggu Pembayaran"} disabled={loading} children={loading && <SpinCircleLogo />} buttonTextSyle={loading && "mr-4"}/>}
      </CardModal>
    </Modal>
  );
};

ModalWaiting.defaultProps = {
  text: "Harap lakukan proses pembayaran pada tab invoice yang baru saja terbuka. Jika sudah selesai, anda akan dialihkan pada proses berikutnya",
  title: "Menunggu Pembayaran",
  showButton: true,
}

export default ModalWaiting;
