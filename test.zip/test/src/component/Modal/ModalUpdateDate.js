import React, { useCallback, useContext, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import assetContext from "../../context/Asset/assetContext";
import authContext from "../../context/Auth/authContext";
import collectionContext from "../../context/Collection/collectionContext";
import { ASSET_PATHNAME } from "../../utils/constants/domainTypes";
import { WEB_HOST } from "../../utils/helper";
import ButtonLink from "../Button/ButtonLink";
import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
import CalendarInputWithLabel from "../Input/CalendarInputWithLabel";
import InputDropdownWithLabel from "../Input/InputDropdownWithLabel";
import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import TextLink from "../Text/TextLink";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";

const ModalUpdateDate = ({ show, setShow, onSubmit ,loading}) => {
    const { control} = useForm()
    const [date,setDate] = useState()
    const handleSubmit = () => {
        onSubmit(date)
    }
    return (
        <Modal backdrop={false} disablePropagation={true} show={show} setShow={setShow}>
            <CardModal>
                <ModalTitleText tx={"Ubah Durasi Lelang Aset"} />

                <CalendarInputWithLabel
                        control={control}
                        name="duration"
                        value={date}
                        onChange={e => setDate(e.target.value)}
                        className="w-full mb-4"
                        minDate={new Date()}
                        showIcon
                        tx='marketplace.createNft.duration'
                    />
                <ButtonModal
                    disabled={loading}
                    type={"confirmation"}
                    onNoClick={() => setShow(false)}
                    onOkClick={handleSubmit}
                    okLabel={loading ? "Loading ..." : "Ubah"}
                    noLabel="Tutup"
                />
            </CardModal>

        </Modal>
    )
}

export default ModalUpdateDate