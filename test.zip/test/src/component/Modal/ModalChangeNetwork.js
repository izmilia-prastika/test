import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
// import RoundedButton from "../Button/RoundedButton";
// import ButtonText from "../Text/ButtonText";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import P from "./P";

import {
  POLYGON_MAINNET,
  POLYGON_MUMBAI,
  ETHEREUM_RINKEBY
} from "../../utils/constants/metamaskConfig";
import env from "../../config/env";
import ButtonModal from "./ButtonModal";
import ExclamationIcon from "../../assets/icon/exclamation_icon";

const ModalChangeNetwork = (props) => {
  const changeNetwork = async () => {
    const ethereum = window.ethereum;
    let mumbaiChainId, chainName, nativeCurrency, rpcUrls, blockExplorerUrls

    if (env.NETWORK_NAME === "polygon") {
      mumbaiChainId = POLYGON_MAINNET.chainId
      chainName = POLYGON_MAINNET.chainName
      nativeCurrency = POLYGON_MAINNET.nativeCurrency
      rpcUrls = POLYGON_MAINNET.rpcUrl
      blockExplorerUrls = POLYGON_MAINNET.blockExplorerUrl
    } else if (env.NETWORK_NAME === "mumbai") {
      mumbaiChainId = POLYGON_MUMBAI.chainId
      chainName = POLYGON_MUMBAI.chainName
      nativeCurrency = POLYGON_MUMBAI.nativeCurrency
      rpcUrls = POLYGON_MUMBAI.rpcUrl
      blockExplorerUrls = POLYGON_MUMBAI.blockExplorerUrl
    } else if (env.NETWORK_NAME === "rinkeby") {
      mumbaiChainId = ETHEREUM_RINKEBY.chainId
      chainName = ETHEREUM_RINKEBY.chainName
      nativeCurrency = ETHEREUM_RINKEBY.nativeCurrency
      rpcUrls = ETHEREUM_RINKEBY.rpcUrl
      blockExplorerUrls = ETHEREUM_RINKEBY.blockExplorerUrl
    }
    const data = [
      {
        chainId: "0x" + mumbaiChainId.toString(16),
        chainName,
        nativeCurrency,
        rpcUrls,
        blockExplorerUrls,
      },
    ];
    // let switchTx;
    // https://docs.metamask.io/guide/rpc-api.html#other-rpc-methods
    try {
      /* switchTx = */ await ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: data[0].chainId }],
      });
    } catch (switchError) {
      // not checking specific error code, because maybe we're not using MetaMask
      try {
        /* switchTx = */ await ethereum.request({
          method: "wallet_addEthereumChain",
          params: data,
        });
      } catch (addError) {
        // handle "add" error
      }
    }
  };

  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText text="Ubah Jaringan" />
        <ExclamationIcon width="100" height="100" />
        <P>
          Jaringan yang sedang terhubung dengan anda saat ini salah. Harap tekan
          tombol dibawah ini untuk mengganti jaringan yang kami dukung yaitu
          Polygon
        </P>
        <ButtonModal onClick={changeNetwork} tx="Ubah Jaringan" />
      </CardModal>
    </Modal>
  );
};

export default ModalChangeNetwork;
