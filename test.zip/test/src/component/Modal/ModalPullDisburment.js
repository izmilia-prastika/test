import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import P from './P';
import ButtonModal from "./ButtonModal";

const ModalPullDisburment = ({
  title = "Apakah anda yakin untuk membatalkan penjualan ini?",
  ...props
}) => {
  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx="Konfirmasi Penarikan Dana" />
        <P>{title}</P>
        <ButtonModal
          okLabel="Tarik Dana"
          noLabel="Tidak"
          type="confirmation"
          onNoClick={() => props.setShow(false)}
          onOkClick={props?.onSubmit}
        />
      </CardModal>
    </Modal>
  );
};

export default ModalPullDisburment;
