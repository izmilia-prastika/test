import React from "react";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import CloseIcon from "../../assets/icon/close_icon";

import P from "./P";
import ButtonModal from "./ButtonModal";

const ModalPickGasFeePayment = ({ onClickFiat, onClickCrypto, ...props }) => {
  const { responsive, setShow } = props;


  return (
    <Modal {...props}>
      <CardModal>
        {responsive && (
          <div className="w-full justify-end flex mb-4">
            <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />
          </div>
        )}
        <ModalTitleText tx="Pilih Pembayaran Gas Fee" />
        <P fontSize="md:text-lg text-base md:mt-0 -mt-3">
            Anda harus membayar Gas Fee saat melakukan transaksi ke blockhain. 
            Pilih salah satu jenis pembayaran dibawah ini
        </P>
        <div className="grid md:grid-cols-2 grid-cols-1 md:gap-4 gap-2 w-full">
          <ButtonModal onClick={onClickCrypto} tx="Bayar dengan MATIC" />
          <ButtonModal onClick={onClickFiat} tx="Bayar dengan Rupiah" />
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalPickGasFeePayment;
