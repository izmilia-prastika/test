import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import { useContext } from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ButtonModal from "./ButtonModal";
import P from './P';

const ModalInfoBank = ({isFinalSuccess, isEdit, handleTryAgain, ...props}) => {
  const responsive = useContext(ResponsiveContext)
  let title
  let info
  if(isEdit){
    if(isFinalSuccess){
      title = "Ubah Bank Berhasil"
      info = "Proses pengubahan akun rekening bank anda berhasil, silahkan tekan tombol tutup"
    } else {
      title = "Ubah Bank Gagal"
      info = "Proses pengubahan akun rekening bank anda tidak berhasil. Hal ini terjadi karena terdapat kesalahan pada blochain, silahkan ulangi proses"
    }
  } else {
    if(isFinalSuccess){
      title = "Tambah Bank Berhasil"
      info = "Proses penambahan akun rekening bank anda berhasil, silahkan tekan tombol tutup"
    } else {
      title = "Tambah Bank Gagal"
      info = "Proses penambahan akun rekening bank anda tidak berhasil. Hal ini terjadi karena terdapat kesalahan pada blochain, silahkan ulangi proses"
    }
  }

  const handleClick = () => {
      props?.setShow(false)
  }

  const handleTryTryAgain = () => {
    handleClick()
    handleTryAgain()
  }



  return (
    <Modal responsive={responsive} {...props} >
      <CardModal>
        <ModalTitleText text={title} />
        <P className="-mt-0" fontSize="md:text-lg text-base">
          {info}
        </P>
        <div className={`grid ${isFinalSuccess ? "grid-cols-1 w-1/2" : "grid-cols-2 w-4/5 gap-x-4"}`}>
          <ButtonModal buttonStyle="py-4 w-full mt-4 border border-hijau_hutan" buttonTextSyle={`${isFinalSuccess ? "text-white" : "text-hijau_hutan"}`} color={`${isFinalSuccess ? "bg-hijau_hutan" : "bg-white"}`} onClick={handleClick} tx={"Tutup"} />
          {!isFinalSuccess && <ButtonModal buttonStyle="py-4 w-full mt-4 border border-hijau_hutan" buttonTextSyle={`text-white`} color="bg-hijau_hutan" onClick={handleTryTryAgain} tx={"Ulangi"} />}
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalInfoBank;
