import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";
import P from "./P";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const ModalCantContinue = ({
  title = "Transaksi Tidak Dapat Dilanjutkan",
  isAmountCause,
  isOwnerCause,
  loading,
  handleClose,
  ...props
}) => {
  let subTitle
  if(isAmountCause){
      subTitle = "Transaksi ini tidak dapat dilanjutkan karena jumlah pembelian serial melebihi kapasitas serial yang dapat dibeli"
  } else {
     subTitle = "Transaksi ini tidak dapat dilanjutkan karena pemilik asset sudah berpindah tangan. Anda dapat menekan tombol tutup, transaksi tertunda ini akan menghilang secara otomatis"
  }
  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx={title} />
        {props?.loading && <SpinCircleLogo type={"big"}/>}
        <P>{subTitle}</P>
        <div className="grid grid-cols-1 w-1/2">
          <ButtonModal 
          disabled={loading} 
          buttonStyle={`${!loading ? "bg-hijau_hutan" : "bg-hijau_kristal"} py-4 w-full mt-4`}
          buttonTextSyle={loading && "mr-4"}
          onClick={handleClose} 
          tx={"Tutup"} 
          children={loading && <SpinCircleLogo />}
          />
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalCantContinue;
