import React from "react";

import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
// import ButtonLink from "../Button/ButtonLink";

function ButtonModal({
  type,
  okLabel = "Hapus",
  noLabel = "Tidak",
  onNoClick = () => {},
  onOkClick = () => {},
  buttonTextSyle = "",
  buttonStyle = "px-10 py-4 w-auto",
  onClick,
  tx,
  children,
  setShow = () => {},
  ...rest
}) {
  if (type === "confirmation") {
    return (
      <div className="flex flex-row gap-x-4 self-center">
        {/* <ButtonLink onClick={onNoClick}>
          <ButtonText tx={noLabel} color="hitam" />
        </ButtonLink> */}
        <RoundedButton {...rest} onClick={onNoClick} className={`border ${rest?.disabled ? "border-transparent" : "border-hijau_hutan"}  ${buttonStyle}`} color={rest?.disabled
              ? "bg-gray-200"
              : "bg-white"}>
          <ButtonText
            classstyle={`font-bold text-sm ${buttonTextSyle}`}
            tx={noLabel}
            color={rest?.disabled
              ? "text-white"
              : "text-hijau_hutan"}
          />
        </RoundedButton>
        <RoundedButton {...rest} onClick={onOkClick} color={rest?.disabled
              ? "bg-gray-200"
              : "bg-hijau_hutan"} className={`${buttonStyle}`}>
          <ButtonText
            classstyle={`font-bold text-sm ${buttonTextSyle}`}
            tx={okLabel}
          />
        </RoundedButton>
      </div>
    );
  }
  return (
    <RoundedButton {...rest} onClick={onClick} className={`${buttonStyle}`}>
      <div className="inline-flex items-center">
        <ButtonText
          classstyle={`font-bold text-sm ${buttonTextSyle}`}
          text={tx}
        />
        {children}
      </div>
    </RoundedButton>
  );
}

export default ButtonModal;
