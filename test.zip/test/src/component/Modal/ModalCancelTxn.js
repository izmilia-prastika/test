import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";
import P from "./P";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const ModalCancelTxn = ({
  title = "Batalkan Transaksi",
  subTitle = "Apakah anda yakin untuk membatalkan transaksi ini?",
  ...props
}) => {
  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx={title} />
        {props?.loading && <SpinCircleLogo type={"big"}/>}
        <P>{subTitle}</P>
        <ButtonModal
          okLabel="Batalkan"
          noLabel="Tidak"
          type="confirmation"
          onNoClick={() => props.setShow(false)}
          onOkClick={props?.onSubmit}
          disabled={props?.loading}
        />
      </CardModal>
    </Modal>
  );
};

export default ModalCancelTxn;
