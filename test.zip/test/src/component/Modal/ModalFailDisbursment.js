import React from "react";
import AlertCircleIcon from "../../assets/icon/alert_circle_icon";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";
import P from './P';

const ModalFailDisbursment = ({ ...props }) => {
  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx="Penarikan Gagal" />
        <AlertCircleIcon className="mb-4" />
        <P>
          Anda belum memasukan Rekening Bank. Silahkan tekan tombol di bawah ini
          untuk memasukan Rekening Bank Anda
        </P>
        <ButtonModal onClick={props?.onSubmit} tx="Isi Rekening Bank" />
      </CardModal>
    </Modal>
  );
};

export default ModalFailDisbursment;
