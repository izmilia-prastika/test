import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";
import P from "./P";

const ModalConfirmation = ({
  title = "Konfirmasi Penghapusan",
  subTitle = "Apakah anda yakin untuk menghapus data ini?",
  ...props
}) => {
  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx={title} />
        <P>{subTitle}</P>
        <ButtonModal
          okLabel="Hapus"
          noLabel="Tidak"
          type="confirmation"
          onNoClick={() => props.setShow(false)}
          onOkClick={props?.onSubmit}
        />
      </CardModal>
    </Modal>
  );
};

export default ModalConfirmation;
