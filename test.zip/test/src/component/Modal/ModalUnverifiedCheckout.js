import React from "react";
// import CheckboxChecklistLogo from "../../assets/logo/checkbox_checklist";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ModalInfo from "../Info/ModalInfo";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";

const ModalUnverifiedCheckout = (props) => {
    // const { fontSize = 'text-lg' } = props;
    // const { buttonStyle = 'px-10 py-4 w-auto' } = props;

    return (
        <Modal {...props}>
            <CardModal>
                <ModalTitleText text="Konfirmasi Checkout" />
               {/*  <ModalInfo label="Nama Koleksi" value="Gundala Fake" />
                <ModalInfo label="Pembuat" value="Gundala Fake" />
                <ModalInfo label="Total Penjualan" value="0" />
                <ModalInfo label="Contract Address" value="0xcq341" />P
                <div className="flex flex-row mt-10 px-24 mb-6">
                    <CheckboxChecklistLogo className="mr-2" />
                    <p className="font-quicksand font-normal text-xs text-hitam_2">  Saya mengerti bahwa Code.ID NFT Marketplace belum
                        memverifikasi koleksi ini dan transaksi tidak dapat dibatalkan
                    </p>
                </div> */}
                <ButtonModal onClick={props?.handleBtn} tx="Lanjut" />
            </CardModal>
        </Modal>
    )
}

export default ModalUnverifiedCheckout