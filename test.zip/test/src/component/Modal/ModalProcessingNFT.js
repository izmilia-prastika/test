import React, { useContext, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
import InfoIcon from "../../assets/icon/info_icon";
import CardModal from "../Card/CardModal";
import StatusProcessInfo from "../Info/StatusProcessInfo";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";
import { toast } from "react-toastify";
// import HeaderMobileContext from "../../context/HeaderMobile/HeaderMobileContext";

const ModalProcessingNFT = ({
  title = "Proses Penyelesaian Penjualan Aset",
  children,
  status,
  processLabels,
  onSubmit,
  setShow,
  responsive,
  errorMessage,
  onRetryProcess,
  handleInvoice,
  isInvoicePay,
  ...props
}) => {
  const isFiat = processLabels.includes("Menunggu Pembayaran");
  const isFiatContinue =
    isFiat && processLabels.includes("Konfirmasi Persetujuan Pembelian");
  const isCreateCrypto =
    processLabels.includes("Pengecekan Wallet") &&
    processLabels.includes("Unggah Asset");
  const isFiatWait = isInvoicePay;
  const isFailed = status.includes("fail");
  const isFiatFailed = isFailed && isFiat;
  const isCreateCryptoFailed = isFailed && isCreateCrypto;
  const isDisabled = (!status.includes("fail") && (status.includes("process") || status.includes("waiting")))
  const isProcessing = status.includes("process")
  // const {setTriggerBanner, triggerBanner} = useContext(HeaderMobileContext)
  const handleClose = () => {
    setShow(false)
    // setTriggerBanner(!triggerBanner)
  }
  // const navigate = useNavigate();
  // const handleToDashboard = () => {
  //   navigate("/history-txn/pending");
  // };
  // const handleToLihatProfile = () => {
  //   setShow(false)
  //   navigate("/profile-page");
  // };

  useEffect(() => {
    let indexProcessing = status.indexOf('process')
    let selectedProcess = processLabels[indexProcessing]
    let isiToast;
    switch (selectedProcess) {
      case "Konfirmasi Proses Minting":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      case "Konfirmasi Registrasi Aset":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      case "Sinkronasi Data":
        isiToast = "Mohon tunggu, sedang sinkronasi data"
        break;
      case "Proses Penawaran":
        isiToast = "Mohon tunggu, penawaran sedang diproses"
        break;
      case "Selesaikan Pembayaran":
        isiToast = "Silahkan selesaikan pembayaran pada tab invoice"
        break;
      case "Menunggu Pembayaran":
        isiToast = "Silahkan selesaikan pembayaran pada tab invoice"
        break;
      case "Konfirmasi Lelang Asset":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      case "Konfirmasi Penjualan Asset":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      case "Proses Lelang":
        isiToast = "Mohon tunggu, lelang sedang diproses"
        break;
      case "Proses Pembatalan":
        isiToast = "Mohon tunggu, pembatalan sedang diproses"
        break;
      case "Proses Penutupan Lelang":
        isiToast = "Mohon tunggu, penutupan lelang sedang diproses"
        break;
      case "Memberikan Hak Kuasa":
        isiToast = "Mohon tunggu, sedang memberikan hak kuasa"
        break;
      case "Memberi Hak Kuasa":
        isiToast = "Mohon tunggu, sedang memberikan hak kuasa"
        break;
      case "Konfirmasi Pembelian":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      case "Proses Persetujuan Penawaran":
        isiToast = "Mohon tunggu, pesetujuan penawaran sedang diproses"
        break;
      case "Konfirmasi Persetujuan Pembelian":
        isiToast = "Silahkan cek popup metamask, atau cek icon metamask di bagian kanan atas browser"
        break;
      default:
        break;
    }
    toast(isiToast, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status])





  return (
    <Modal setShow={setShow} responsive={responsive} {...props}>
      <CardModal>
        <ModalTitleText
          text={title}
        />
        {isProcessing &&
          <div className="flex mb-6 flex-col bg-gray-100 py-3 px-6 rounded-lg overflow-hidden">
            <p className="font-medium text-lg font-quicksand text-abu_86 text-left">
              Harap menunggu beberapa menit sampai seluruh proses selesai
            </p>
          </div>
        }
        <div className="grid grid-rows-3 gap-4 mb-6 w-full">
          {processLabels?.map((label, i) => {
            return (
              <StatusProcessInfo
                key={i}
                label={label}
                status={status[i]}
                handleInvoice={handleInvoice}
              />
            );
          })}
        </div>

        {isFiatFailed && !isFiatContinue ? (
          <div className="flex mb-6 flex-col bg-red-50 p-5 rounded-lg">
            <div className="flex mb-2">
              <InfoIcon className="self-center mr-2" color={"#B92525"} />
              <p className="font-bold text-lg font-quicksand text-hitam">
                {errorMessage?.title ?? "Proses Tidak Berhasil"}

              </p>
            </div>
            <p className="font-medium text-lg font-quicksand text-abu_86">
              {errorMessage?.message ?? "Untuk melanjutkan proses silahkan konfirmasi ulang di menu Sejarah Transaksi atau"}
              {/* <p
                className="cursor-pointer text-hijau_hutan underline hover:text-hijau_muda"
                onClick={handleToDashboard}
              >
                Klik Disini
              </p>{" "} */}
            </p>
          </div>
        ) : isCreateCryptoFailed ? (
          <div className="flex mb-6 flex-col bg-red-50 p-5 rounded-lg">
            <div className="flex mb-2">
              <InfoIcon className="self-center mr-2" color={"#B92525"} />
              <p className="font-bold text-lg font-quicksand text-hitam">
                {errorMessage?.title ?? "Proses Tidak Berhasil"}
              </p>
            </div>
            <p className="font-medium text-lg font-quicksand text-abu_86">
              {errorMessage?.message ?? "Untuk melanjutkan proses silahkan masuk ke Tab 'Asset Yang Dibuat'di menu 'Lihat Profil' atau"}
              {/* <p
                className="cursor-pointer text-hijau_hutan underline hover:text-hijau_muda"
                onClick={handleToLihatProfile}
              >
                Klik Disini
              </p>{" "} */}
            </p>
          </div>
        ) : isFailed ? (
          <div className="flex mb-6 flex-col bg-red-50 p-5 rounded-lg">
            <div className="flex">
              <InfoIcon className="self-start mr-2" color={"#B92525"} />
              <div className="flex flex-col">
                <p className="font-bold text-lg font-quicksand text-hitam">
                  {errorMessage?.title}
                </p>
                <p className="font-medium text-lg font-quicksand text-abu_86">
                  {errorMessage?.message}
                </p>
              </div>
            </div>
          </div>
        ) : null}
        {isFiatWait && (
          <div className="p-5 bg-gray-100 w-full rounded-lg mb-6 items-center">
            <div className="flex">
              <InfoIcon className="self-start mr-2" />
              <p className="font-quicksand text-base font-medium text-hitam">
                Jika halaman invoice tidak terbuka, silahkan{" "}
                <span
                  className="cursor-pointer text-hijau_hutan underline hover:text-hijau_muda"
                  onClick={handleInvoice}
                >
                  Klik Disini
                </span>
              </p>
            </div>
          </div>
        )}
        <ButtonModal
          type={(status.includes("fail") || status.includes("waiting") || status.includes("process")) && "confirmation"}
          disabled={isDisabled}
          onNoClick={() =>
            status.includes("fail") && handleClose()
          }
          onOkClick={() => status.includes("fail") ? onRetryProcess() : onSubmit()}
          okLabel={status.includes("fail") ? "Ulangi" : "Lanjut"}
          noLabel="Tutup"
          onClick={() =>
            status.includes("fail") ? handleClose() : onSubmit()
          }
          color={
            isDisabled
              ? "bg-gray-200"
              : "bg-hijau_hutan"
          }
          tx={status.includes("fail") ? "Tutup" : "Lanjut"}
        />

        {/* <RoundedButton
          disabled={!status.includes("fail") && status.includes("process")}
          onClick={() =>
            status.includes("fail") ? setShow(false) : onSubmit()
          }
          color={
            !status.includes("fail") && status.includes("process")
              ? "bg-gray-200"
              : "bg-hijau_hutan"
          }
          className={`px-10 py-4 w-full self-end`}
        >
          <ButtonText
            classstyle="font-bold md:text-base text-sm"
            text={status.includes("fail") ? "Tutup" : "Lanjut"}
          />
        </RoundedButton> */}
      </CardModal>
    </Modal>
  );
};

export default ModalProcessingNFT;
