/* eslint-disable react-hooks/exhaustive-deps */
import React, { useContext, useEffect, useState } from "react";
import CloseIcon from "../../assets/icon/close_icon";
// import accountsBankContext from "../../context/AccounsBank/accountsBankContext";
// import authContext from "../../context/Auth/authContext";
import bankContext from "../../context/Bank/bankContext";
import { convertNumber } from "../../utils/helper";
import CardModal from "../Card/CardModal";
import ExclamationInfo from "../Info/ExclamationInfo";
import InputWithLabel from "../Input/InputWithLabel";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import P from './P';
import ButtonModal from "./ButtonModal";
// import web3ModalContext from "../../context/Web3Modal/web3ModalContext";
import fiatContext from "../../context/FiatPayment/fiatContext";
// import { ethers } from "ethers";
// import BankContract from "../../artifacts/contracts/BankAccounts.sol/BankAccounts.json"
// import { bankAddres, paymasterConfig } from "../../config/configContract";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { toast } from "react-toastify";
// import { signRelayRequest } from "../../utils/VerifyingPaymasterUtils";
// import { RelayProvider } from "@opengsn/provider";
// import env from "../../config/env";
import authContext from "../../context/Auth/authContext";
import { INVOICE_ADD_BANK } from "../../utils/constants/invoiceTypes";
// import InfoIcon from "../../assets/icon/info_icon";
import InputComboBox from "../Input/InputComboBox";
import InfoIcon from "../../assets/icon/info_icon";
import { v4 as uuidv4 } from 'uuid';
import env from "../../config/env";
// import _ from 'lodash'

const TRIAL_MAX = 3

const ModalInputBankAccount = ({ 
    title = "Tambah Rekening Bank", 
    imgAsset, 
    info, 
    handleBtn, 
    isEdit, 
    setIsEdit, 
    initData,
    setModalConfirm,
    setFound,
    setConfirmedBank,
    setFormInput,
    setBankData,
    setShowTimeout,
    setMatch,
    setShowInfo,
    ...props }) => {
    // const { fontSize = 'text-lg' } = props;
    // const { buttonStyle = 'px-10 py-4 w-auto' } = props;
    // const AccountsBankContext = useContext(accountsBankContext)
    // const AuthContext = useContext(authContext)
    // const inputEl = useRef(null)
    // const { allInvoice } = useContext(fiatContext)
    const BankContext = useContext(bankContext)
    const AuthContext = useContext(authContext)
    const FiatContext = useContext(fiatContext)
    const [isButtonOn, setisButtonOn] = useState(false)
    const [isAllowed, setisAllowed] = useState(false)
    const [attempts, setAttempts] = useState(false)
    const [invoiceIdSelected, setInvoiceId] = useState(false)
    const [referenceIdBankValidation, setReference] = useState()
    const [accountBankValidationId, setAccountValId] = useState()
    const [bank, setBank] = useState(null)
    const [errorMsg, setErrorMsg] = useState(`Percobaan validasi rekening anda tinggal ${TRIAL_MAX - attempts} kali lagi.`)
    const [loading, setLoading] = useState(false)
    const [formInput, updateFormInput] = useState({
        bankAccountNumber: "", accountHolderName: ""
    })

    useEffect(async () => {
        setLoading(true)
        if (props?.show) {
            // console.log(attempts, "TESS")
            await BankContext?.getAll()
            // const selectedBank = BankContext.banks?.filter(el => el.code === initData?.bankName)
            setBank({
                name: null,
                 code: '',
                 id: '',
             })
            updateFormInput({
                bankAccountNumber: "",
                accountHolderName: "",
            })
            
            const fetchInvoice = await FiatContext.allInvoice(
                {
                    accountId: AuthContext?.auth?.user?.id,
                    type: INVOICE_ADD_BANK,
                    first: 1
                })
            if (fetchInvoice?.nodes?.length > 0) {
                setInvoiceId(fetchInvoice?.nodes[0]?.id)
            }
            const fetchBankValidation = await BankContext.getValidationBank(
                {
                    accountId: AuthContext?.auth?.user?.id,
                    invoiceId: fetchInvoice?.nodes[0]?.id,
                    first: 1
                }
            )
                // console.log(fetchBankValidation, "TESS FET")
                if(fetchBankValidation?.length !== 0 ){
                    let dataValidationBank
                    dataValidationBank = fetchBankValidation[0]
                    setAccountValId(dataValidationBank?.id)
                    setAttempts(dataValidationBank?.attempts)
                    setReference(dataValidationBank?.referenceId)
                } else if(fetchBankValidation?.length === 0) {
                    setAttempts(3)
                }
                // console.log('TES ZAP', attempts)
                setErrorMsg(`Percobaan validasi rekening anda tinggal ${TRIAL_MAX - attempts} kali lagi.`)
                
            // const dataValidationBank = fetchBankValidation[0]
            // setAttempts(dataValidationBank?.attempts)
            // setIdBankValidation(dataValidationBank?.id)
            // setReference(dataValidationBank?.referenceId)
            // setErrorMsg(`Percobaan validasi rekening anda tinggal ${TRIAL_MAX - attempts} kali lagi.`)

            if(attempts <= 3){
                setisAllowed(true)
                setLoading(false)
            } else {
                setisAllowed(false)
                setLoading(false)
            }
    }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props?.show, attempts, errorMsg, ])

    useEffect(() => {
        if(formInput?.accountHolderName === "" && formInput?.bankAccountNumber ===""){
            setisButtonOn(false)
        } else {
            setisButtonOn(true)
        }
    }, [formInput?.accountHolderName ,isButtonOn])

    const dataBank = BankContext?.banks?.map(({ name, id, code }) => ({value: id, name, code}))
    const handleShow = (state) => {
        props.setShow(state)
    }
    
    const checkPullIluma = async (bankAccountNumber, accountHolderName) => {
        toast(`Proses validasi rekening bank sedang diproses. Mohon tunggu beberapa saat.`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
        const fetchBankValidation = await BankContext.getValidationBank(
                {
                    accountId: AuthContext?.auth?.user?.id,
                    invoiceId: invoiceIdSelected,
                    first: 1
                }
            )
        // console.log(accountBankValidationId, referenceIdBankValidation, "TES")
        await BankContext.checkIluma(
            {
                bank_account_number: bankAccountNumber,
                bank_code: bank?.code,
                given_name: accountHolderName,
                accountBankValidationId: fetchBankValidation[0].id,
                refrenceId: fetchBankValidation[0].referenceId,
            }
        )
        
        const timeOut = setTimeout(() => {
                setLoading(false)
                clearTimeout(timeOut)
            }, 300000)

        const intervalId = setInterval(async () => {
            const fetchVerified = await BankContext.getVerifiedBank(
                {
                    refrenceId: referenceIdBankValidation,
                    first: 1
                })
            // console.log(fetchVerified, "TES")
            if (fetchVerified?.nodes?.length > 0) {
                const dataRes = fetchVerified.nodes[0]
                const result = JSON.parse(dataRes?.result)
                if(result?.is_found === true) {
                    // !isEdit ? addToBlockchain() : editToBlockchain()
                    setLoading(false)
                    handleShow(false)
                    setFound(true)
                    setConfirmedBank({
                        accountNumber: bankAccountNumber,
                        bankName: bank?.name,
                        holderName: accountHolderName,
                    })
                    if(result.name_matching_result === env.IS_PROD ? "MATCH" : "NOT_MATCH"){
                        setMatch(true)
                    } else {
                        setMatch(false)
                    }
                    setBankData(bank)
                    setFormInput(formInput)
                    setModalConfirm(true)
                    clearInterval(intervalId)
                    clearTimeout(timeOut)
                    clearTimeout(timeOutInterval)
                } else {
                    setLoading(false)
                    setConfirmedBank({
                        accountNumber: bankAccountNumber,
                        bankName: bank?.name,
                        holderName: accountHolderName,
                    })
                    handleShow(false)
                    setFound(false)
                    setModalConfirm(true)
                    clearTimeout(timeOutInterval)
                    clearInterval(intervalId)
                    clearTimeout(timeOut)
                }
            } 
        }, 2000)
        const timeOutInterval = setTimeout(() => {
            setLoading(false)
            handleShow(false)
            setShowTimeout(true)
            clearTimeout(timeOutInterval)
            clearInterval(intervalId)
        }, 30000)
       
    }

    const addBankWithBlockhain = async () => {
        setLoading(true)
        const {bankAccountNumber, accountHolderName} = formInput
        const fetchBankValidation = await BankContext.getValidationBank(
            {
                accountId: AuthContext?.auth?.user?.id,
                invoiceId: invoiceIdSelected,
                first: 1
            }
        )
        if(fetchBankValidation?.length === 0){
            const reference = uuidv4()
            await BankContext.addValidationBank({
                accountId: AuthContext?.auth?.user?.id,
                invoiceId: invoiceIdSelected,
                referenceId: `${reference}/${accountHolderName}`,
                attempts: 0,
            })
        } else {
            let dataValidationBank = fetchBankValidation[0]
            setAccountValId(dataValidationBank?.id)
            setReference(dataValidationBank?.referenceId)
            setAttempts(dataValidationBank?.attempts)
        }

        const res = await BankContext.getVerifiedBank({
            bankAccountNumber: bankAccountNumber,
            bankCode: bank?.code,
            bankAccountName: accountHolderName,
            first: 1,
        })
        // console.log("TES RES VERF", res)

        if(res?.nodes?.length !== 0){
            const dataRes = res?.nodes[0]
            const result = JSON.parse(dataRes?.result)
            // console.log("TES result", result)
            if(result.is_found === true && result?.name_matching_result === env.IS_PROD ? "MATCH" : "NOT_MATCH") {
                setLoading(false)
                handleShow(false)
                setFound(true)
                setConfirmedBank({
                    accountNumber: bankAccountNumber,
                    bankName: bank?.name,
                    holderName: accountHolderName,
                })
                setMatch(true)
                setBankData(bank)
                setFormInput(formInput)
                setModalConfirm(true)
            } else {
                if(isAllowed){
                    checkPullIluma(bankAccountNumber, accountHolderName)
                } else {
                    setLoading(false)
                    handleShow(false)
                    setShowInfo(true)
                }
            }
        } else {
            if(isAllowed){
                checkPullIluma(bankAccountNumber, accountHolderName)
            } else {
                // console.log("TES Disini", isAllowed, attempts)
                setLoading(false)
                handleShow(false)
                setShowInfo(true)
            }
        }
    }

    return (
        <>
        <Modal {...props}>
            <CardModal className={"pb-10 md:max-h-full max-h-modalmax overflow-y-auto md:py-9 py-0"}>
                <div className="bg-white sticky md:pt-0 pt-6 top-0 w-full justify-center items-center z-30">
                {props.responsive &&
                <div className='flex items-center w-full justify-end bg-white'>
                    <CloseIcon size={4} viewBox={20} onClick={()=>props.setShow(!props.show)}/>
                </div>}
                <ModalTitleText text={isEdit ? "Edit Rekening Bank" : "Tambah Rekening Bank"} classstyle="text-center bg-white"/>
                </div>
                <P className="md:mt-0 -mt-0" fontSize="md:text-lg text-sm">
                    Pastikan Bank dan Nomor Rekening yang diisi tidak salah karena bisa berakibat kesalahan saat kami mentransfer dana kepada anda.
                </P>
                <ExclamationInfo className={"self-start mb-4"} value="Kesalahan pengisisan bukan tanggung jawab kami" />
                <div className="grid gap-6 grid-cols-1 w-full mb-3">
                    <InputComboBox
                        suggestions={dataBank}
                        searchAble
                        setValue={setBank}
                        value={bank}
                        className="w-full" tx="Nama Bank" 
                        modalParent={props?.show}
                        />
                    <InputWithLabel tx="Nomor Rekening"
                        value={formInput?.bankAccountNumber}
                        defaultValue={""}
                        // defaultValue={isEdit ? initData?.accountNumber : ""}
                        onChange={(e) => updateFormInput({ ...formInput, bankAccountNumber: convertNumber(e.target.value) })}
                    />
                    <InputWithLabel
                        value={formInput?.accountHolderName}
                        onChange={(e) => {
                            const upperCaseString = e.target.value.toLocaleUpperCase();
                            updateFormInput({ ...formInput, accountHolderName: upperCaseString })}}
                        tx="Atas Nama" /> 
                    {TRIAL_MAX - attempts !== 0 && <div className="flex bg-gray-100 font-quicksand p-4 rounded-md items-center">
                        <InfoIcon />
                        <p className="ml-2">{errorMsg}</p>
                    </div>}
                </div>
                <div className="grid grid-cols-2 w-full gap-x-6">
                    <ButtonModal buttonStyle="py-4 w-full mt-4 border border-hijau_hutan" color="bg-white" disabled={loading} onClick={() => handleShow(false)} tx="Kembali" buttonTextSyle={`text-hijau_hutan`}/>
                    <ButtonModal buttonStyle={`${(!loading && isButtonOn) ? "bg-hijau_hutan" : "bg-hijau_kristal"} py-4 w-full mt-4`} disabled={loading || !isButtonOn} onClick={addBankWithBlockhain} tx="Lanjutkan" children={loading && <SpinCircleLogo />} buttonTextSyle={loading && "mr-4"}/>
                </div>
            </CardModal>
        </Modal>
    </>
    )
}

export default ModalInputBankAccount
