import React, { useRef, useState } from "react";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import CloseIcon from "../../assets/icon/close_icon";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
import ChecklistInput from "../Input/ChecklistInput";

const tes =
  '<p><span style="font-weight: 400;">NFT Saya&hellip; adalah aplikasi yang memberi pengguna kesempatan untuk membeli, mengumpulkan, dan menampilkan koleksi blockchain digital yang berisi konten eksklusif dari berbagai Karya Digital. </span><strong>&hellip;</strong> <strong>NFT Saya</strong><span style="font-weight: 400;"> menyediakan Aplikasi untuk Anda. Namun, sebelum Anda menggunakan Aplikasi, Anda harus menyetujui Syarat Penggunaan ini dan syarat dan ketentuan apa pun yang tercantum di sini sebagai referensi (selanjutnya disebut </span><strong>"Syarat dan Ketentuan"</strong><span style="font-weight: 400;">).</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">HARAP BACA KETENTUAN INI DENGAN SEKSAMA SEBELUM MENGGUNAKAN APLIKASI. PENGGUNAAN APLIKASI, KECUALI KAMI TELAH MENJALANKAN PERJANJIAN TERTULIS TERPISAH DENGAN ANDA UNTUK TUJUAN SEBAGAIMANA DIMAKSUD. KAMI HANYA BERSEDIA UNTUK MEMBUAT APLIKASI TERSEDIA UNTUK ANDA JIKA ANDA MENYETUJUI SEMUA PERSYARATAN INI DENGAN MENGGUNAKAN APLIKASI ATAU BAGIAN DARINYA, ATAU DENGAN CARA MELAKUKAN KLIK PADA TOMBOL &ldquo;SAYA SETUJU&rdquo; DI BAWAH ATAU MENUNJUKKAN PENERIMAAN ANDA DALAM KOTAK YANG TERSEDIA, ANDA MENYATAKAN BAHWA ANDA MEMAHAMI DAN SETUJU UNTUK TERIKAT OLEH SEMUA PERSYARATAN INI JIKA ANDA MENERIMA PERSYARATAN INI ATAS NAMA PERUSAHAAN ATAU PERWAKILAN LAIN, BAHWA ANDA MEMILIKI WEWENANG HUKUM UNTUK MENERIMA PERSYARATAN INI ATAS NAMA ENTITAS TERSEBUT, DALAM KASUS "ANDA" BERARTI ENTITAS ITU. JIKA ANDA TIDAK MEMILIKI WEWENANG TERSEBUT, ATAU JIKA ANDA TIDAK MENERIMA SEMUA PERSYARATAN INI, MAKA KAMI MENYETUJUI BUAT APLIKASI TERSEDIA UNTUK ANDA JIKA ANDA MELAKUKANNYA ATAU SETUJU DENGAN KETENTUAN INI, ANDA TIDAK BOLEH MENGAKSES ATAU MENGGUNAKAN APLIKASI.</span></p>' +
  '<p><span style="font-weight: 400;">PERJANJIAN INI BERISI KETENTUAN ARBITRASE HARAP PERIKSA KEMBALI KETENTUAN ARBITRASE DENGAN SEKSAMA, KARENA HAL TERSEBUT MEMPENGARUHI HAK ANDA. DENGAN MENGGUNAKAN APLIKASI ATAU BAGIAN APA PUN DARINYA, ATAU DENGAN MELAKUKAN KLIK PADA TOMBOL &ldquo;SAYA SETUJU&rdquo; DI BAWAH ATAU MENUNJUKKAN PENERIMAAN ANDA DALAM KOTAK YANG BERSAMAAN, ANDA MEMAHAMI DAN SETUJU UNTUK TERIKAT OLEH KETENTUAN ARBITRASE YANG BERLAKU.</span></p>' +
  '<p><span style="font-weight: 400;">SETIAP PEMBELIAN ATAU PENJUALAN YANG ANDA LAKUKAN, TERIMA, ATAU FASILITASI DI LUAR APLIKASI INI AKAN SEPENUHNYA MENJADI RISIKO ANDA. KAMI TIDAK MENGENDALIKAN ATAU MENYETUJUI PEMBELIAN ATAU PENJUALAN MOMEN DI LUAR APLIKASI INI. KAMI SECARA TEGAS MENYANGKAL KEWAJIBAN APA PUN UNTUK MENGGANTI RUGI TERKAIT YANG ANDA LAKUKAN DENGAN TRANSAKSI, ATAU MEMFASILITASI TRANSAKSI, DI DILUAR APLIKASI INI.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Dokumen ini berisi informasi yang sangat penting mengenai hak dan kewajiban Anda, kondisi, batasan, dan pengecualian yang mungkin berlaku untuk Anda. Silakan baca Syarat dan Ketentuan ini dengan seksama. Setiap perubahan pada Syarat dan Ketentuan ini akan berlaku pada </span><strong>&ldquo;Tanggal Pembaruan Terakhir&rdquo;</strong><span style="font-weight: 400;"> yang disebutkan di bagian atas halaman ini. Anda harus meninjau dan memeriksa kembali terkait Syarat dan Ketentuan ini sebelum menggunakan Aplikasi atau membeli produk apa pun dan atau menggunakan layanan apa pun yang tersedia melalui Aplikasi ini.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Jika Anda terus menggunakan Aplikasi ini setelah </span><strong>&ldquo;Tanggal Pembaruan Terakhir&rdquo;</strong><span style="font-weight: 400;">, Anda akan menerima dan menyetujui perubahan tersebut. Dengan menggunakan Aplikasi ini, Anda menegaskan bahwa Anda cukup umur untuk masuk ke dalam Aplikasi ini, dan Anda menerima dan terikat oleh Syarat dan Ketentuan ini. Anda menegaskan bahwa jika Anda menggunakan Aplikasi ini atas nama organisasi atau perusahaan, Anda menjamin bahwa Anda memiliki wewenang hukum untuk mewakili organisasi atau perusahaan tersebut dengan Syarat dan Ketentuan ini.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Anda tidak boleh menggunakan Aplikasi ini jika Anda:</span></p>' +
  '<ul class="list-alpha_small ml-4">' +
  '<li style="font-weight: 400;" aria-level="1">Tidak menyetujui Ketentuan ini</li>' +
  '<li style="font-weight: 400;" aria-level="1">Tidak cukup umur secara hukum di tempat tinggal Anda; atau</li>' +
  '<li style="font-weight: 400;" aria-level="1">Dilarang mengakses atau menggunakan Aplikasi ini atau konten, produk, atau layanan Aplikasi ini oleh hukum yang berlaku.</li>' +
  "</ul>" +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-decimal ml-0">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>PENGGUNAAN APLIKASI PENYIAPAN DAN KEAMANAN AKUN</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Pengaturan Akun dan Dompet</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Untuk menggunakan Aplikasi dengan cara yang paling mudah untuk dipahami adalah Anda harus terlebih dahulu menginstal browser web (seperti browser web Google Chrome). Anda juga perlu menggunakan dompet elektronik Gopay, OVO, DANA, ShopeePay atau dompet elektronik lain yang didukung, yang memungkinkan Anda untuk membeli dan menyimpan barang koleksi yang Anda kumpulkan atau beli melalui Aplikasi. Setiap koleksi adalah Token Non-Fungible (selanjutnya disebut sebagai&ldquo;NFT&rdquo;) pada jaringan </span><span style="font-weight: 400;">blockchain Polygon&hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Pendaftaran Akun</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda harus memberikan informasi pendaftaran yang akurat dan lengkap saat membuat akun untuk Aplikasi. Dengan membuat akun, Anda setuju untuk memberikan informasi akun yang akurat, terkini, dan lengkap tentang diri Anda, dan untuk memelihara dan segera memperbarui informasi akun Anda sebagaimana diperlukan. Kami berhak mendapatkan kembali nama pengguna tanpa kewajiban kepada Anda.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Keamanan Akun</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda bertanggung jawab atas keamanan akun Anda untuk Aplikasi dan dompet elektronik Anda. Jika Anda mengetahui adanya penggunaan kata sandi atau akun Anda yang tidak sah dengan kami, Anda setuju untuk segera memberitahukan kepada kami dengan segera di &hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Transaksi Rekening</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda dapat menggunakan dompet elektronik Anda untuk membeli, menyimpan, dan terlibat dalam transaksi menggunakan rekening bank atau akun e-wallet Anda. Transaksi yang terjadi di Aplikasi dikonfirmasi melalui jaringan Polygon</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  "</ol>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>MEMBELI DAN MENDAPATKAN KARYA DIGITAL</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Memperoleh NFT</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Aplikasi ini memungkinkan Anda untuk membeli, mendapatkan, mengumpulkan dan menampilkan Karya Digital dari Seniman Karya digital. Setiap Karya Digital adalah NFT di Jaringan Polygon&hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Pembelian Karya Digital</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda dapat membeli Karya Digital dengan dua cara yaitu:</span></p>' +
  '<ol class="list-decimal ml-4 mb-2">' +
  '<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Dengan membeli pack NFT dari kami di pasar primary (&ldquo;pack&rdquo; atau paket); atau</span></li>' +
  '<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Dengan membeli NFT dari pengguna lain di pasar sekunder (&ldquo;Marketplace&rdquo;).</span></li>' +
  "</ol>" +
  '<p><span style="font-weight: 400;">Ada berbagai jenis Paket yang tersedia untuk dibeli di Aplikasi, dan kami berhak untuk mengubah jenis, harga, dan jumlah Paket yang tersedia sesuai kebijaksanaan kami. Tergantung pada jenis Paket yang Anda beli, Anda akan mengumpulkan Karya Digital dari berbagai tingkat kelangkaan. Sebelum Anda membeli Paket, kami akan memberitahu Anda jenis Karya Digital (tetapi bukan spesifik pada jenis Karya Digital) yang ada di dalam Paket tersebut. Jika Anda membeli Momen individual dari pengguna lain di Marketplace, Anda akan tahu persis Karya Digital yang Anda beli. Kami sangat menganjurkan Anda untuk tidak membeli Karya Digital selain dengan cara pembelian sebagaimana dimaksud diatas. Jika Anda memutuskan untuk membeli Karya Digital dengan cara lain, Anda memahami bahwa pembelian tersebut sepenuhnya menjadi risiko Anda sendiri.</span></p>' +
  "</li>" +
  "</ol>" +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>PEMBAYARAN DAN PAJAK</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Transaksi keuangan dalam Aplikasi</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Setiap pembayaran atau transaksi keuangan yang Anda lakukan melalui Aplikasi akan dicatat secara permanen di jaringan Polygon&hellip;. Kami tidak memiliki kendali atas pembayaran atau transaksi yang Anda lakukan, kami juga tidak memiliki kemampuan untuk membatalkan pembayaran atas transaksi apa pun. Kami tidak bertanggung jawab kepada Anda atau Pihak Ketiga mana pun atas klaim atau kerusakan apa pun yang mungkin timbul sebagai akibat dari pembayaran atau transaksi apa pun yang Anda lakukan melalui Aplikasi. Kami tidak memberikan pengembalian uang untuk pembelian apa pun yang mungkin Anda lakukan melalui Aplikasi &ndash; baik untuk Karya Digital, Pack, atau apa pun.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Tanggung Jawab Perpajakan</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda akan bertanggung jawab penuh untuk membayar setiap dan semua penjualan, penggunaan, pertambahan nilai dan pajak, bea, dan penilaian lainnya (kecuali pajak atas penghasilan bersih kami) sekarang atau selanjutnya yang diklaim atau dikenakan oleh otoritas pemerintah mana pun (secara bersama-sama disebut "Pajak") yang terkait dengan penggunaan Aplikasi oleh Anda. Kecuali untuk pajak penghasilan yang dikenakan kepada kami.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Anda akan membayar untuk semua pajak nasional atau lainnya dan penilaian yurisdiksi mana pun, termasuk pajak pertambahan nilai dan pajak sebagaimana disyaratkan oleh perjanjian pajak internasional, bea cukai atau pajak impor atau ekspor lainnya, dan jumlah yang dikenakan sebagai penggantinya berdasarkan biaya yang ditetapkan, layanan yang dilakukan atau pembayaran yang dilakukan berdasarkan Perjanjian ini, seperti yang sekarang atau selanjutnya dapat dikenakan di bawah otoritas perpajakan Republik Indonesia.</span></p>' +
  "</li>" +
  "</ol>" +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>KEPEMILIKAN, LISENSI, DAN PEMBATASAN KEPEMILIKAN</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">KEPEMILIKAN NFT ANDA HANYA AKAN DIAKUI OLEH KAMI JIKA ANDA TELAH MEMBELI ATAU MENDAPATKAN KARYA DIGITAL TERSEBUT DARI SUMBER YANG SAH DAN TIDAK MELALUI KEGIATAN TERLARANG SEBAGAIMANA DIATUR DALAM PERJANJIAN INI DAN PERATURAN PERUNDANG-UNDANGAN YANG BERLAKU.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Untuk maksud dan definisi pada Bagian 4 ini, istilah dalam Perjanjian ini memiliki arti sebagai berikut</span><strong>:</strong></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><strong>&ldquo;Karya DiIgital&rdquo;</strong><span style="font-weight: 400;"> berarti setiap seni, desain, dan gambar (dalam bentuk atau media apa pun, termasuk, tanpa batasan, video atau foto). Karya digital yang Anda beli mengandung Hak Kekayaan Intelektual (</span><strong>&ldquo;HAKI&rdquo;</strong><span style="font-weight: 400;">).</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><strong>&ldquo;Milik&rdquo;</strong><span style="font-weight: 400;"> berarti, sehubungan dengan Karya Digital yang telah Anda beli atau dapatkan dengan cara lain dari sumber yang sah (dan bukan melalui Aktivitas yang Dilarang dalam Syarat dan Ketentuan ini di mana bukti pembelian tersebut dicatat pada jaringan Polygon&hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><strong>&ldquo;Karya Digital yang Dibeli&rdquo;</strong><span style="font-weight: 400;"> berarti Karya Digital yang Anda Miliki. Berarti setiap hak paten pihak ketiga, hak cipta, rahasia dagang, merek dagang, pengetahuan atau HAKI yang diakui di negara atau yurisdiksi mana pun di dunia.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Kepemilikan Karya Digital</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Karena setiap Karya Digital adalah NFT di jaringan Polygon&hellip;, saat Anda membeli Karya Digital sesuai dengan Syarat dan Ketentuan ini (dan bukan melalui Aktivitas yang dilarang dalam Syarat dan Ketentuan ini), Anda memiliki NFT yang mendasarinya sepenuhnya. Ini berarti Anda memiliki hak untuk memperjual belikan karya digital anda. Kepemilikan Karya Digital dimediasi sepenuhnya oleh jaringan Polygon&hellip;. Kecuali jika diizinkan oleh Ketentuan ini dalam kasus di mana kami menentukan bahwa Karya Digital tersebut tidak diperoleh secara sah dari sumber yang sah (termasuk namun tidak terbatas pada melalui Aktivitas Terlarang sebagaimana diatur dalam Syarat dan Ketentuan ini).</span></p>' +
  "</li>" +
  "<h2>&nbsp;</h2>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Kami Merupakan Pemilik Aplikasi</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda mengakui dan setuju bahwa kami memiliki semua hak hukum, kepemilikan dan kepentingan dalam dan untuk semua elemen lain dari Aplikasi, dan semua HAKI di dalamnya (termasuk namun tidak terbatas pada semua Seni, desain, sistem, metode, informasi, kode komputer, perangkat lunak, layanan, "tampilan dan nuansa", organisasi, kompilasi konten, kode, data, dan semua elemen lain dari Aplikasi yang selanjutnya disebut </span><strong>&ldquo;Materi Aplikasi&rdquo;</strong><span style="font-weight: 400;">). Anda mengakui bahwa Materi Aplikasi dilindungi oleh undang-undang hak cipta,&nbsp;paten, dan merek dagang, konvensi internasional, kekayaan intelektual dan hak kepemilikan lainnya yang relevan, dan undang-undang yang berlaku. Semua Materi Aplikasi adalah hak cipta milik kami, dan semua merek dagang, merek layanan, dan nama dagang yang terkait dengan Aplikasi atau yang terkandung dalam Materi Aplikasi adalah milik kami.</span></p>' +
  "</li>" +
  "<h2>&nbsp;</h2>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Tidak Ada Lisensi Pengguna atau Kepemilikan Materi Aplikasi</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Kecuali secara tegas dinyatakan di sini, penggunaan Aplikasi oleh Anda tidak memberi Anda kepemilikan atau hak lain apa pun sehubungan dengan konten, kode, data, atau Materi Aplikasi lainnya yang dapat Anda akses pada atau melalui Aplikasi. Kami memiliki semua hak dalam dan atas Materi Aplikasi yang tidak secara tegas diberikan kepada Anda dalam Ketentuan ini.</span></p>' +
  "</li>" +
  "<h2>&nbsp;</h2>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Pengakuan Kepemilikan Penggunaan Lebih Lanjut</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Demi tercapainya suatu kepastian, Anda memahami dan menyetujui: (a) bahwa pembelian Karya Digital Anda, baik melalui Aplikasi atau lainnya, tidak memberi Anda hak atau lisensi apa pun dalam atau atas Materi Aplikasi (termasuk namun tidak terbatas pada hak cipta kami dalam dan ke Seni terkait) selain yang secara tegas terkandung dalam Ketentuan ini; (b) bahwa Anda tidak memiliki hak, kecuali dinyatakan lain dalam Ketentuan ini, untuk mereproduksi, mendistribusikan, atau mengkomersilkan elemen apa pun dari Materi Aplikasi (termasuk namun tidak terbatas pada Seni apa pun) tanpa persetujuan tertulis sebelumnya dari kami pada setiap kasus, persetujuan mana yang dapat kami tahan atas kebijakan kami sendiri dan mutlak; dan (c) bahwa Anda tidak akan mengajukan, mendaftar, atau menggunakan atau mencoba menggunakan merek dagang atau merek layanan kami, atau merek serupa yang dapat menimbulkan perselisihan, di mana pun di dunia tanpa persetujuan tertulis sebelumnya dari kami dalam setiap kasus, yang mengizinkan kami untuk dapat bertahan atas kebijakan kami sendiri secara mutlak.</span></p>' +
  "</li>" +
  "<h2>&nbsp;</h2>" +
  "</ol>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Pembatasan Kepemilikan</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda setuju bahwa Anda tidak diperkenankan, atau mengizinkan Pihak Ketiga mana pun untuk melakukan atau mencoba melakukan salah satu hal di atas tanpa persetujuan tertulis sebelumnya dari kami dalam setiap kasus: (a) memodifikasi Seni untuk Karya Digital yang Dibeli dengan cara apa pun, termasuk namun tidak terbatas pada bentuk, desain, gambar, atribut, atau skema warna; (b) menggunakan Seni dari Karya Digital yang Anda Beli untuk mengiklankan, memasarkan, atau menjual produk atau layanan Pihak Ketiga; (c) menggunakan Seni dari Momen yang Anda Beli sehubungan dengan gambar, video, atau bentuk media lain yang menggambarkan kebencian, intoleransi, kekerasan, kekejaman, atau apa pun yang dapat dianggap sebagai ujaran kebencian atau melanggar hak dari orang lain; (d) menggunakan Seni untuk Karya Digital yang Anda Beli dalam film, video, atau bentuk media lainnya, kecuali sejauh penggunaan tersebut diizinkan secara tegas dalam Persyaratan ini atau semata-mata untuk penggunaan pribadi dan non-komersial Anda sendiri; (e) menjual, mendistribusikan untuk keuntungan komersial termasuk namun tidak terbatas pada memberikan dengan harapan keuntungan komersial pada akhirnya, atau mengkomersialkan barang dagangan yang mencakup, berisi, atau terdiri dari Seni untuk Karya Digital yang Anda Beli; (f) mencoba untuk merek dagang, hak cipta, atau memperoleh HAKI tambahan dalam atau pada Seni untuk Momen yang Anda Beli; atau (g) jika tidak, gunakan Seni untuk Momen yang Anda Beli untuk keuntungan komersial Anda atau Pihak Ketiga mana pun.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>KETENTUAN PENGGUNAAN DAN KEGIATAN YANG DILARANG</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">ANDA SETUJU BAHWA ANDA BERTANGGUNG JAWAB ATAS PERILAKU ANDA SENDIRI SAAT MENGAKSES ATAU MENGGUNAKAN APLIKASI, DAN ATAS KONSEKUENSINYA. ANDA SETUJU UNTUK MENGGUNAKAN APLIKASI HANYA UNTUK TUJUAN YANG HUKUM, BENAR DAN SESUAI DENGAN PERSYARATAN INI DAN UNDANG-UNDANG ATAU PERATURAN YANG BERLAKU.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">Jaminan Pengguna. Tanpa membatasi hal-hal di atas, Anda menjamin dan menyetujui bahwa penggunaan Aplikasi oleh Anda tidak akan (dan tidak akan mengizinkan Pihak Ketiga mana pun untuk dan dengan cara apa pun:</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan pengiriman, pengunggahan, pendistribusian atau penyebaran konten yang melanggar hukum, memfitnah, melecehkan, kasar, curang, cabul, atau tidak pantas;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan distribusi virus, worm, cacat, Trojan horse, file rusak, hoax, atau item lain yang bersifat merusak atau menipu;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan pengunggahan, pengeposan, pengiriman, atau penyediaan konten apa pun melalui Aplikasi yang melanggar HAKI pihak mana pun;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan penggunaan Aplikasi untuk melanggar hak hukum (seperti hak privasi dan publisitas) orang lain;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Terlibat dalam, mempromosikan, atau mendorong aktivitas ilegal (termasuk namun tidak terbatas pada kegiatan terorisme dan pencucian uang);</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan gangguan terhadap kesenangan pengguna lain atas Aplikasi;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan eksploitasi Aplikasi untuk tujuan komersial yang tidak sah;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan memodifikasi, mengadaptasi, menerjemahkan, atau merekayasa balik bagian mana pun dari Aplikasi;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan penghapusan pemberitahuan hak cipta, merek dagang, atau hak kepemilikan lainnya yang terkandung di dalam atau di Aplikasi atau bagian mana pun darinya;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan pemformatan ulang atau pembingkaian bagian mana pun dari Aplikasi;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan menampilkan konten apa pun di Aplikasi yang berisi konten yang terkait dengan kebencian atau kekerasan atau berisi materi, produk, atau layanan lain apa pun yang melanggar atau mendorong perilaku yang akan melanggar peraturan perundang-undangan yang berlaku.</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan penggunaan spider, aplikasi pencarian/pengambilan situs, atau perangkat lain untuk mengambil atau mengindeks bagian mana pun dari Aplikasi atau konten yang diposting di Aplikasi, atau untuk mengumpulkan informasi tentang penggunanya untuk tujuan yang tidak sah;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan akses atau penggunaan Aplikasi untuk tujuan menciptakan produk atau layanan yang bersaing dengan produk atau layanan kami;</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan menyalahgunakan, melecehkan, atau mengancam pengguna lain Aplikasi atau perwakilan resmi kami, personel layanan pelanggan, moderator papan obrolan, atau sukarelawan (termasuk namun tidak terbatas pada mengajukan tiket support dengan informasi palsu, mengirim email atau dukungan berlebihan tiket, menghalangi karyawan kami melakukan pekerjaan mereka, menolak untuk mengikuti instruksi karyawan kami, atau secara terbuka meremehkan kami dengan menyiratkan pilih kasih oleh karyawan kami atau sebaliknya); atau</span></li>' +
  '<li class="mt-3" style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Melibatkan penggunaan bahasa yang kasar, memfitnah, menyinggung etnis atau ras, melecehkan, berbahaya, penuh kebencian, cabul, menyinggung, eksplisit secara seksual, mengancam, atau vulgar saat berkomunikasi dengan pengguna Aplikasi lain atau perwakilan resmi kami, personel layanan pelanggan , moderator papan obrolan, atau sukarelawan.</span></li>' +
  "</ol>" +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">TERLEPAS DARI HAL-HAL DI ATAS, NAMUN, JIKA KAMI SECARA WAJAR PERCAYA BAHWA ANDA TERLIBAT DALAM AKTIVITAS YANG DILARANG DALAM PERJANJIAN INI, SELAIN HAK KAMI UNTUK SEGERA MENANGGUHKAN ATAU MENGHENTIKAN AKUN PENGGUNA ANDA DAN/ATAU MENGHAPUS KARYA DIGITAL ANDA, KAMI JUGA BERHAK ATAS KEBIJAKSANAAN KAMI SENDIRI YANG MUTLAK, TANPA PEMBERITAHUAN ATAU TANGGUNG JAWAB KEPADA ANDA, UNTUK MELAKUKAN SALAH SATU ATAU SEMUA TINDAKAN BERIKUT: (A) MENGANGGAP SETIAP TRANSAKSI YANG TERJADI MELALUI ATAU SEBAGAI HASIL AKTIVITAS TERSEBUT BATAL; DAN/ATAU (B) UNTUK SEGERA MENYINGKAT SETIAP KARYA DIGITAL (TERMASUK NFT DASARNYA) YANG DIBELI ATAU DIPEROLEH SEBAGAI HASIL AKTIVITAS TERSEBUT.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>PENGHENTIAN</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Jika Anda Mengakhiri</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda dapat mengakhiri Ketentuan ini kapan saja dengan membatalkan akun Anda di Aplikasi dan menghentikan akses Anda ke dan penggunaan Aplikasi. Jika Anda membatalkan akun Anda, atau menghentikan Ketentuan ini, Anda tidak akan menerima pengembalian uang untuk pembelian apa pun yang mungkin Anda lakukan melalui Aplikasi &ndash; baik untuk Karya Digital, Paket, atau apa pun.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Jika Kami Mengakhiri</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda setuju bahwa kami, atas kebijakan kami sendiri dan untuk alasan apa pun atau tanpa alasan apa pun, dapat mengakhiri Ketentuan ini dan menangguhkan dan/atau menghentikan akun Anda untuk Aplikasi tanpa ketentuan pemberitahuan sebelumnya. Anda setuju bahwa penangguhan atau penghentian akses Anda ke Aplikasi mungkin tanpa pemberitahuan sebelumnya, dan bahwa kami tidak akan bertanggung jawab kepada Anda atau Pihak Ketiga mana pun atas penangguhan atau penghentian tersebut.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Opsi Lain</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Jika kami menghentikan Ketentuan ini atau menangguhkan atau menghentikan akses Anda ke atau penggunaan Aplikasi karena pelanggaran Anda terhadap Ketentuan ini atau aktivitas yang dicurigai curang, kasar, atau ilegal termasuk namun tidak terbatas pada jika Anda terlibat dalam Aktivitas Terlarang, maka penghentian Persyaratan ini akan menjadi tambahan dari upaya hukum lain.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  "</ol>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Efek Penghentian</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Setelah penghentian atau menjadi berakhirnya Persyaratan ini, baik oleh Anda atau kami, Anda mungkin tidak lagi memiliki akses ke informasi yang telah Anda posting di Aplikasi atau yang terkait dengan akun Anda, dan Anda mengakui bahwa kami tidak berkewajiban untuk mempertahankan informasi tersebut di basis data kami atau untuk meneruskan informasi tersebut kepada Anda atau Pihak Ketiga mana pun.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>PENYANGKALAN</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">ANDA SECARA TEGAS MEMAHAMI DAN MENYETUJUI BAHWA AKSES DAN PENGGUNAAN APLIKASI ANDA SENDIRI, DAN BAHWA APLIKASI DISEDIAKAN "SEBAGAIMANA ADANYA" DAN "SEBAGAIMANA TERSEDIA" TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN TERSIRAT. SEJAUH DIIZINKAN BERDASARKAN HUKUM YANG BERLAKU, KAMI, ANAK PERUSAHAAN KAMI, AFILIASI, DAN PEMBERI LISENSI TIDAK MEMBERIKAN JAMINAN TERSURAT DAN DENGAN INI MENOLAK SEMUA JAMINAN TERSIRAT MENGENAI APLIKASI DAN SETIAP BAGIAN DARINYA, TERMASUK JAMINAN TERSIRAT TIDAK ADANYA PELANGGARAN, KEBENARAN, AKURASI, ATAU KEANDALAN. TANPA MEMBATASI UMUM DARI INDUK PERUSAHAAN, ANAK PERUSAHAAN, AFILIASI, DAN PEMBERI LISENSI KAMI TIDAK MENYATAKAN ATAU MENJAMIN KEPADA ANDA BAHWA: (I) AKSES ATAU PENGGUNAAN APLIKASI ANDA AKAN MEMENUHI KEBUTUHAN ANDA; (II) AKSES ANDA KE ATAU PENGGUNAAN APLIKASI TIDAK AKAN TERGANGGU, TEPAT WAKTU, AMAN ATAU BEBAS DARI KESALAHAN; (III) PENGGUNAAN DATA YANG DISEDIAKAN MELALUI APLIKASI AKAN AKURAT; (IV) APLIKASI ATAU KONTEN, LAYANAN, ATAU FITUR YANG TERSEDIA PADA ATAU MELALUI APLIKASI BEBAS VIRUS ATAU KOMPONEN BERBAHAYA LAINNYA; ATAU (V) BAHWA SETIAP DATA YANG ANDA UNGKAPKAN SAAT MENGGUNAKAN APLIKASI AKAN AMAN. BEBERAPA YURISDIKSI TIDAK MENGIZINKAN PENGECUALIAN JAMINAN TERSIRAT DALAM KONTRAK DENGAN KONSUMEN, SEHINGGA BEBERAPA ATAU SEMUA PENGECUALIAN DI ATAS MUNGKIN TIDAK BERLAKU BAGI ANDA.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">ANDA MENERIMA RISIKO KEAMANAN TERHADAP PEMBERIAN INFORMASI DAN MENJALANKAN AKTIVITAS ONLINE MELALUI INTERNET, DAN MENYETUJUI BAHWA KAMI TIDAK BERTANGGUNG JAWAB ATAS PELANGGARAN KEAMANAN KECUALI KARENA PELANGGARAN YANG KAMI LAKUKAN.</span></p>' +
  "<h2>&nbsp;</h2>" +
  '<p><span style="font-weight: 400;">KAMI TIDAK BERTANGGUNG JAWAB ATAS KERUGIAN YANG ANDA DERITA AKIBAT PENGGUNAAN&nbsp; JARINGAN POLYGON&hellip;, ATAU DOMPET ELEKTRONIK ANDA, TERMASUK NAMUN TIDAK TERBATAS PADA KERUGIAN, KERUSAKAN, ATAU KLAIM YANG TIMBUL DARI: (I,) KESALAHAN PENGGUNA SEPERTI PASSWORD YANG TERLUPAKAN ATAU SMART&nbsp; CONTRACT YANG SALAH DIRANCANG; (II) KEGAGALAN SERVER ATAU KEHILANGAN DATA; (III) FILE WALLET KORUP; ATAU (IV) AKSES ATAU AKTIVITAS TIDAK RESMI OLEH PIHAK KETIGA, TERMASUK NAMUN TIDAK TERBATAS PADA PENGGUNAAN VIRUS, PHISHING, BRUTE-FORCING ATAU SARANA SERANGAN LAINNYA TERHADAP APLIKASI, JARINGAN POLYGON&hellip; ATAU DOMPET ELEKTRONIK APAPUN.</span></p>' +
  '<p><span style="font-weight: 400;">NFT ADALAH ASET DIGITAL INTAGIBLE YANG DICATAT KEPEMILIKANNYA DI JARINGAN POLYGON.... SEMUA SMART CONTRACT DILAKSANAKAN DI BUKU BESAR TERDESENTRALISASI DI JARINGAN POLYGON&hellip;. KAMI TIDAK MEMILIKI KONTROL TERHADAPNYA DAN TIDAK MEMBERIKAN JAMINAN ATAU JANJI TERKAIT SMART CONTRACT. KAMI TIDAK BERTANGGUNGJAWAB ATAS KEHILANGAN KARENA ISSUE FITUR-FITUR BLOCKCHAIN ATAU JARINGAN POLYGON&hellip;, ATAU DOMPET ELEKTRONIK.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li class="ml-2" style="font-weight: 400;" aria-level="1"><strong>PENYELESAIAN SENGKETA</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Pelaksanaan Syarat dan Ketentuan ini tunduk pada hukum Negara Republik Indonesia. Setiap perselisihan atau perbedaan penafsiran yang timbul mengenai Aplikasi ini dan pelaksanaannya akan diselesaikan terlebih dahulu secara musyawarah untuk mufakat. Jika musyawarah untuk mufakat tidak tercapai, selambat-lambatnya dalam waktu 30 (tiga puluh) hari kalender sejak timbulnya perselisihan, maka Pihak yang bersengketa sepakat untuk menyerahkan penyelesaian perselisihan ke ranah Arbitrase melalui lembaga Arbitrase yang diakui.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li class="ml-2" style="font-weight: 400;" aria-level="1"><strong>ASUMSI RISIKO</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Nilai dan volatilitas</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Harga dari aset kolektibel berbasis blockchain sangat volatile dan subjektif dan tidak memiliki nilai intrinsik. Fluktuasi pada harga bisa secara material mempengaruhi nilai dari NFT Anda. Kami tidak menjamin bahwa NFT yang dibeli akan menyimpan nilai awalnya dikarenakan nilai dari aset &hellip; NFT bersifat subjektif dan memiliki banyak faktor di luar dari ekosistem NFT Saya&hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Perhitungan pajak</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Anda bertanggung jawab untuk menentukan jenis pajak yang diaplikasikan pada transaksi di platform NFT Saya&hellip;. Kami tidak bertanggungjawab menentukan pajak yang diaplikasikan atas transaksi Anda.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Ketidakpastian regulasi</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Regulasi terkait teknologi blockchain masih belum pasti. Regulasi baru bisa secara material memiliki dampak dari pengembangan platform NFT Saya&hellip; dan juga utility dari NFT Anda.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Risiko software</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Upgrade pada jaringan Polygon&hellip;, hard fork di jaringan Polygon&hellip;, atau perubahan pada bagaimana transaksi dikonfirmasi di jaringan Polygon&hellip; bisa memiliki efek pada ekosistem NFT Saya&hellip;</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  "</ol>" +
  "</li>" +
  '<li class="ml-2" style="font-weight: 400;" aria-level="1"><strong>KETENTUAN LAIN</strong>' +
  "<h2>&nbsp;</h2>" +
  '<ol class="list-alpha_big ml-4">' +
  '<li style="font-weight: 400;" aria-level="1"><strong>Keseluruhan Perjanjian</strong>' +
  '<p class="mt-2"> <span style="font-weight: 400;">Syarat dan Ketentuan ini serta Kebijakan Privasi kami merupakan keseluruhan Perjanjian antara Anda dan kami dan akan dianggap sebagai Perjanjian yang sah dan terpadu antara Anda dan kami, dan mengatur akses Anda menggunakan Aplikasi dan ketentuan lainnya yang diatur oleh peraturan perundang-undangan.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Tidak Ada Keterlibatan Pihak Ketiga</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Ketentuan ini tidak dan tidak dimaksudkan untuk memberikan hak atau pemulihan apa pun kepada orang atau entitas mana pun selain Anda.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Penafsiran</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Bahasa dalam Ketentuan ini ditafsirkan dengan makna yang wajar</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Keterpisahan</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Jika ada bagian dari Ketentuan ini yang dianggap tidak sah, ilegal, batal, atau tidak dapat diterapkan demi hukum, maka bagian tersebut akan dianggap terpisah dari Ketentuan ini dan tidak akan mempengaruhi validitas atau keberlakuan ketentuan lainnya dari Ketentuan ini. Para Pihak akan menyesuaikan maksud dalam Ketentuan tersebut menjadi sah dan tidak melanggar hukum.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Tidak ada Pengabaian</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Kegagalan atau penundaan kami untuk melaksanakan atau menegakkan hak atau ketentuan apa pun dari Ketentuan ini tidak akan merupakan atau dianggap sebagai pengabaian pelaksanaan atau penegakan hak atau ketentuan tersebut di masa mendatang. Pengesampingan hak atau ketentuan apa pun dari Ketentuan ini hanya akan berlaku jika secara tertulis dan ditandatangani untuk dan atas nama kami oleh perwakilan resmi yang berwenang.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Hukum yang mengatur</strong>' +
  '<p class="mt-2"><span style="font-weight: 400;">Hal-hal yang diatur dan dicantumkan dalam Syarat dan Ketentuan ini tunduk dan ditafsirkan sesuai dengan hukum Negara Republik Indonesia.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  '<li style="font-weight: 400;" aria-level="1"><strong>Penugasan</strong>' +
  '<p><span style="font-weight: 400;">Anda tidak boleh mengalihkan hak atau kewajiban Anda berdasarkan Syarat dan Ketentuan ini, baik berdasarkan hukum atau lainnya, tanpa persetujuan tertulis sebelumnya dari kami. Kami dapat mengalihkan hak dan kewajiban kami berdasarkan Ketentuan ini atas kebijakan kami sendiri kepada afiliasi, atau sehubungan dengan akuisisi, penjualan, atau merger.</span></p>' +
  "<h2>&nbsp;</h2>" +
  "</li>" +
  "</ol>" +
  "</li>" +
  "</ol>";

function ModalTerms({ onCancel, onContinue, ...props }) {
  const { responsive, setShow } = props;
  const listInnerRef = useRef();
  const [buttonDisable, setbuttonState] = useState(true);
  const handleSetButton = () => {
    setbuttonState(!buttonDisable);
  };
  const onScroll = () => {
    if (listInnerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = listInnerRef.current;
      if (
        Math.ceil(scrollTop) + Math.ceil(clientHeight) + 100 >=
        scrollHeight
      ) {
        setbuttonState(false);
      } else {
        setbuttonState(true);
      }
    }
  };

  //   useEffect(()=> console.log(buttonState, "TES"), [buttonState])
  return (
    <Modal {...props}>
      <CardModal
        className={`md:min-h-almost_full min-h-0 min-w-almost_full ${
          responsive && "max-h-modalmax"
        } md:px-8 px-4`}
      >
        {responsive && (
          <div className="w-full justify-end flex mb-4">
            <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />
          </div>
        )}
        <ModalTitleText tx="Syarat dan Ketentuan" />
        <div
          className="max-h-modal_terms mb-8 overflow-y-scroll pl-4"
          onScroll={onScroll}
          ref={listInnerRef}
        >
          <p
            className="font-quicksand font-normal md:text-lg text-base text-hitam w-full mt-4 pr-4 text-justify"
            dangerouslySetInnerHTML={{ __html: tes }}
          ></p>
        </div>
        <div className="flex flex-row justify-start items-center content-center mb-6">
          <ChecklistInput value={!buttonDisable} setValue={handleSetButton} />
          <p className=" ml-3 font-quicksand text-sm font-extralight text-hitam m-0">
            Saya menyetujui seluruh Syarat dan Ketentuan yang berlaku di NFTsaya
          </p>
        </div>
        <div className="grid md:grid-cols-2 grid-cols-1 md:gap-4 gap-2 md:w-full lg:w-3/4 fhd:w-3/4 px-4">
          {!responsive && (
            <RoundedButton
              onClick={onCancel}
              className={`border border-hijau_hutan py-3`}
              color="bg-white"
            >
              <ButtonText
                classstyle={`font-bold text-base`}
                tx={"Kembali"}
                color="text-hijau_hutan"
              />
            </RoundedButton>
          )}
          <RoundedButton
            onClick={onContinue}
            className="md:py-5 py-4"
            disabled={buttonDisable}
            color={buttonDisable ? "bg-gray-400" : "bg-hijau_hutan"}
          >
            <ButtonText classstyle={`font-bold text-base`} tx={"Lanjutkan"} />
          </RoundedButton>
        </div>
      </CardModal>
    </Modal>
  );
}

export default ModalTerms;
