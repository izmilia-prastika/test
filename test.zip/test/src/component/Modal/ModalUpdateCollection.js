import React, { useCallback, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import assetContext from "../../context/Asset/assetContext";
import authContext from "../../context/Auth/authContext";
import collectionContext from "../../context/Collection/collectionContext";
import { ASSET_PATHNAME } from "../../utils/constants/domainTypes";
import { WEB_HOST } from "../../utils/helper";
import ButtonLink from "../Button/ButtonLink";
import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
import InputDropdownWithLabel from "../Input/InputDropdownWithLabel";
import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import TextLink from "../Text/TextLink";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";

const ModalUpdateCollection = ({ show, setShow, responsive, asset }) => {

    const CollectionContext = useContext(collectionContext)
    const AssetContext = useContext(assetContext)
    const AuthContext = useContext(authContext)
    const [collection, setCollection] = useState(null)
    const [loading, setLoading] = useState()
    const navigate = useNavigate()
    useEffect(() => {
        async function fetchData() {

            const res = await CollectionContext?.getCollectionByOwnerId(AuthContext?.auth?.user?.id)

            await setCollection({
                value: asset?.collectionId,
                name: res?.find(collection => collection?.id === asset?.collectionId)?.name
            })
        }
        fetchData()
    }, [show])

    const handleOpenNewTabCollection = useCallback((e) => {
        window.open(`${WEB_HOST}/create-collection`, '_blank', 'noopener,noreferrer')
    }, [])

    const handleRefreshCollection = useCallback(async () => {
        await CollectionContext?.getCollectionByOwnerId(AuthContext?.auth?.user?.id)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [CollectionContext.collections])

    const onSubmit = async () => {
        setLoading(true)
        await AssetContext?.updateAssetById(asset?.id, {
            collectionId: parseInt(collection?.value),
        })
        setShow(false)

        await navigate(ASSET_PATHNAME + '/' + asset?.id, {
            state: { refresh: new Date() }
        })
        setLoading(false)
    }

    return (
        <Modal backdrop={true} show={
            show} setShow={setShow}>
            <CardModal>
                <ModalTitleText tx={"Ubah Koleksi Aset"} />

                <InputDropdownWithLabel tx='marketplace.createNft.collection' data={
                    CollectionContext.collections.map(({ name, id }) => ({
                        value: id,
                        name
                    }))
                }

                    name="collection"
                    className="h-full w-1/2 mb-10"
                    initValue="Pilih Koleksi"
                    topAddon={
                        <div className='items-center justify-start flex'>

                            <ButtonLink onClick={handleOpenNewTabCollection} type="button">
                                <TextLink text="+ Tambah Koleksi Baru" textSize={`${responsive ? "text-sm" : "text-lg"}`} />
                            </ButtonLink>
                        </div>
                    }
                    rightButton={
                        <RoundedButton onClick={handleRefreshCollection} className="ml-4 px-10 py-4 self-start">
                            <ButtonText tx="Perbaharui" />
                        </RoundedButton>
                    }
                    value={collection}
                    setValue={setCollection}
                    subLabel="Pilih koleksi dimana anda berada, *Kategori aset anda akan mengikuti kategori koleksi."
                />

                <ButtonModal
                    disabled={loading}
                    type={"confirmation"}
                    onNoClick={() => setShow(false)}
                    onOkClick={onSubmit}
                    okLabel={loading ? "Loading ..." : "Ubah"}
                    noLabel="Tutup"
                />
            </CardModal>

        </Modal>
    )
}

export default ModalUpdateCollection