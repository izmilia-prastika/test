import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import { useContext } from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ButtonModal from "./ButtonModal";
import P from './P';

const ModalFailValidate = ({title, info, handleNext, txNext = "Bayar Sekarang", ...props}) => {
  const responsive = useContext(ResponsiveContext)

  const handleClick = () => {
      props?.setShow(false)
  }

  return (
    <Modal responsive={responsive} {...props} >
      <CardModal>
        <ModalTitleText text={title} />
        <P className="-mt-0" fontSize="md:text-lg text-base">
          {info}
        </P>
        <div className="grid grid-cols-2 w-full gap-x-4">
          <ButtonModal buttonStyle="py-4 w-full mt-4 border border-hijau_hutan" buttonTextSyle={`text-hijau_hutan`} color="bg-white" onClick={handleClick} tx={"Tutup"} />
          <ButtonModal buttonStyle={`bg-hijau_hutan py-4 w-full mt-4`} onClick={handleNext} tx={txNext} />
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalFailValidate;
