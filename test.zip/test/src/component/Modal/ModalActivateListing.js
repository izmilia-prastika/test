import React from "react";
import { FIX_PRICE } from "../../utils/constants/listedType";
import CardModal from "../Card/CardModal";
import PickerListedType from "../Input/PickerListedType";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import { useForm } from "react-hook-form";

const ModalActivateListing = (props) => {
    const { control } = useForm()
    return (
        <Modal {...props}>
            <CardModal >
                <ModalTitleText tx="Aktifkan Penjualan Asetmu" />
               <PickerListedType control={control} name="listedType" value={FIX_PRICE} />
            </CardModal>
        </Modal>
    )
}

export default ModalActivateListing