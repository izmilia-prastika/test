import React, { useContext, useEffect, useState } from "react";
// import { IdrLogo, MaticTokenIcon } from "../../assets";
import CloseIcon from "../../assets/icon/close_icon";
import socketContext from "../../context/Socket/socketContext";
import { MAXIMUM_PAYMENT_LIMIT } from "../../utils/constants/priceConstant";
// import { IdrLogo, MaticTokenIcon } from "../../assets";
import CardModal from "../Card/CardModal";
// import InputRoundedPicker from "../Input/InputRoundedPicker";
import ModalTitleText from "../Text/ModalTitleText";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";
import P from "./P";

const ModalPickPayment = ({ onSubmitFiat, onSubmitCrypto, asset, ...props }) => {
    const { responsive, setShow } = props;
    const { fontSize = 'text-lg' } = props;

    const [isFiat, setIsFiat] = useState(false)
    const SocketContext = useContext(socketContext)
    const { matic_price } = SocketContext
    const isPriceExceedLimit = asset?.publishedPrice * matic_price > MAXIMUM_PAYMENT_LIMIT

    useEffect(() => {
        setIsFiat(false)
    }, [props?.show])
    
    return (
        <Modal {...props}>
            <CardModal className="w-full">
                <div className="flex w-full justify-end">
                    {responsive && <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />}
                </div>
                <ModalTitleText tx="Pilih Pembayaran" />
                <P fontSize="md:text-lg text-base md:mt-0 -mt-3">
                Penjual Menerima Dua Jenis Pembayaran, pilih salah satu jenis pembayaran dibawah ini
                </P>
                {/* <InputRoundedPicker
                    className={`${fontSize} mb-3`}
                    onClick={(e) => setIsFiat(e)}
                    value={false}
                    isActive={!isFiat}
                    text={"Beli Dengan Matic"}
                    logo={<img alt="Matic Token" src={MaticTokenIcon} className="w-6" />}
                />
                <InputRoundedPicker
                    className={`${fontSize}`}
                    onClick={(e) => setIsFiat(e)}
                    value={true}
                    disabled={isPriceExceedLimit}
                    isActive={isFiat}
                    text={"Beli Dengan Rupiah"}
                    logo={<img alt="Rupiah" src={IdrLogo} className="w-6" />}
                /> */}
                {
                    isPriceExceedLimit && <div className="w-full flex flex-col justify-start mt-4">
                        <p className="text-xs text-red-500">* Harga sudah melebihi Rp 100.000.000,- .Transaksi hanya bisa dilakukan dengan mata uang kripto</p>
                        <p className="text-xs text-red-500"></p>
                    </div>
                }
                <div className="grid md:grid-cols-2 grid-cols-1 w-full gap-x-4 mt-2">
                    <ButtonModal onClick={onSubmitCrypto} tx="Bayar dengan MATIC" />
                    <ButtonModal onClick={onSubmitFiat} tx="Bayar dengan Rupiah" />
                </div>
            </CardModal>
        </Modal>
    )
}

export default ModalPickPayment