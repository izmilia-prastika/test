import React, { useContext, useEffect, useState } from "react";
import NumberFormat from "react-number-format";
import { MaticTokenIcon } from "../../assets";
import CloseIcon from "../../assets/icon/close_icon";
// import InfoIcon from "../../assets/icon/info_icon";
import collectionContext from "../../context/Collection/collectionContext";
import assetContext from "../../context/Asset/assetContext";
import { ERC1155 } from "../../utils/constants/contractType";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import Badges from "../Badges/Badges";
import ButtonModal from './ButtonModal';
import CardModal from "../Card/CardModal";
import GroupLabelForm from "../Form/GroupLabelForm";
import ModalInfo from "../Info/ModalInfo";
import AdderInput from "../Input/AdderInput";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import { IMAGE_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType";
import ReactAudioPlayer from "react-audio-player";
import { Player, ControlBar, BigPlayButton } from 'video-react';
import { useForm } from 'react-hook-form'
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { toast } from "react-toastify";
import { checkERC1155, checkERC721  } from "../../utils/nft-check-helper"

const INITIAL_AMOUNT = 1
const ModalVerifiedCheckout = ({ nft, maticPrice, updateFormInput, responsive, setShow, ...props }) => {
    const { fontSize = 'text-lg' } = props;

    const CollectionContext = useContext(collectionContext)
    const AssetContext = useContext(assetContext)
    const [amount, setAmount] = useState(INITIAL_AMOUNT)
    const [loading, setLoading] = useState(false)
    const [validatedAmount, setValidatedAmount] = useState(null)

    const handleAmountOnchange = (e) => {
        console.log("zap compare handleOnChange", nft?.remainingAmount, validatedAmount)
        if(isNaN(parseFloat(e.target.value))){
            updateFormInput(props => ({ ...props, amount: 0 }))
            setAmount(0)
        }
        else{
            if(parseFloat(e.target.value) <= (validatedAmount ?? nft?.remainingAmount)){
                updateFormInput(props => ({ ...props, amount: parseFloat(e.target.value) }))
                setAmount(parseFloat(e.target.value))
            } 
        }
    }

    const handleAmountAdd = async () => {
        console.log("zap testo", amount <=  validatedAmount ?? nft?.remainingAmount, validatedAmount, nft?.remainingAmount,amount, validatedAmount ?? nft?.remainingAmount)
        if (amount < (validatedAmount ?? nft?.remainingAmount)) {
            await updateFormInput(props => ({ ...props, amount: parseFloat(amount) + 1 }))
            setAmount(parseFloat(amount) + 1)
        }
    }

    const handleAmountSubstract = async () => {
        if (amount > INITIAL_AMOUNT) {
            updateFormInput(props => ({ ...props, amount: parseFloat(amount) - 1 }))
            setAmount(parseFloat(amount) - 1)
        }
    }

    useEffect(() => {
        if(props?.show){
            setAmount(INITIAL_AMOUNT)
        }
    }, [props?.show])

    const handleSubmit = async () => {
        console.log("zap nft", nft)
        const asset = await AssetContext.fetchAssetById(nft?.id)
        if (nft?.tokenStandardType === ERC1155) {
            if (checkERC1155(asset))  {
                toast.error(`Terdapat transaksi yang belum selesai pada asset ini`)
            } else {
                setLoading(true)
                const getBalance = await AssetContext.validateErc1155Amount(nft?.id, validatedAmount ?? nft?.remainingAmount, nft?.itemContractId)
                // const comparator = validatedAmount ?? nft?.remainingAmount
                // console.log("zap compare", getBalance, comparator)
                if (amount <= getBalance) {
                    setValidatedAmount(getBalance)
                    props?.handleBtn()
                    setLoading(false)
                } else {
                    setValidatedAmount(getBalance)
                    toast.error(`
                        Maksimum jumlah serial yang dapat dibeli telah berubah karena telah terjadi transaksi di tempat lain.
                        Silahkan kurangi jumlah serial yang ingin anda beli.
                    `, {
                        className: "w-2/5"
                    })
                    setAmount(0)
                    setLoading(false)
                }
            }
        } else {
            if (checkERC721(asset)) {
                toast.error(`Terdapat transaksi yang belum selesai pada asset ini`)
            } else {
                props?.handleBtn()
            }
        }
    }
    
    const { control } = useForm()
    return (
        <Modal responsive={responsive} setShow={setShow} {...props}>
            <CardModal className="overflow-y-auto max-h-screen w-full">
                <div className="w-full justify-end flex md:mt-0 mt-2">
                    {responsive &&
                        <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />
                    }
                </div>
                <ModalTitleText tx={nft?.tokenStandardType === ERC1155 ? 'Masukkan Jumlah Serial' : 'Konfirmasi Pembelian'} />
                <div className="verified-background w-full md:pt-7 pt-4 border-gray-200 border-t-2 border-b-0">
                    {nft?.tokenStandardType === ERC1155 &&
                        <div className="transform-rotate-180 md:px-10 px-0">
                            <GroupLabelForm Form tx="Jumlah Serial" className="w-full flex justify-end">
                                <AdderInput
                                    control={control}
                                    name="amount"
                                    className={"md:mt-3"}
                                    width={80}
                                    onChange={handleAmountOnchange}
                                    value={amount}
                                    handleClickAdd={handleAmountAdd}
                                    handleClickSubstract={handleAmountSubstract}
                                />
                            </GroupLabelForm>
                        </div>
                    }
                    <div className="inline-flex w-full md:px-10 px-0 transform-rotate-180 mt-4">
                        <div style={{ width: 100, height: 100 }} className="bg-black items-center justify-center flex flex-col md:flex-row mr-5 mb-3 cursor-pointer rounded-xl">
                            {
                                nft?.type === IMAGE_FILE_TYPE ?
                                    <img alt="asset" src={nft?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE} className="rounded-xl object-cover" style={{ maxWidth: 100, maxHeight: 100 }} />
                                    : nft?.type === VIDEO_FILE_TYPE ?
                                        <Player className="object-cover max-h-full max-w-full" fluid={false} height={"100%"} width={"100%"} preload="metadata" src={nft?.thumbnailUrl}>
                                            <BigPlayButton className="custom-big-play-button" />
                                            <ControlBar autoHide={false} disableDefaultControls={true} />
                                        </Player>
                                        :
                                        <ReactAudioPlayer
                                            style={{width:'100%'}}
                                            src={nft?.thumbnailUrl}
                                            autoPlay={false}
                                            controls
                                        />}
                        </div>
                        <div className="flex flex-col items-start ml-4">
                            <p className="font-quicksand font-bold text-sm text-hijau_tua">{CollectionContext?.collections.find(collection => collection?.id === nft?.collectionId)?.name}</p>
                            <p className="font-quicksand font-bold text-base text-hitam">{nft?.name}</p>
                            <div className="w-full flex justify-start">
                                <Badges width="36" value={`Royalti ${nft?.royalti ?? 0} % untuk pembuat aset`} />
                            </div>
                        </div>
                    </div>

                </div>
                {nft?.tokenStandardType === ERC1155 &&

                    <ModalInfo
                        labelStyle={`${fontSize} text-sm text-hitam`}
                        label={"Harga Satuan"}
                        rightContent={
                            <div className="flex flex-col">
                                <NumberFormat decimalScale={0} value={Math.ceil(nft?.publishedPrice ? nft?.publishedPrice * maticPrice : nft?.price * maticPrice)} displayType={'text'} thousandSeparator={true}
                                    renderText={(value, props) =>
                                        <>
                                            <div className="inline-flex items-center justify-end">
                                                <img src={MaticTokenIcon} className="h-4 w-4 mr-2" alt="matic"/>
                                                <p className="font-quicksand font-bold text-base text-hitam">{parseFloat(nft?.publishedPrice).toFixed(2)}</p>
                                            </div>
                                            <p className="font-quicksand font-normal text-sm text-gray-400">IDR {value}</p>

                                        </>
                                    }
                                />
                            </div>
                        } />
                }
                <ModalInfo
                    labelStyle={`${fontSize} text-sm text-hitam`}
                    label={"Sub Total"}
                    rightContent={
                        <div className="flex flex-col">
                            <NumberFormat decimalScale={0} value={Math.ceil(nft?.publishedPrice ? parseFloat(amount) * nft?.publishedPrice * maticPrice : parseFloat(amount) * nft?.price * maticPrice)} displayType={'text'} thousandSeparator={true}
                                renderText={(value, props) =>
                                    <>
                                        <div className="inline-flex items-center justify-end">
                                            <img src={MaticTokenIcon} className="h-4 w-4 mr-2" alt="matic"/>
                                            <p className="font-quicksand font-bold text-base text-hitam">{parseFloat(parseFloat(amount) * nft?.publishedPrice).toFixed(2)}</p>
                                        </div>
                                        <p className="font-quicksand font-normal text-sm text-gray-400">IDR {value}</p>


                                    </>
                                }
                            />
                        </div>
                    } />

                <ModalInfo
                    labelStyle={`${fontSize} font-bold`}
                    label={"Total"}
                    rightContent={
                        <div className="flex flex-col">
                            <NumberFormat decimalScale={0} value={Math.ceil(nft?.publishedPrice ? parseFloat(amount) * nft?.publishedPrice * maticPrice : parseFloat(amount) * nft?.price * maticPrice)} displayType={'text'} thousandSeparator={true}
                                renderText={(value, props) =>
                                    <>
                                        <div className="inline-flex items-center justify-end">
                                            <img src={MaticTokenIcon} className="h-4 w-4 mr-2" alt="matic"/>
                                            <p className="font-quicksand font-bold text-base text-hitam">{parseFloat(parseFloat(amount) * nft?.publishedPrice).toFixed(2)}</p>
                                        </div>
                                        <p className="font-quicksand font-normal text-sm text-gray-400">IDR {value}</p>

                                    </>
                                }
                            />
                        </div>
                    } />
                <div className="grid md:grid-cols-2 grid-cols-1 w-full gap-x-4 mt-6">
                    {!responsive && <ButtonModal tx="Kembali" buttonTextSyle="text-hijau_hutan" color="bg-white" buttonStyle="border border-hijau_hutan px-10 py-4" onClick={() => setShow(false)} />}
                    <ButtonModal onClick={handleSubmit} tx="Bayar Sekarang"/>
                </div>
            </CardModal>
            <Modal backdrop={false} show={loading}>
                <div className="flex w-full h-screen justify-center items-center">
                <SpinCircleLogo black={"true"} type="big" />
                </div>
            </Modal>
        </Modal>
    )
}

export default ModalVerifiedCheckout