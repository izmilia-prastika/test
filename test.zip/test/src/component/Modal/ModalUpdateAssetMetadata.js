import React, { useCallback, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
// import assetContext from "../../context/Asset/assetContext";
// import authContext from "../../context/Auth/authContext";
// import collectionContext from "../../context/Collection/collectionContext";
import { IMAGE_FILE_TYPE, MUSIC_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType";
// import { ASSET_PATHNAME } from "../../utils/constants/domainTypes";
// import { WEB_HOST } from "../../utils/helper";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import InputDropdownWithLabel from "../Input/InputDropdownWithLabel";
import InputFileWithLabel from "../Input/InputFileWithLabel";
import InputWithLabel from "../Input/InputWithLabel";
import TextareaWithLabel from "../Input/TextareaWithLabel";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
// import TextLink from "../Text/TextLink";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";

const IMAGE = "image"
const VIDEO = "video"
const SUPPORTED_FORMAT = ["jpeg", "jpg", "png", "mpeg", "mp4", "gif", "webp"]
const VIDEO_SIZE_LIMIT = 104857600
const IMAGE_SIZE_LIMIT = 20971520

const ModalUpdateAssetMetadata = ({ show, setShow, handleSubmit, asset,updateFormInput }) => {

    // const CollectionContext = useContext(collectionContext)
    // const AssetContext = useContext(assetContext)
    // const AuthContext = useContext(authContext)
    const [thumbnailUrl, setThumbnailUrl] = useState(null)
    const [fileType, setFileType] = useState(1)
    // const [collection, setCollection] = useState(null)
    const [loading, setLoading] = useState()
    // const navigate = useNavigate()
    const [loadingFile, setLoadingFile] = useState(false)
    const [input, updateInput] = useState({  name: '', description: ''})
    async function onChange(e) {
        setLoadingFile(true)
        const file = e.target.files[0]
        const type = file.type.split("/")[0]
        const format = file.type.split("/")[1]
        const size = file.size
        if (SUPPORTED_FORMAT.includes(format)) {
            if (type === VIDEO) {
                if (size <= VIDEO_SIZE_LIMIT) {
                    setFileType(VIDEO_FILE_TYPE)
                    setThumbnailUrl(file)
                } else {
                    toast.info(`Ukuran file video tidak boleh lebih dari 100mb`)
                }
            } else {
                if (size <= IMAGE_SIZE_LIMIT) {
                    if (type === IMAGE) {
                        setFileType(IMAGE_FILE_TYPE)
                    } else {
                        setFileType(MUSIC_FILE_TYPE)
                    }
                    setThumbnailUrl(file)
                } else {
                    toast.info("Ukuran file tidak boleh lebih dari 20 mb")
                }
            }
        } else {
            toast.info("Format file tidak mendukung")
        }
        setLoadingFile(false)
    }

    const onSubmit = async () => {
        setLoading(true)
        updateFormInput({
            ...input,
            thumbnailUrl,
            type: fileType,
        })
        handleSubmit({amount:0})
        // handleSubmit({...input,thumbnailUrl},asset)
        // setShow(false)

        /* await navigate(ASSET_PATHNAME + '/' + asset?.id, {
            state: { refresh: new Date() }
        }) */
        setLoading(false)
    }

    return (
        <Modal
            wide={true}
            backdrop={true}
            show={show}
            setShow={setShow}>
            <CardModal className='overflow-y-auto max-h-modalmax_payment_fiat md:h-auto h-modalmax' width={500}>
                <ModalTitleText tx={"Ubah Metadata Aset"} />

                
                <InputFileWithLabel
                        labelConstraint={`
                    Format Gambar: JPEG, PNG, GIF maks 20 mb\nFormat Musik: mp3 maks: 20 mb\nFormat Video: mp4 maks 100 mb
                    `}
                        onChange={onChange}
                        name="thumbnailUrl"
                        value={thumbnailUrl}
                        type={fileType}
                        loading={loadingFile}
                        className="w-full mb-10"
                        classstyle="font-quicksand text-base text-hitam md:mb-4 mb-4 md:mr-0 mr-auto font-extrabold "
                        tx='marketplace.createNft.upload' 
                        leftLabel={true}
                        />
                <InputWithLabel
                    onChange={e => {
                        updateInput({ ...input, name: e.target.value })
                    }}
                    placeholder="Masukkan nama asetmu"
                    className="h-full w-full mb-10"
                    name="name"
                    tx='marketplace.createNft.name' />
                <TextareaWithLabel
                    name="description"
                    onChange={e => updateInput({ ...input, description: e.target.value })}
                    className="h-full w-full mb-10"
                    placeholder="Masukkan deskripsi asetmu"
                    tx='marketplace.createNft.description' />

                <ButtonModal
                    disabled={loading}
                    type={"confirmation"}
                    onNoClick={() => setShow(false)}
                    onOkClick={onSubmit}
                    okLabel={loading ? "Loading ..." : "Ubah"}
                    noLabel="Tutup"
                />
            </CardModal>

        </Modal>
    )
}

export default ModalUpdateAssetMetadata