import React from "react";
// import clasNames from 'classnames'

const Modal = ({ backdrop = true,disablePropagation, topModal=200, positionMobile="items-end", wide, ...props }) => {
    const { children, show, setShow } = props
    return (
        <div onClick={() => backdrop && setShow(false)} className={`bg-black bg-opacity-50 fixed inset-0 overflow-y-auto min-h-full z-50 ${show ? "flex" : "hidden"} z-30 justify-center ${positionMobile} md:items-center `} id="overlay">
            <div className={`w-full md:flex md:justify-center md:items-center ${wide ? "md:max-w-3xl" : "md:max-w-xl" }`} onClick={(e) => !disablePropagation && e.stopPropagation()}>
                {children}
            </div>
        </div>
    )
}

export default Modal