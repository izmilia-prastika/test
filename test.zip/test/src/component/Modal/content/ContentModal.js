import { intervalToDuration } from "date-fns";
import NumberFormat from "react-number-format";
import { MaticTokenIcon } from "../../../assets";
import { AUCTION } from "../../../utils/constants/listedType";
import Badges from "../../Badges/Badges";
import ModalInfo from "../../Info/ModalInfo";
import { Player, ControlBar, BigPlayButton } from "video-react";
import ReactAudioPlayer from "react-audio-player";
import {
  IMAGE_FILE_TYPE,
  VIDEO_FILE_TYPE,
} from "../../../utils/constants/assetFileType";
import socketContext from "../../../context/Socket/socketContext";
import { useContext } from "react";

const dataPayment = [
  {
    value: "BRI",
    name: "BRI Virtual Account",
  },
  {
    value: "BNI",
    name: "BNI Virtual Account",
  },
  {
    value: "MANDIRI",
    name: "Mandiri Virtual Account",
  },
  {
    value: "PERMATA",
    name: "Permata Virtual Account",
  },
  {
    value: "OVO",
    name: "OVO",
  },
  {
    value: "SHOPEEPAY",
    name: "Shopee Pay",
  },
  {
    value: "DANA",
    name: "DANA",
  },
  {
    value: "LINKAJA",
    name: "Link Aja",
  },
  {
    value: "QRIS",
    name: "QRIS",
  },
];

const remaining = (endDate) => {
  const now = new Date();
  const end = new Date(endDate);
  return intervalToDuration({
    start: now,
    end: end,
  });
};

const addVirtualAccount = (paymentMethod) => {
  const methodePayment = dataPayment.filter(el => el.value === paymentMethod)
  const finalPayment = methodePayment[0]
  return finalPayment?.name
};

const ListingContent = ({ data, formInput }) => {
  let interval;
  let days;
  let payment;
  const isFiat = formInput?.isFiat === true
  const isTypeListing = formInput?.listedType !== AUCTION;
  if (!isTypeListing && formInput?.duration) {
    interval = remaining(formInput?.duration);
    days = interval?.months * 30 + interval?.days;
  }
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={isTypeListing ? "Harga jual aset" : "Harga lelang"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {formInput?.price}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={isTypeListing ? "Penjualan dengan rupiah" : "Durasi Lelang"}
        rightContent={
          <div className="flex">
            {isTypeListing ? (
              <p className="font-quicksand font-bold text-base text-hitam">
                {formInput?.isFiatTransaction ? "Aktif" : "Tidak Aktif"}
              </p>
            ) : (
              <p>
                {days === 0
                  ? "Kurang dari 1 hari"
                  : `Sekitar ${days} hari lagi`}
              </p>
            )}
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const UpdateMetadataContent = ({formInput}) => {
  let payment
  const isFiat = formInput?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(formInput?.paymentMethod)
  }
  return (
    <div className="flex flex-col justify-center items-center w-full">
      <div className="flex flex-col mr-5 bg-black items-center justify-center rounded-xl" style={{ width: 100, height: 100 }}>
        {formInput?.type === IMAGE_FILE_TYPE ? (
          <img
            alt="asset"
            src={
              formInput?.thumbnailUrl instanceof Blob
                ? URL.createObjectURL(formInput?.thumbnailUrl)
                : formInput?.thumbnailUrl
            }
            className="rounded-xl object-cover"
            style={{ maxWidth: 100, maxHeight: 100 }}
          />
        ) : formInput?.type === VIDEO_FILE_TYPE ? (
          <Player
            className="object-cover max-h-full max-w-full"
            fluid={false}
            height={"100%"}
            width={"100%"}
            preload="metadata"
            src={formInput?.thumbnailUrl}
          >
            <BigPlayButton className="custom-big-play-button" />
            <ControlBar autoHide={false} disableDefaultControls={true} />
          </Player>
        ) : (
          <ReactAudioPlayer
            style={{ width: "100%" }}
            src={formInput?.thumbnailUrl}
            autoPlay={false}
            controls
          />
        )}
      </div>
      <div className="flex flex-col w-full">
        <ModalInfo
          labelStyle={"text-base text-hitam"}
          label={"Nama Aset"}
          rightContent={
            <div className="flex flex-col">
              <p className="font-quicksand font-bold text-base text-hitam">
                {formInput?.name}
              </p>
            </div>
          }
        />
        <ModalInfo
          labelStyle={"text-base text-hitam"}
          label={"Deskripsi Aset"}
          rightContent={
            <div className="flex flex-col">
              <p className="font-quicksand font-bold text-base text-hitam">
                {formInput?.description}
              </p>
            </div>
          }
        />
        {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={formInput?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={formInput?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(formInput?.adminFee) + parseInt(formInput?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
      </div>
    </div>
  )
}

const CancelListingContent = ({ data }) => {
  let payment;
  const isFiat = data?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga jual aset"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.price}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Penjualan dengan rupiah"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.isFiatTransaction ? "Aktif" : "Tidak Aktif"}
            </p>
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const CancelMakeOfferContent = ({ data }) => {
  let payment;
  const isFiat = data?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const AcceptMakeOffer = ({ data, formInput, assetBid }) => {
  let payment;
  const isFiat = formInput?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(formInput?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga penawaran"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {assetBid?.bidPrice}
            </p>
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={formInput?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={formInput?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(formInput?.adminFee) + parseInt(formInput?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const CancelAuctionContent = ({ data }) => {
  let payment;
  const isFiat = data?.isFiat === true 
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga yang dilelang"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.price}
            </p>
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const CancelBidderAuctionContent = ({ data }) => {
  let payment;
  const isFiat = data?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const CreateAssetContent = ({ data }) => {
  let payment;
  const isFiat = data?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <div className="flex flex-col mb-6 w-full justify-center items-center">
      <div className="inline-flex w-full md:px-10 px-0 mt-4">
        <div
          style={{ width: 100, height: 100 }}
          className="bg-black items-center justify-center flex mr-5 mb-3 cursor-pointer  rounded-xl"
        >
          {data?.type === IMAGE_FILE_TYPE ? (
            <img
              alt="asset"
              src={
                data?.thumbnailUrl instanceof Blob
                  ? URL.createObjectURL(data?.thumbnailUrl)
                  : data?.thumbnailUrl
              }
              className="rounded-xl object-cover"
              style={{ maxWidth: 100, maxHeight: 100 }}
            />
          ) : data?.type === VIDEO_FILE_TYPE ? (
            <Player
              className="object-cover max-h-full max-w-full"
              fluid={false}
              height={"100%"}
              width={"100%"}
              preload="metadata"
              src={data?.thumbnailUrl}
            >
              <BigPlayButton className="custom-big-play-button" />
              <ControlBar autoHide={false} disableDefaultControls={true} />
            </Player>
          ) : (
            <ReactAudioPlayer
              style={{ width: "100%" }}
              src={data?.thumbnailUrl}
              autoPlay={false}
              controls
            />
          )}
        </div>
        <div className="flex flex-col items-start ml-4">
          <p className="font-quicksand font-bold text-base text-hijau_tua">
            {data?.collection?.name ?? "Tidak masuk koleksi"}
          </p>
          <p className="font-quicksand font-bold text-base text-hitam mb-2">
            {data?.name}
          </p>
          <Badges
            // icon={<InfoIcon className="mr-2" />}
            width="36"
            value={`Royalti ${data?.royalti ?? 0} % untuk pembuat aset`}
          />
        </div>
      </div>
      <div className="verified-background transform-rotate-180 px-10 py-4 border-t w-full">
        <p className="transform-rotate-180 font-quicksand font-medium text-hitam_2">
          {data?.description}
        </p>
      </div>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Aktifkan Penjualan"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.isListed ? "Aktif" : "Tidak Aktif"}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Jumlah Serial"}
        rightContent={
          <div className="flex flex-col">
            <NumberFormat
              decimalScale={0}
              value={data?.amount}
              displayType={"text"}
              thousandSeparator={true}
              renderText={(value, props) => (
                <>
                  <p className="font-quicksand font-bold text-base text-hitam">
                    {value}
                  </p>
                </>
              )}
            />
          </div>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </div>
  );
};

const AcceptAuctionContent = ({ data, assetBid }) => {
  let payment;
  const isFiat = data?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga penawaran tertinggi"}
        rightContent={assetBid?.assetsAuctionDetailsByAssetAuctionId?.nodes?.[0]?.bidPrice ? 
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {assetBid?.assetsAuctionDetailsByAssetAuctionId?.nodes?.[0]?.bidPrice}
            </p>
          </div> : <p className="font-quicksand font-bold text-base text-hitam">
              Tidak ada penawaran
            </p>
        }
      />
      {isFiat && (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      )}
    </>
  );
};

const MakeOfferContent = ({ data, price, amount }) => {
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga yang kamu tawarkan"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {price}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Jumlah Serial"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {amount}
            </p>
          </div>
        }
      />
    </>
  );
};

const BidContent = ({ data, price }) => {
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Harga yang kamu ajukan"}
        rightContent={
          <div className="flex items-center">
            <img src={MaticTokenIcon} alt="" className="h-4 w-4 mr-2" />
            <p className="font-quicksand font-bold text-base text-hitam">
              {price}
            </p>
          </div>
        }
      />
    </>
  );
};

const BankContent = ({ data }) => {
  let payment = addVirtualAccount(data?.paymentMethod)
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Metode Pembayaran"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {payment}
            </p>
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Gas Fee"}
        rightContent={
          <div className="flex flex-col">
            <NumberFormat
              decimalScale={0}
              value={data?.gasFee}
              displayType={"text"}
              thousandSeparator={true}
              renderText={(value) => (
                <p className="font-quicksand font-bold text-base text-hitam">
                  Rp. {value}
                </p>
              )}
            />
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Biaya Admin"}
        rightContent={
          <div className="flex flex-col">
            <NumberFormat
              decimalScale={0}
              value={data?.adminFee}
              displayType={"text"}
              thousandSeparator={true}
              renderText={(value) => (
                <p className="font-quicksand font-bold text-base text-hitam">
                  Rp. {value}
                </p>
              )}
            />
          </div>
        }
      />
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Total Pembayaran"}
        rightContent={
          <div className="flex flex-col">
            <NumberFormat
              decimalScale={0}
              value={parseInt(data?.adminFee) + parseInt(data?.gasFee)}
              displayType={"text"}
              thousandSeparator={true}
              renderText={(value) => (
                <p className="font-quicksand font-bold text-base text-hitam">
                  Rp. {value}
                </p>
              )}
            />
          </div>
        }
      />
    </>
  );
};

const BuyContent = ({ data, formInput }) => {
  const SocketContext = useContext(socketContext);
  const { matic_price } = SocketContext;
  let payment;
  const isFiat = formInput?.isFiat === true
  if(isFiat){
    payment = addVirtualAccount(data?.paymentMethod)
  }
  return (
    <>
      <ModalInfo
        labelStyle={"text-base text-hitam"}
        label={"Nama Aset"}
        rightContent={
          <div className="flex flex-col">
            <p className="font-quicksand font-bold text-base text-hitam">
              {data?.name}
            </p>
          </div>
        }
      />
      {isFiat ? (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Metode Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {payment}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Gas Fee"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.gasFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Biaya Admin"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.adminFee}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Harga Aset"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={data?.publishedPrice * matic_price * formInput?.amount}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={
                    parseInt(data?.adminFee) +
                    parseInt(data?.gasFee) +
                    parseInt(
                      data?.publishedPrice * matic_price * formInput?.amount
                    )
                  }
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value) => (
                    <p className="font-quicksand font-bold text-base text-hitam">
                      Rp. {value}
                    </p>
                  )}
                />
              </div>
            }
          />
        </>
      ) : (
        <>
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Harga Satuan"}
            rightContent={
              <div className="flex flex-col">
                <NumberFormat
                  decimalScale={0}
                  value={Math.ceil(
                    data?.publishedPrice
                      ? data?.publishedPrice * matic_price
                      : data?.price * matic_price
                  )}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value, props) => (
                    <>
                      <div className="inline-flex items-center justify-end">
                        <img
                          src={MaticTokenIcon}
                          className="h-4 w-4 mr-2"
                          alt="matic"
                        />
                        <p className="font-quicksand font-bold text-base text-hitam">
                          {parseFloat(data?.publishedPrice).toFixed(2)}
                        </p>
                      </div>
                    </>
                  )}
                />
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Jumlah Serial"}
            rightContent={
              <div className="flex flex-col">
                <p className="font-quicksand font-bold text-base text-hitam">
                  {formInput?.amount}
                </p>
              </div>
            }
          />
          <ModalInfo
            labelStyle={"text-base text-hitam"}
            label={"Total Pembayaran"}
            rightContent={
              <div className="flex flex-col">
                <div className="inline-flex items-center justify-end">
                  <img
                    src={MaticTokenIcon}
                    className="h-4 w-4 mr-2"
                    alt="matic"
                  />
                  <p className="font-quicksand font-bold text-base text-hitam">
                    {parseFloat(
                      parseInt(formInput?.amount) *
                        parseFloat(data?.publishedPrice)
                    ).toFixed(2)}
                  </p>
                </div>
              </div>
            }
          />
        </>
      )}
    </>
  );
};

export {
  BuyContent,
  BankContent,
  ListingContent,
  CancelListingContent,
  CancelMakeOfferContent,
  AcceptMakeOffer,
  CancelAuctionContent,
  CancelBidderAuctionContent,
  CreateAssetContent,
  AcceptAuctionContent,
  MakeOfferContent,
  BidContent,
  UpdateMetadataContent
};
