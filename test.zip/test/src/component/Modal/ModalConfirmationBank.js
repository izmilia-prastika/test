import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import ButtonModal from "./ButtonModal";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const ListData = ({title, value}) => {
    return(
    <div className="flex justify-between ">
        <p className="font-quicksand text-base text-hitam">{title}</p>
        <p className="font-quicksand text-base text-hitam font-semibold">{value}</p>
    </div>
    )
}

const ModalConfirmationBank = ({
  isFound, 
  isMatch,
  confirmedBank,
  handleAdd,
  handleEdit,
  setShowModalInput,
  isEdit,
  loading,
  ...props
}) => {
  const handleEditUlang = () => {
      props.setShow(false)
      setShowModalInput(true)
  }

  return (
    <Modal {...props}>
      <CardModal>
        <ModalTitleText tx={isFound ? isMatch ? "Konfirmasi Penyimpanan Rekening" : "Data Ditemukan Namun Tidak Cocok" : "Data Rekening Tidak ditemukan"} />
        <p className="font-quicksand font-normal text-hitam_2 text-lg mb-6">{isFound ? isMatch ?
        "Data rekening kamu berhasil divalidasi. Berikut data yang akan kamu simpan kedalam blockchain" : "Data rekening kamu berhasil divalidasi, namun terdapat ketidakcocokan antara nama dan nomor rekening. Silahkan ulangi proses" : 
        "Rekening bank anda tidak ditemukan. Silahkan coba ulang dan cek kembali data rekening"}</p>
            <div className={`flex flex-col gap-y-4 w-full mb-8 bg-gray-100 p-4 rounded-md`}>
                <ListData title={"Nama Bank"} value={confirmedBank?.bankName}/>
                <ListData title={"Nomor Rekening"} value={confirmedBank?.accountNumber}/>
                <ListData title={"Atas Nama"} value={confirmedBank?.holderName}/>
            </div>
            <div className="grid grid-cols-2 w-full gap-x-6">
                    <ButtonModal 
                      buttonStyle="py-4 w-full mt-4 border border-hijau_hutan" 
                      color="bg-white" 
                      disabled={loading} 
                      onClick={() => props?.setShow(false)} 
                      tx={isFound ? "Kembali" : "Tutup"}
                      buttonTextSyle={`text-hijau_hutan`}/>
                    <ButtonModal 
                      buttonStyle={`${!loading ? "bg-hijau_hutan" : "bg-hijau_kristal"} py-4 w-full mt-4`} 
                      disabled={loading} 
                      tx={(isFound && isMatch) ? "Simpan" : "Edit Ulang"}
                      onClick={(isFound && isMatch) ? isEdit ? handleEdit : handleAdd : handleEditUlang}
                      children={loading && <SpinCircleLogo />} 
                      buttonTextSyle={loading && "mr-4"}/>
            </div>
      </CardModal>
    </Modal>
  );
};

export default ModalConfirmationBank;
