import React from "react";
import ListingForm from "../Form/ListingForm";
import Modal from "./Modal";

const ModalListingForm = ({ show, setShow, ...props }) => {
    return (
        <Modal disablePropagation={true} backdrop={false} show={show} setShow={setShow} responsive={props.responsive}>
            <ListingForm {...props} show={show} setShow={setShow}/>
        </Modal>
    )
}

export default ModalListingForm