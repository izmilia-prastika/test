import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import { useContext } from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ButtonModal from "./ButtonModal";
import P from './P';
import { useNavigate } from "react-router-dom";
import QRCode from "qrcode.react";
import CloseIcon from "../../assets/icon/close_icon";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo"
// import RoundedButton from "../Button/RoundedButton";
// import ButtonText from "../Text/ButtonText";

const ModalQrCode = ({code, title, caption, downloadFunc, ...props}) => {
  const responsive = useContext(ResponsiveContext)
  const navigate = useNavigate()

  return (
    <Modal responsive={responsive} {...props} >
      <CardModal>
        <div className="w-full justify-end flex">
            <CloseIcon divClass="cursor-pointer" onClick={() => props.setShow(false)}/>
        </div>
        <ModalTitleText text={title} />
        <QRCode id="myQR" value={code} size={200} includeMargin={true}/>
        <P fontSize="md:text-lg text-base">
          {caption}
        </P>
        <ButtonModal onClick={downloadFunc} tx="Download QR" />
      </CardModal>
    </Modal>
  );
};

ModalQrCode.defaultProps = {
    code : '0931-asdakj-12381',
    title: 'Modal Kode QR',
    caption: 'Silahkan scan atau download QR Code berikut'
}

export default ModalQrCode;
