import {
  IMAGE_FILE_TYPE,
  VIDEO_FILE_TYPE,
} from "../../utils/constants/assetFileType";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import { useContext } from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import ButtonModal from "./ButtonModal";
import TYPE_TRANSACTION from "../../utils/constants/typeTransaction";
import { AUCTION } from "../../utils/constants/listedType";
import {
  AcceptAuctionContent,
  AcceptMakeOffer,
  BankContent,
  BidContent,
  BuyContent,
  CancelAuctionContent,
  CancelBidderAuctionContent,
  CancelListingContent,
  CancelMakeOfferContent,
  CreateAssetContent,
  ListingContent,
  MakeOfferContent,
  UpdateMetadataContent,
} from "./content/ContentModal";
import { Player, ControlBar, BigPlayButton } from "video-react";
import ReactAudioPlayer from "react-audio-player";

const ModalSummaryTxn = ({
  data,
  handleContinue,
  typeTxn,
  formInput,
  assetBid,
  amount,
  isFiat,
  dataFiat,
  setShowFiatModal,
  ...prop
}) => {
  let dataFix;
  const responsive = useContext(ResponsiveContext);
  const isTypeListing = formInput?.listedType !== AUCTION;
  const isListing = typeTxn === TYPE_TRANSACTION.LISTING;
  const isCancelListing = typeTxn === TYPE_TRANSACTION.CANCEL_LISTING;
  const isCancelMakeOffer = typeTxn === TYPE_TRANSACTION.CANCEL_MAKE_OFFER;
  const isAcceptOffer = typeTxn === TYPE_TRANSACTION.ACCEPT_MAKE_OFFER;
  const isCancelAuction = typeTxn === TYPE_TRANSACTION.CANCEL_AUCTION;
  const isCancelBidderAuction = typeTxn === TYPE_TRANSACTION.CANCEL_BID_AUCTION;
  const isCreateAsset = typeTxn === TYPE_TRANSACTION.CREATE_ASSET;
  const isAccepAuction = typeTxn === TYPE_TRANSACTION.ACCEPT_AUCTION;
  const isMakeOffer = typeTxn === TYPE_TRANSACTION.MAKE_OFFER;
  const isBid = typeTxn === TYPE_TRANSACTION.BID;
  const isEditBank = typeTxn === TYPE_TRANSACTION.EDIT_BANK;
  const isAddBank = typeTxn === TYPE_TRANSACTION.ADD_BANK;
  const isBuy = typeTxn === TYPE_TRANSACTION.BUY;
  const isUpdateMetadata = typeTxn === TYPE_TRANSACTION.EDIT_METADATA
  let typeTitle;
  let typeCaption;
  const captionBank = 'Kamu akan membayar gas fee untuk menyimpan data ke dalam blockchain. Silahkan pastikan data pembayaran berikut';
  if (data.length === 0) {
    dataFix = assetBid?.assetsBidByAssetBidId?.assetByAssetId;
  } else {
    dataFix = isFiat ? dataFiat : data;
  }
  switch (typeTxn) {
    case TYPE_TRANSACTION.CANCEL_BID_AUCTION:
      typeTitle = "Konfirmasi Pembatalan Penawaran Lelang";
      typeCaption = "membatalkan penawaran lelang";
      break;
    case TYPE_TRANSACTION.LISTING:
      isTypeListing
        ? (typeCaption = "mengaktifkan penjualan")
        : (typeCaption = "mengaktifkan lelang");
      isTypeListing
        ? (typeTitle = "Konfirmasi Pengaktifan Penjualan")
        : (typeTitle = "Konfirmasi Pengaktifan Lelang");
      break;
    case TYPE_TRANSACTION.CREATE_ASSET:
      typeTitle = "Konfirmasi Pembuatan Aset";
      typeCaption = "membuat";
      break;
    case TYPE_TRANSACTION.CANCEL_LISTING:
      typeTitle = "Konfirmasi Pembatalan Penjualan";
      typeCaption = "membatalkan penjualan";
      break;
    case TYPE_TRANSACTION.CANCEL_MAKE_OFFER:
      typeTitle = "Konfirmasi Pembatalan Penawaran";
      typeCaption = "membatalkan penawaran";
      break;
    case TYPE_TRANSACTION.CANCEL_AUCTION:
      typeTitle = "Konfirmasi Pembatalan Lelang";
      typeCaption = "membatalkan lelang untuk";
      break;
    case TYPE_TRANSACTION.ACCEPT_MAKE_OFFER:
      typeTitle = "Konfirmasi Terima Penawaran";
      typeCaption = "menerima penawaran untuk";
      break;
    case TYPE_TRANSACTION.ACCEPT_AUCTION:
      typeTitle = "Konfirmasi Penyelesaian Lelang";
      typeCaption = "menyelesaikan lelang untuk";
      break;
    case TYPE_TRANSACTION.MAKE_OFFER:
      typeTitle = "Konfirmasi Penawaran Aset";
      typeCaption = "menawar untuk";
      break;
    case TYPE_TRANSACTION.BID:
      typeTitle = "Konfirmasi Lelang Aset";
      typeCaption = "mengikuti lelang untuk";
      break;
    case TYPE_TRANSACTION.EDIT_BANK:
      typeTitle = "Konfirmasi Pembayaran Gas Bank";
      break;
    case TYPE_TRANSACTION.ADD_BANK:
      typeTitle = "Konfirmasi Pembayaran Gas Bank";
      break;
    case TYPE_TRANSACTION.BUY:
      typeTitle = "Konfirmasi Pembelian Aset";
      typeCaption = "membeli";
      break;
    case TYPE_TRANSACTION.EDIT_METADATA:
      typeTitle= "Ubah Metadata Aset"
      typeCaption = "mengubah metadata untuk"
      break;
    default:
      break;
  }
  const handleCancel = () => {
    prop.setShow(false);
  };

  const handleCancelFiat = () => {
    prop.setShow(false)
    setShowFiatModal(true)
  }

  return (
    <Modal {...prop}>
      <CardModal className="overflow-y-auto max-h-modalmax_payment_fiat md:h-auto h-modalmax w-full md:py-9 py-0 md:pb-0 pb-6">
        <div className="flex flex-col mb-6 w-full justify-center items-center">
          <ModalTitleText tx={typeTitle} classtyle="text-center self-center" />
          <div>
          {isEditBank || isAddBank ? 
            <p className="font-quicksand font-regular text-lg text-hitam_2 text-center mb-6">
              {captionBank}
            </p> : 
            <p className="font-quicksand font-regular text-lg text-hitam_2 text-center mb-6">
              Kamu akan {typeCaption} aset berikut dengan pembayaran 
              menggunakan {isFiat ? 'rupiah' : 'matic'}
            </p>
          }
          </div>
          <div className="flex flex-col w-full justify-center items-center">
            {(!isCreateAsset && !isEditBank && !isAddBank && !isUpdateMetadata) && (
              <div
                style={{ width: 100, height: 100 }}
                className="bg-black items-center justify-center flex mb-2 cursor-pointer  rounded-xl"
              >
                {dataFix?.type === IMAGE_FILE_TYPE ? (
                  <img
                    alt="asset"
                    src={
                      dataFix?.thumbnailUrl instanceof Blob
                        ? URL.createObjectURL(dataFix?.thumbnailUrl)
                        : dataFix?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE
                    }
                    className="object-cover"
                    style={{ maxWidth: 100, maxHeight: 100 }}
                  />
                ) : dataFix?.type === VIDEO_FILE_TYPE ? (
                  <Player
                    className="object-cover max-h-full max-w-full"
                    fluid={false}
                    height={"100%"}
                    width={"100%"}
                    preload="metadata"
                    src={dataFix?.thumbnailUrl}
                  >
                    <BigPlayButton className="custom-big-play-button" />
                    <ControlBar
                      autoHide={false}
                      disableDefaultControls={true}
                    />
                  </Player>
                ) : (
                  <ReactAudioPlayer
                    style={{ width: "100%" }}
                    src={dataFix?.thumbnailUrl}
                    autoPlay={false}
                    controls
                  />
                )}
              </div>
            )}
            {isListing && (
              <ListingContent data={dataFix} formInput={formInput} />
            )}
            {isCancelListing && <CancelListingContent data={dataFix} />}
            {isCancelMakeOffer && <CancelMakeOfferContent data={dataFix} />}
            {isAcceptOffer && <AcceptMakeOffer data={dataFix} formInput={formInput} assetBid={assetBid}/>}
            {isCancelAuction && <CancelAuctionContent data={dataFix} />}
            {isCancelBidderAuction && (
              <CancelBidderAuctionContent data={dataFix} />
            )}
            {isCreateAsset && <CreateAssetContent data={formInput}/>}
            {isAccepAuction && <AcceptAuctionContent data={dataFix} assetBid={assetBid}/>}
            {isMakeOffer && (
              <MakeOfferContent
                data={dataFix}
                price={formInput?.price}
                amount={amount}
              />
            )}
            {isBid && <BidContent data={dataFix} price={formInput?.price} />}
            {isEditBank && <BankContent data={formInput}/>}
            {isAddBank && <BankContent data={formInput}/>}
            {isBuy && <BuyContent data={dataFix} formInput={formInput}/>}
            {isUpdateMetadata && <UpdateMetadataContent formInput={formInput} /> }
          </div>
          <div className="grid md:grid-cols-2 grid-cols-1 w-full gap-x-4 mt-8 mb-6">
            {!responsive && (
              <ButtonModal
                tx="Kembali"
                buttonTextSyle="text-hijau_hutan"
                color="bg-white"
                buttonStyle="border border-hijau_hutan px-10 py-4"
                onClick={isFiat ? handleCancelFiat : handleCancel}
              />
            )}
            <ButtonModal
              color={"bg-hijau_hutan"}
              onClick={handleContinue}
              tx="Proses Sekarang"
            />
          </div>
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalSummaryTxn;
