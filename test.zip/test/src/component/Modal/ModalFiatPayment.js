/* eslint-disable react-hooks/exhaustive-deps */
import React, { useContext, useEffect, useState } from "react";
import NumberFormat from "react-number-format";
// import InfoIcon from "../../assets/icon/info_icon";
import {
  nftaddress,
  nftauctionaddress,
  nftmarketaddress,
  nftmultiaddress,
  bankAddres,
} from "../../config/configContract";
import collectionContext from "../../context/Collection/collectionContext";
import fiatContext from "../../context/FiatPayment/fiatContext";
import socketContext from "../../context/Socket/socketContext";
import { ERC1155, ERC721 } from "../../utils/constants/contractType";
import {
  // BCA,
  BNI,
  BRI,
  DANA,
  LINKAJA,
  MANDIRI,
  OVO,
  PERMATA,
  QRIS,
  // SAMPOERNA,
  SHOPEEPAY,
} from "../../utils/constants/paymentTypes";
import Badges from "../Badges/Badges";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
import GroupLabelForm from "../Form/GroupLabelForm";
import SelectPaymentMethodForm from "../Form/SelectPaymentMethodForm";
import ModalInfo from "../Info/ModalInfo";
import AdderInput from "../Input/AdderInput";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import NFTMarketplace from "../../artifacts/contracts/NFTMarketplace.sol/NFTMarketplace.json";
import BankContract from "../../artifacts/contracts/BankAccounts.sol/BankAccounts.json"
import NFT from "../../artifacts/contracts/NFT.sol/NFT.json";
import NFTMulti from "../../artifacts/contracts/NFTMulti.sol/NFTMulti.json";
import NFTAuction from "../../artifacts/contracts/NFTAuction.sol/NftAuction.json";
import { ethers } from "ethers";
import { v4 as uuidv4 } from "uuid";
import { calculateGasFee } from "../../utils/helper";
import { RelayProvider } from "@opengsn/provider";
import { signRelayRequest } from "../../utils/VerifyingPaymasterUtils.ts";
import { paymasterConfig } from "../../config/configContract";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import TYPE_TRANSACTION from "../../utils/constants/typeTransaction";
import { AUCTION } from "../../utils/constants/listedType";
import assetContext from "../../context/Asset/assetContext";
// import useHandleEstimateGasFee from "../../utils/hooks/useHandleEstimateGasFee";
import {
  // BCA_LIMIT,
  MAXIMUM_PAYMENT_LIMIT,
  OTHERS_LIMIT,
  BANK_FEE,
} from "../../utils/constants/priceConstant";
import accountContext from "../../context/Account/accountContext";
import authContext from "../../context/Auth/authContext";
import assetBidContext from "../../context/AssetBid/assetBidContext";
import CloseIcon from "../../assets/icon/close_icon";
import ButtonModal from "./ButtonModal";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import web3ModalContext from "../../context/Web3Modal/web3ModalContext";
import _ from "lodash";
import {
  IMAGE_FILE_TYPE,
  VIDEO_FILE_TYPE,
} from "../../utils/constants/assetFileType";
import ReactAudioPlayer from "react-audio-player";
import { Player, ControlBar, BigPlayButton } from "video-react";
import env from "../../config/env";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { checkERC1155, checkERC721 } from "../../utils/nft-check-helper"
// import { MaticTokenIcon } from "../../assets";
// import { AcceptAuctionContent, AcceptMakeOffer, CancelAuctionContent, CancelBidderAuctionContent, CancelListingContent, CancelMakeOfferContent, CreateAssetContent, ListingContent, UpdateMetadataContent } from "./content/ContentModal";

const INITIAL_AMOUNT = 1;
const RETRIES_REMAINING_AMOUNT = 5

const jsonRpcProvider = process.env.REACT_APP_PROVIDER_LINK ? new ethers.providers.JsonRpcProvider(process.env.REACT_APP_PROVIDER_LINK) :
    new ethers.providers.getDefaultProvider()
    
const ModalFiatPayment = ({
  typeTransaction,
  assetBid,
  nft,
  formInput,
  updateFormInput,
  onSubmit,
  ...props
}) => {
  const { control } = useForm();
  const {signMessage} = useContext(fiatContext)
  const { show, setShow, responsive } = props;
  const CollectionContext = useContext(collectionContext);
  const SocketContext = useContext(socketContext);
  const AccountContext = useContext(accountContext);
  const AssetBidContext = useContext(assetBidContext);
  const AuthContext = useContext(authContext);
  const FiatContext = useContext(fiatContext);
  const { matic_price } = SocketContext;
  const [amount, setAmount] = useState(INITIAL_AMOUNT);
  const [fee, setFee] = useState(0);
  const [loadingGas, setLoadingGas] = useState(false);
  const [loadingAdmin, setLoadingAdmin] = useState(false);
  const [loadingValidate, setLoadingValidate] = useState(false)
  const [validatedAmount, setValidatedAmount] = useState(null)
  const [errorContract, setErrorContract] = useState(false)
  const [methodPayment, setMethodPayment] = useState(null);
  const [paymentLimit, setPaymentLimit] = useState(null);
  const [gasFee, setGasFee] = useState(0);
  const AssetContext = useContext(assetContext);
  const { web3Modal } = useContext(web3ModalContext);
  const isAddBank = typeTransaction === TYPE_TRANSACTION.ADD_BANK
  const isEditBank = typeTransaction === TYPE_TRANSACTION.EDIT_BANK
  let dataFix

  if(nft.length === 0){
    dataFix = assetBid?.assetsBidByAssetBidId?.assetByAssetId
  }else {
    dataFix = nft
  }
  
  // const isTypeListing = formInput?.listedType !== AUCTION;
  // const isListing = typeTransaction === TYPE_TRANSACTION.LISTING;
  // const isCancelListing = typeTransaction === TYPE_TRANSACTION.CANCEL_LISTING;
  // const isCancelMakeOffer = typeTransaction === TYPE_TRANSACTION.CANCEL_MAKE_OFFER;
  // const isAcceptOffer = typeTransaction === TYPE_TRANSACTION.ACCEPT_MAKE_OFFER;
  // const isCancelAuction = typeTransaction === TYPE_TRANSACTION.CANCEL_AUCTION;
  // const isCancelBidderAuction = typeTransaction === TYPE_TRANSACTION.CANCEL_BID_AUCTION;
  // const isCreateAsset = typeTransaction === TYPE_TRANSACTION.CREATE_ASSET
  // const isUpdateMetadata = typeTransaction === TYPE_TRANSACTION.EDIT_METADATA
  // const isAccepAuction = typeTransaction === TYPE_TRANSACTION.ACCEPT_AUCTION
  /* const { handleCalculateGasFee } = useHandleEstimateGasFee(
    setLoadingGas,
    setGasFee,
    typeTransaction,
    nft,
    formInput,
    amount,
    assetBid,
    updateFormInput
  ); */

  const externalId = uuidv4();

  useEffect(() => {
    setFee(0);
    setGasFee(0);
    setAmount(INITIAL_AMOUNT);
    setMethodPayment(null);
  }, [show]);

  useEffect(() => {
    async function calculate() {
      await handleCalculateFees(
        typeTransaction === TYPE_TRANSACTION.BUY
          ? nft?.publishedPrice * matic_price * amount
          : gasFee
      );
    }
    if (methodPayment) {
      calculate()
      /* setLoadingAdmin(true)

            const feedata = {
                price: typeTransaction === TYPE_TRANSACTION.BUY ? nft?.publishedPrice * matic_price * amount : gasFee,
                paymentMethod: formInput?.paymentMethod
            }
            const dataFee = await FiatContext?.calculateFee(feedata)
            await setFee(dataFee?.admin_fee)
            await updateFormInput({ ...formInput, adminFee: dataFee?.admin_fee })
            setLoadingAdmin(false) */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [methodPayment, gasFee]);
  /* eslint-disable */

  useEffect(async () => {
    const timeOutId = await setTimeout(async () => {
      if (methodPayment) {
        setLoadingAdmin(true);
        const feedata = {
          price: nft?.publishedPrice * matic_price * amount,
          paymentMethod: formInput?.paymentMethod,
        };
        const dataFee = await FiatContext?.calculateFee(feedata);
        await setFee(dataFee?.admin_fee);
        await updateFormInput({ ...formInput, adminFee: dataFee?.admin_fee });
        setLoadingAdmin(false);
      }
    }, 500);
    return () => clearTimeout(timeOutId);
  }, [amount]);

  useEffect(async () => {
    async function calculateLimit(gasFee) {
      if (typeTransaction !== TYPE_TRANSACTION.BUY || !gasFee) {
       
          if (gasFee < OTHERS_LIMIT) {
            gasFee = OTHERS_LIMIT;
          }
        const dataFee = FiatContext.calculateFee({
          paymentMethod: methodPayment,
          price: gasFee,
        });
        updateFormInput({ ...formInput, gasFee, adminFee: dataFee?.admin_fee });
        if(isAddBank || isEditBank){
          await setGasFee(parseInt(gasFee) + parseInt(BANK_FEE))
        } else {
          await setGasFee(gasFee);
        }
        setLoadingGas(false);
      }
    }
    if (show) {
      // if (show && methodPayment) {
      // await handleCalculateGasFee(methodPayment)
      const isERC721 = parseFloat(formInput?.amount) === INITIAL_AMOUNT;
      setLoadingGas(true);

      const signerPrivateKeyBuffer = Buffer.from(env?.SM, "hex");

      const asyncApprovalData = async function (relayRequest) {
        return await signRelayRequest(relayRequest, signerPrivateKeyBuffer);
      };

      const connection = await web3Modal.connect();

      const selectedProvider = new ethers.providers.Web3Provider(connection);
      const gsnProvider = await RelayProvider.newProvider({
        provider: selectedProvider.provider,
        config: paymasterConfig,
        overrideDependencies: {
          asyncApprovalData: asyncApprovalData,
        },
      }).init();

      let provider = new ethers.providers.Web3Provider(gsnProvider);
      let signer = provider.getSigner();

      const { signature, messageHash } = await FiatContext.signMessage(
        externalId
      );

      console.log('zap use effect get remaining amount',signature, messageHash, externalId, typeTransaction);

      if (typeTransaction === TYPE_TRANSACTION.CREATE_ASSET) {
        async function fetchEstimate(retries) {
          let allEstimatedGas;
          const isERC721 = formInput?.amount === INITIAL_AMOUNT;
          const INITIAL_DATA_ERC1155 = "0x00";
          try {
            // we want to create the token
            if (isERC721) {
              let contract = new ethers.Contract(nftaddress, NFT.abi, signer);

              let gasPrice = await contract.provider.getGasPrice();

              let gasLimit = await contract.estimateGas.mintToken("");
              allEstimatedGas = gasLimit.toNumber() * ethers.utils.formatEther(
                gasPrice.toNumber()
              );
            } else {
              let contract = new ethers.Contract(
                nftmultiaddress,
                NFTMulti.abi,
                signer
              );
              let gasPrice = await contract.provider.getGasPrice();
              let gasLimit = await contract.estimateGas.mint(
                formInput?.amount,
                "",
                INITIAL_DATA_ERC1155
              );

              allEstimatedGas = gasLimit.toNumber() * ethers.utils.formatEther(
                gasPrice.toNumber()
              );
            }
            let calculatedTotalGas = calculateGasFee(
              allEstimatedGas * matic_price * typeTransaction ===
                TYPE_TRANSACTION.CREATE_ASSET
                ? formInput?.typeSell === AUCTION
                  ? 3
                  : 2
                : 1
            );

            await calculateLimit(calculatedTotalGas);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.BUY) {
        async function fetchEstimate(retries) {
          try {
            const contract = new ethers.Contract(
              nftmarketaddress,
              NFTMarketplace.abi,
              signer
            );

            const gasPrice = await contract.provider.getGasPrice();

            const gasLimit = await contract.estimateGas.createMarketSale(
              nft?.tokenStandardType === ERC721 ? nftaddress : nftmultiaddress,
              nft?.itemContractId,
              nft?.tokenStandardType === ERC1155 ? amount : 1,
              true,
              messageHash,
              signature
            );

            const estimatedGasPrice = gasLimit.toNumber() * ethers.utils.formatEther(gasPrice.toNumber())

            updateFormInput({
              ...formInput,
              gasFee: calculateGasFee(estimatedGasPrice * matic_price),
            });
            await setGasFee(calculateGasFee(estimatedGasPrice * matic_price));
            setLoadingGas(false);

          } catch (error) {
            if (methodPayment) {
              toast.error(`nError: ${error?.data?.message}`)
            }
            setLoadingGas(false)
            setErrorContract(error)
            setMethodPayment(null)
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.CANCEL_LISTING) {
        console.log('zap cancel listing');
        async function fetchEstimate(retries) {
          try {
            const contract = new ethers.Contract(
              nftmarketaddress,
              NFTMarketplace.abi,
              signer
            );

            const gasPrice = await contract.provider.getGasPrice();

            const gasLimit = await contract.estimateGas.cancelListingItem(
              nft?.tokenStandardType === ERC1155 ? nftmultiaddress : nftaddress,
              AssetContext?.asset?.itemContractId
            );

            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);
            setLoadingGas(false);
          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.CANCEL_AUCTION) {
        async function fetchEstimate(retries) {
          try {
            const contract = new ethers.Contract(
              nftauctionaddress,
              NFTAuction.abi,
              signer
            );

            const gasPrice = await contract.provider.getGasPrice();
            const gasLimit = await contract.estimateGas.cancelAuction(
              assetBid?.auctionContractId
            );
            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);
            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.CANCEL_MAKE_OFFER) {
        async function fetchEstimate(retries) {
          try {
            const res = await AssetBidContext.getById(assetBid?.assetBidId);
            const contract = await new ethers.Contract(
              nftmarketaddress,
              NFTMarketplace.abi,
              signer
            );
            const gasPrice = await contract.provider.getGasPrice();

            const gasLimit = await contract.estimateGas.cancelBid(
              res?.bidContractId
            );
            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);
            // setGasFee(calculatedTotalGas)
            await calculateLimit(calculatedTotalGas);

            setLoadingGas(false);
          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.ACCEPT_MAKE_OFFER) {
        async function fetchEstimate(retries) {
          try {
            const acceptedBidder = await AccountContext.getAccountById(
              assetBid?.bidderAccount
            );
            const acceptedAsset = assetBid?.assetsBidByAssetBidId?.assetByAssetId;

            const contract = new ethers.Contract(
              nftmarketaddress,
              NFTMarketplace.abi,
              signer
            );
            let isApproved;
            if (acceptedAsset.tokenStandardType === ERC1155) {
              const tokenContract = new ethers.Contract(
                nftmultiaddress,
                NFTMulti.abi,
                jsonRpcProvider
              );
              isApproved = await tokenContract.isApprovedForAll(
                AuthContext?.auth?.user?.address,
                nftmarketaddress
              );
            } else {
              if (!acceptedAsset?.isListed) {
                const tokenContract = new ethers.Contract(
                  nftaddress,
                  NFT.abi,
                  jsonRpcProvider
                );
                isApproved = await tokenContract.isApprovedForAll(
                  AuthContext?.auth?.user?.address,
                  nftmarketaddress
                );
              } else {
                isApproved = true;
              }
            }

            let gasLimit;
            if (isApproved) {
              gasLimit = await contract.estimateGas.approveBid(
                assetBid?.assetsBidByAssetBidId?.bidContractId,
                // "bima123",
                acceptedBidder?.address,
                acceptedAsset?.itemContractId,
                // royaltiPercentage,
                acceptedAsset?.isListed ?? false,
                // offer?.amountToBid,
              );
            } else {
              if (acceptedAsset.tokenStandardType === ERC1155) {
                const tokenContract = new ethers.Contract(
                  nftmultiaddress,
                  NFTMulti.abi,
                  signer
                );
                gasLimit = await tokenContract.estimateGas.setApprovalForAll(
                  nftmarketaddress,
                  acceptedAsset?.tokenId
                );
              } else {
                const tokenContract = new ethers.Contract(
                  nftaddress,
                  NFT.abi,
                  signer
                );
                gasLimit = await tokenContract.estimateGas.changeOwnership(
                  nftmarketaddress,
                  acceptedAsset?.tokenId
                );
              }
            }
            const gasPrice = await contract.provider.getGasPrice();
            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(
              calculatedTotalGas * matic_price * isApproved ? 1 : 2
            );

            await calculateLimit(calculatedTotalGas);

            setLoadingGas(false);
          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.LISTING_AUCTION) {
        async function fetchEstimate(retries) {
          try {
            const contractAuction = new ethers.Contract(
              nftauctionaddress,
              NFTAuction.abi,
              signer
            );
            const gasPrice = await contractAuction.provider.getGasPrice();
            const gasLimit = await contractAuction.estimateGas.createAuction(
              externalId,
              isERC721,
              nftaddress,
              nft?.tokenId,
              AuthContext?.auth?.user?.address,
              0,
              new Date()
            );
            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);

            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.LISTING) {
        async function fetchEstimate(retries) {
          try {
            let tokenContract = new ethers.Contract(nftaddress, NFT.abi, signer);
            const gasPrice = await tokenContract.provider.getGasPrice();
            let isApproved;
            let gasLimit;
            if (nft?.tokenStandardType === ERC721) {
              tokenContract = new ethers.Contract(nftaddress, NFT.abi, jsonRpcProvider)
              const approvedAddress = await tokenContract.getApproved(nft.tokenId)
              if (approvedAddress !== nftmarketaddress) {
                tokenContract = new ethers.Contract(nftaddress, NFT.abi, signer);
                gasLimit = await tokenContract.estimateGas.changeOwnership(
                  nftmarketaddress,
                  nft.tokenId
                );
              }
            } else {
              tokenContract = new ethers.Contract(
                nftmultiaddress,
                NFTMulti.abi,
                jsonRpcProvider
              );
              isApproved = await tokenContract.isApprovedForAll(
                AuthContext?.auth?.user?.address,
                nftmarketaddress
              );
              if(!isApproved){
                tokenContract = new ethers.Contract(
                  nftmultiaddress,
                  NFTMulti.abi,
                  signer
                );
                gasLimit = await tokenContract.estimateGas.setApprovalForAll(
                  nftmarketaddress,
                  nft.tokenId
                );
              }
            }
            let calculatedTotalGas = isApproved ? 0 : gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(
              calculatedTotalGas * matic_price * isApproved ? 1 : 2
            );

            await calculateLimit(calculatedTotalGas);

            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.ACCEPT_AUCTION) {

        async function fetchEstimate(retries) {
          try {
            const res = await AccountContext?.getAccountOwnerById(
              assetBid?.sellerAccount
            );
            // const auctionedAsset = await AssetContext?.assetById(assetBid?.assetId)

            const contract = new ethers.Contract(
              nftauctionaddress,
              NFTAuction.abi,
              signer
            );
            const gasPrice = await contract.provider.getGasPrice();
            const gasLimit = await contract.estimateGas.settleAuction(
              assetBid?.auctionContractId,
              assetBid?.assetByAssetId?.itemContractId,
              nftmarketaddress,
              res?.address,
              assetBid?.assetByAssetId?.royalti
            );

            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);
            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.CANCEL_BID_AUCTION) {
        async function fetchEstimate(retries) {
          try {
            const contract = new ethers.Contract(
              nftauctionaddress,
              NFTAuction.abi,
              signer
            );

            const gasPrice = await contract.provider.getGasPrice();
            const gasLimit = await contract.estimateGas.cancelBidderAuction(
              assetBid?.auctionContractId
            );

            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (typeTransaction === TYPE_TRANSACTION.EDIT_METADATA) {
        async function fetchEstimate(retries) {
          let gasPrice
          let gasLimit
          try {
            if (nft?.tokenStandardType === ERC721) {
              const contract = new ethers.Contract(nftaddress, NFT.abi, signer)
              gasPrice = await contract.provider.getGasPrice();
              gasLimit = await contract.estimateGas.changeTokenUri(nft?.itemContractId, nft?.tokenId, "", nftmarketaddress)
          } else {
              const contract = new ethers.Contract(nftmultiaddress, NFTMulti.abi, signer)
              gasPrice = await contract.provider.getGasPrice();
              gasLimit = await contract.estimateGas.changeTokenUri(nft?.itemContractId, nft?.tokenId, "", nftmarketaddress)
          }

            let calculatedTotalGas = gasLimit.toNumber() * ethers.utils.formatEther(
              gasPrice.toNumber()
            );

            calculatedTotalGas = calculateGasFee(calculatedTotalGas * matic_price);

            await calculateLimit(calculatedTotalGas);

          } catch (error) {
            /*  if (retries > 0) {
               const turnLeft = retries - 1
               fetchEstimate(turnLeft)
             } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (isAddBank) {
        async function fetchEstimate(retries) {
          try {
            let externalId = `INV/${new Date().getFullYear()}${new Date().getMonth().toString().length === 1 ? "0" + new Date().getMonth().toString() : new Date().getMonth().toString()}${new Date().getDate().toString().length === 1 ? "0" + new Date().getDate().toString() : new Date().getDate().toString()}/${new Date().getTime()}`
            const { messageHash, signature } = await signMessage(externalId)
            const contract = new ethers.Contract(
              bankAddres,
              BankContract.abi,
              signer
            );
            const gasPrice = await contract.provider.getGasPrice();
            const gasLimit = await contract.estimateGas.addBankAccount('bankAccount', 'bankCode', 'holderName', signature, messageHash, 'invoiceYa')
            const gasFinal = gasLimit.toNumber() * ethers.utils.formatEther(gasPrice.toNumber())
            let calculatedTotalGas = 0;
            calculatedTotalGas = calculateGasFee(gasFinal * matic_price);
            await calculateLimit(calculatedTotalGas);
            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } else if (isEditBank) {
        async function fetchEstimate(retries) {
          try {
            let externalId = `INV/${new Date().getFullYear()}${new Date().getMonth().toString().length === 1 ? "0" + new Date().getMonth().toString() : new Date().getMonth().toString()}${new Date().getDate().toString().length === 1 ? "0" + new Date().getDate().toString() : new Date().getDate().toString()}/${new Date().getTime()}`
            const { messageHash, signature } = await signMessage(externalId)
            const contract = new ethers.Contract(
              bankAddres,
              BankContract.abi,
              signer
            );
            const gasPrice = await contract.provider.getGasPrice();
            const gasLimit = await contract.estimateGas.editBankAccount('bankAccount', 'bankCode', 'holderName', signature, messageHash, 'invoiceYa')
            const gasFinal = gasLimit.toNumber() * ethers.utils.formatEther(gasPrice.toNumber())
            let calculatedTotalGas = 0;
            calculatedTotalGas = calculateGasFee(gasFinal * matic_price);
            await calculateLimit(calculatedTotalGas);
            setLoadingGas(false);

          } catch (error) {
           /*  if (retries > 0) {
              const turnLeft = retries - 1
              fetchEstimate(turnLeft)
            } */
            setShow(false)
            toast.error("Terjadi kesalahan di sistem blockchain")
            throw error
          }
        }
        fetchEstimate(RETRIES_REMAINING_AMOUNT)
      } 
      }
    }
, [show, methodPayment]);

  async function handleCalculateFees(price) {
    setLoadingAdmin(true);
    const feedata = {
      price,
      // price: typeTransaction === TYPE_TRANSACTION.BUY ? nft?.publishedPrice * matic_price * amount : gasFee,
      paymentMethod: formInput?.paymentMethod,
    };
    const dataFee = await FiatContext?.calculateFee(feedata);
    await setFee(dataFee?.admin_fee);
    await updateFormInput({ ...formInput, adminFee: dataFee?.admin_fee });
    setLoadingAdmin(false);
  }

  const resetExceedLimitMethodPayment = (value, limit) => {
    if (value > limit) {
      setMethodPayment(null);
      setFee(0);
    }
  };

  const handleAmountOnchange = (e) => {
    if (isNaN(parseFloat(e.target.value))) {
      updateFormInput((props) => ({ ...props, amount: 0 }));
      resetExceedLimitMethodPayment(
        nft?.publishedPrice * matic_price * 0 + gasFee,
        paymentLimit
      );
      setAmount(0);
      setErrorContract(false)
    } else {
      if (parseFloat(e.target.value) <= (validatedAmount ?? nft?.remainingAmount)) {
        updateFormInput((props) => ({
          ...props,
          amount: parseFloat(e.target.value),
        }));
        resetExceedLimitMethodPayment(
          nft?.publishedPrice * matic_price * e.target.value + gasFee,
          paymentLimit
        );
        setAmount(parseFloat(e.target.value));
        setErrorContract(false)
      }
    }
  };

  const handleAmountAdd = async () => {
    if (amount < (validatedAmount ?? nft?.remainingAmount)) {
      updateFormInput((props) => ({
        ...props,
        amount: parseFloat(amount) + 1,
      }));
      resetExceedLimitMethodPayment(
        nft?.publishedPrice * matic_price * (parseFloat(amount) + 1) + gasFee,
        paymentLimit
      );
      setAmount(parseFloat(amount) + 1);
      setErrorContract(false)
    }
  };

  const handleAmountSubstract = async () => {
    if (amount > INITIAL_AMOUNT) {
      updateFormInput((props) => ({
        ...props,
        amount: parseFloat(amount) - 1,
      }));
      resetExceedLimitMethodPayment(
        nft?.publishedPrice * matic_price * (parseFloat(amount) - 1) + gasFee,
        paymentLimit
      );
      setAmount(parseFloat(amount) - 1);
      setErrorContract(false)
    }
  };

  const getTotalTransaction =
    typeTransaction === TYPE_TRANSACTION.BUY
      ? nft?.publishedPrice * matic_price * amount + fee + gasFee
      : parseFloat(fee) + parseFloat(methodPayment ? gasFee : 0);

  const selectBankPaymentParam = [
    /* {
      ...BCA,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(BCA.maximumLimit);
      },
    }, */
   
    {
      ...BRI,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(BRI.maximumLimit);
      },
    },
    {
      ...BNI,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(BNI.maximumLimit);
      },
    },
    {
      ...MANDIRI,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(MANDIRI.maximumLimit);
      },
    },
    {
      ...PERMATA,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(PERMATA.maximumLimit);
      },
    },
    /* {
      ...SAMPOERNA,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(SAMPOERNA.maximumLimit);
      },
    }, */
  ];
  const selectWalletPaymentParam = [
    {
      ...OVO,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(OVO.maximumLimit);
      },
    },
    {
      ...SHOPEEPAY,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(SHOPEEPAY.maximumLimit);
      },
    },
    {
      ...DANA,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(DANA.maximumLimit);
      },
    },
    {
      ...LINKAJA,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(LINKAJA.maximumLimit);
      },
    },
    {
      ...QRIS,
      onClick: (e) => {
        updateFormInput({ ...formInput, paymentMethod: e });
        setMethodPayment(e);
        setPaymentLimit(QRIS.maximumLimit);
      },
    },
  ];

  const handleSubmit = async () => {
    const asset = await AssetContext.fetchAssetById(nft?.id)
    console.log('zap form input modal fiat payment',formInput);
    if(nft?.tokenStandardType == ERC1155) {
      if (checkERC1155(asset)) {
        toast.error(`Terdapat transaksi yang belum selesai pada asset ini`)
      } else {
        setLoadingValidate(true)
        const getBalance = await AssetContext.validateErc1155Amount(nft?.id, validatedAmount ?? nft?.remainingAmount, nft?.itemContractId)
        if (amount <= getBalance) {
            setValidatedAmount(getBalance)
          if (typeTransaction === TYPE_TRANSACTION.EDIT_METADATA) {

            await onSubmit({
              ...formInput,
              amount: nft?.amount,
              listedType: formInput?.typeSell,
              adminFee: parseFloat(fee),
              paymentMethod: methodPayment,
              amount: parseFloat(amount),
              gasFee: parseFloat(gasFee),
            });
          } else {
            await onSubmit({
              ...formInput,
              listedType: formInput?.typeSell,
              ...nft,
              adminFee: parseFloat(fee),
              paymentMethod: methodPayment,
              amount: parseFloat(amount),
              gasFee: parseFloat(gasFee),
            });

          }
            setLoadingValidate(false)
        } else {
            setValidatedAmount(getBalance)
            toast.error(`Maksimum jumlah serial yang dapat dibeli telah berubah karena telah terjadi transaksi di tempat lain.
              Silahkan kurangi jumlah serial yang ingin anda beli.
            `)
            setAmount(0)
            setMethodPayment(null)
            setLoadingValidate(false)
        }
      }
    } else {
      if (checkERC721(asset)) {
        toast.error(`Terdapat transaksi yang belum selesai pada asset ini`)
      } else {
        if (typeTransaction === TYPE_TRANSACTION.EDIT_METADATA) {

          await onSubmit({
            ...formInput,
            amount:nft?.amount,
            adminFee: parseFloat(fee),
            paymentMethod: methodPayment,
            amount: parseFloat(amount),
            gasFee: parseFloat(gasFee),
          });
        } else {
          await onSubmit({
            ...formInput,
            ...nft,
            adminFee: parseFloat(fee),
            paymentMethod: methodPayment,
            amount: parseFloat(amount),
            gasFee: parseFloat(gasFee),
          });

        }
      
      }
    }
  } 

  return (
    <Modal {...props}>
      <CardModal className="overflow-y-auto max-h-modalmax_payment_fiat md:h-auto h-modalmax w-full md:py-9 py-0 md:pb-0 pb-6">
        {responsive && (
          <div className="w-full justify-end flex flex-col sticky top-0 z-40 bg-white pt-6">
            <div className="justify-end w-full flex">
              <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />
            </div>
            {typeTransaction === TYPE_TRANSACTION.BUY && <div className="justify-center w-full flex">
              <ModalTitleText tx="Konfirmasi Pembelian" classtyle="text-center self-center"/>
            </div>}
          </div>
        )}
        {/* Header FIAT PAYMENT */}
        {typeTransaction === TYPE_TRANSACTION.BUY && (
          <div className="flex flex-col mb-6 w-full justify-center items-center">
            {!responsive && <ModalTitleText tx="Konfirmasi Pembelian" classtyle="text-center self-center"/>}
            <div className="verified-background w-full md:pt-0 pt-4">
              {nft?.tokenStandardType === ERC1155 && (
                <div className="transform-rotate-180 md:px-10 px-0">
                  <GroupLabelForm tx="Jumlah Serial">
                    <AdderInput
                      name="amount"
                      control={control}
                      className={"md:mt-3 md:mb-8"}
                      width={80}
                      onChange={handleAmountOnchange}
                      value={amount}
                      handleClickAdd={handleAmountAdd}
                      handleClickSubstract={handleAmountSubstract}
                    />
                  </GroupLabelForm>
                </div>
              )}
              <div className="inline-flex w-full md:px-10 px-0 transform-rotate-180 mt-4">
                <div
                  style={{ width: 100, height: 100 }}
                  className="bg-black items-center justify-center flex mr-5 mb-3 cursor-pointer  rounded-xl"
                >
                  {nft?.type === IMAGE_FILE_TYPE ? (
                    <img
                      alt="asset"
                      src={nft?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE}
                      className="rounded-xl object-cover"
                      style={{ maxWidth: 100, maxHeight: 100 }}
                    />
                  ) : nft?.type === VIDEO_FILE_TYPE ? (
                    <Player
                      className="object-cover max-h-full max-w-full"
                      fluid={false}
                      height={"100%"}
                      width={"100%"}
                      preload="metadata"
                      src={nft?.thumbnailUrl}
                    >
                      <BigPlayButton className="custom-big-play-button" />
                      <ControlBar
                        autoHide={false}
                        disableDefaultControls={true}
                      />
                    </Player>
                  ) : (
                    <ReactAudioPlayer
                      style={{ width: "100%" }}
                      src={nft?.thumbnailUrl}
                      autoPlay={false}
                      controls
                    />
                  )}
                </div>
                <div className="flex flex-col items-start ml-4">
                  <p className="font-quicksand font-bold text-sm text-hijau_tua">
                    {
                      CollectionContext?.collections.find(
                        (collection) => collection?.id === nft?.collectionId
                      )?.name
                    }
                  </p>
                  <p className="font-quicksand font-bold text-base text-hitam mb-2">
                    {nft?.name}
                  </p>
                  <Badges
                    // icon={<InfoIcon className="mr-2" />}
                    width="36"
                    value={`Royalti ${nft?.royalti ?? 0} % untuk pembuat aset`}
                  />
                </div>
              </div>
            </div>
            { !errorContract && nft?.tokenStandardType === ERC1155 && (
              <ModalInfo
                labelStyle={"text-base text-hitam"}
                label={"Harga Satuan"}
                rightContent={
                  <div className="flex flex-col">
                    <NumberFormat
                      decimalScale={0}
                      value={
                        nft?.publishedPrice
                          ? nft?.publishedPrice * matic_price
                          : 0
                      }
                      displayType={"text"}
                      thousandSeparator={true}
                      renderText={(value, props) => (
                        <>
                          <p className="font-quicksand font-bold text-sm text-hitam">
                            IDR {value}
                          </p>
                        </>
                      )}
                    />
                  </div>
                }
              />
            )}
            {
              !errorContract && (
                <ModalInfo
                  labelStyle={"text-base text-hitam"}
                  label={"Sub Total"}
                  rightContent={
                    <NumberFormat
                      decimalScale={0}
                      value={
                        nft?.publishedPrice
                          ? nft?.publishedPrice * matic_price * amount
                          : 0
                      }
                      displayType={"text"}
                      thousandSeparator={true}
                      renderText={(value, props) => (
                        <>
                          <p className="font-quicksand font-bold text-base text-hitam">
                            IDR {value}
                          </p>
                        </>
                      )}
                    />
                  }
                />
              )
            }
          </div>
        )
        }

        {/* Modal Select Payment */}
        {!errorContract && (
          typeTransaction !== TYPE_TRANSACTION.BUY ||
          nft?.publishedPrice * matic_price * amount < MAXIMUM_PAYMENT_LIMIT
        ) ? (
          <>
          <ModalTitleText tx={isAddBank ? "Tambah Bank" : isEditBank ? "Ubah Rekening Bank" : "Pilih Metode Pembayaran"}/>
            {(isAddBank || isEditBank) && <p className="mb-4 font-quicksand text-sm text-justify">Demi keamanan data rekening Bank anda, kami akan menyimpan data anda di Blockchain melalui Smart Contract yang kami buat. Untuk itu anda akan dikenakan biaya Gas (Gas Fee) untuk menyimpan data di Blokchain. </p>}
            {(isAddBank || isEditBank) && <p className="mb-4 font-quicksand text-sm font-semibold text-justify">Pembayaran Gas Fee ini akan berlaku untuk 3 kali validasi bank. Silahkan lakukan pembayaran ini dengan pilihan Kanal Pembayaran yang kami miliki</p>}
            <SelectPaymentMethodForm
              formInput={formInput}
              methodPayment={methodPayment}
              totalPrice={
                typeTransaction === TYPE_TRANSACTION.BUY
                  ? nft?.publishedPrice * matic_price * amount + gasFee
                  : methodPayment
                  ? gasFee
                  : 0
              }
              formParam={selectBankPaymentParam}
              title={"Transfer Virtual Account"}
              customDiv="mt-2"
            />
          </>
        ) : (
          errorContract?.data ?
          <div className="w-full flex flex-col justify-start mt-4 px-10">
            <p className="font-quicksand font-bold text-lg text-red-500">
              Terjadi error ketika estimasi gas. Harap melakukan refresh atau 
              mengurangi jumlah serial yang ingin kamu beli
            </p>
            <p className="text-xs text-red-500"></p>
          </div> 
          : 
          <div className="w-full flex flex-col justify-start mt-4 px-10">
            <p className="text-xs text-red-500">
              * Harga sudah melebihi Rp 100.000.000,- .Transaksi hanya bisa
              dilakukan dengan mata uang kripto
            </p>
            <p className="text-xs text-red-500"></p>
          </div>
        )}
        {!errorContract && (typeTransaction !== TYPE_TRANSACTION.BUY ||
          nft?.publishedPrice * matic_price * amount < QRIS.maximumLimit) && (
          <SelectPaymentMethodForm
            formInput={formInput}
            methodPayment={methodPayment}
            row="md:grid-cols-2"
            totalPrice={
              typeTransaction === TYPE_TRANSACTION.BUY
                ? nft?.publishedPrice * matic_price * amount + gasFee
                : methodPayment
                ? gasFee
                : 0
            }
            formParam={selectWalletPaymentParam}
            title={"e-Wallet"}
            customDiv="pt-4"
          />
        )}

        {/* Modal Detail Payment */}
        {!errorContract && typeTransaction !== TYPE_TRANSACTION.BUY ? (
          <>
            <ModalInfo
              labelStyle={"text-base text-hitam"}
              label={"Gas Fee"}
              rightContent={
                !loadingGas ? (
                  <NumberFormat
                    decimalScale={0}
                    value={methodPayment ? gasFee : 0}
                    displayType={"text"}
                    thousandSeparator={true}
                    renderText={(value, props) => (
                      <>
                        <p className="font-quicksand font-bold text-base text-hitam">
                          IDR {value}
                        </p>
                      </>
                    )}
                  />
                ) : (
                  <SpinCircleLogo />
                )
              }
            />
            <ModalInfo
              labelStyle={"text-base text-hitam"}
              label={"Biaya Admin"}
              rightContent={
                !loadingAdmin ? (
                  <NumberFormat
                    decimalScale={0}
                    value={fee ?? 0}
                    displayType={"text"}
                    thousandSeparator={true}
                    renderText={(value, props) => (
                      <>
                        <p className="font-quicksand font-bold text-base text-hitam">
                          IDR {value}
                        </p>
                      </>
                    )}
                  />
                ) : (
                  <SpinCircleLogo />
                )
              }
            />
          </>
        ) : (
          !errorContract && (
          <>
            <ModalInfo
              labelStyle={"text-base text-hitam"}
              label={"Biaya Admin"}
              rightContent={
                !loadingAdmin ? (
                  <NumberFormat
                    decimalScale={0}
                    value={fee ?? 0}
                    displayType={"text"}
                    thousandSeparator={true}
                    renderText={(value, props) => (
                      <>
                        <p className="font-quicksand font-bold text-base text-hitam">
                          IDR {value}
                        </p>
                      </>
                    )}
                  />
                ) : (
                  <SpinCircleLogo />
                )
              }
            />
            <ModalInfo
              labelStyle={"text-base text-hitam"}
              label={"Gas Fee"}
              rightContent={
                !loadingGas ? (
                  <NumberFormat
                    decimalScale={0}
                    value={gasFee}
                    displayType={"text"}
                    thousandSeparator={true}
                    renderText={(value, props) => (
                      <>
                        <p className="font-quicksand font-bold text-base text-hitam">
                          IDR {value}
                        </p>
                      </>
                    )}
                  />
                ) : (
                  <SpinCircleLogo />
                )
              }
            />
          </>
          )
        )}
        {/* Modal Total Price */}
        {
          !errorContract && (
            <ModalInfo
              labelStyle={"text-base font-bold"}
              label={"Total"}
              rightContent={
                <NumberFormat
                  decimalScale={0}
                  value={getTotalTransaction}
                  displayType={"text"}
                  thousandSeparator={true}
                  renderText={(value, props) => (
                    <>
                      <p className="font-quicksand font-bold text-base text-hitam">
                        IDR {value}
                      </p>
                    </>
                  )}
                />
              }
            />
          )
        }
        <div className="grid md:grid-cols-2 grid-cols-1 w-full gap-x-4 mt-8 mb-6">
        {!responsive && <ButtonModal tx="Kembali" buttonTextSyle="text-hijau_hutan" color="bg-white" buttonStyle="border border-hijau_hutan px-10 py-4" onClick={() => setShow(false)} />}
          <ButtonModal
            disabled={
              errorContract ||
              loadingAdmin ||
              loadingGas ||
              !methodPayment ||
              _.isNil(matic_price)
            }
            color={
              loadingAdmin || loadingGas || !methodPayment
                ? "bg-gray-200"
                : "bg-hijau_hutan"
            }
            onClick={async () => {
              // await onSubmit({
              //   ...formInput,
              //   adminFee: parseFloat(fee),
              //   paymentMethod: methodPayment,
              //   amount: parseFloat(amount),
              //   gasFee: parseFloat(gasFee),
              // });
              await handleSubmit()
            }}
            tx="Lanjutkan"
          />
        </div>

        {/* <RoundedButton disabled={loadingAdmin || loadingGas || !methodPayment || _.isNil(matic_price)} className={`md:w-3/4 w-full py-4 mt-4`} color={(loadingAdmin || loadingGas || !methodPayment) ? "bg-gray-200" : "bg-hijau_hutan"} onClick={async () => {
                    await onSubmit({
                        ...formInput, adminFee: fee, paymentMethod: methodPayment,
                        amount,
                        gasFee
                    })
                }}>
                    <ButtonText classstyle="font-bold" tx="Bayar Sekarang" />
                </RoundedButton> */}
      </CardModal>
      <Modal backdrop={false} show={(loadingGas || loadingAdmin || loadingValidate) && show}>
        <div className="flex w-full h-screen justify-center items-center">
          <SpinCircleLogo black={"true"} type="big" />
        </div>
      </Modal>
    </Modal>
  );
};

export default ModalFiatPayment;
