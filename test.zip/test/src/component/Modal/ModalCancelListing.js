import React from "react";
// import ButtonLink from "../Button/ButtonLink";
// import RoundedButton from "../Button/RoundedButton";
import CardModal from "../Card/CardModal";
// import ButtonText from "../Text/ButtonText";
import ModalTitleText from "../Text/ModalTitleText";
import ButtonModal from "./ButtonModal";
import Modal from "./Modal";
import P from './P';

const ModalCancelListing = ({ title = "Apakah anda yakin untuk membatalkan penjualan ini?", ...props }) => {
    // const { responsive } = props;
    const handleCancelButton = () => props.setShow(false)
    const handleSubmitButton = props?.onSubmit
    return (
        <Modal {...props}>
            <CardModal>
                <ModalTitleText tx="Konfirmasi Pembatalan" />
                <P>
                    {title}
                </P>
                <ButtonModal onNoClick={handleCancelButton} onOkClick={handleSubmitButton} okLabel="Batalkan" noLabel="Kembali" type="confirmation" tx="Batalkan" />

            </CardModal>
        </Modal>
    )
}

export default ModalCancelListing