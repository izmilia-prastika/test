import React from "react";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
import Modal from "./Modal";
import CloseIcon from "../../assets/icon/close_icon";

import P from "./P";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
import { WEB_HOST } from "../../utils/helper";

const ModalValidateBank = ({ ...props }) => {
  const { responsive, setShow } = props;
  const handleTo = () => {
    window.open(`${WEB_HOST}/setting/bank-account`, '_blank', 'noopener,noreferrer');
    setShow(false);
  }

  return (
    <Modal {...props}>
      <CardModal>
        {responsive && (
          <div className="w-full justify-end flex mb-4">
            <CloseIcon viewBox={20} size={4} onClick={() => setShow(false)} />
          </div>
        )}
        <ModalTitleText tx="Tambahkan Rekening Bank Anda" />
        <P fontSize="md:text-lg text-base md:mt-0 -mt-3">
            Untuk mengaktifkan penjualan dengan mata uang Rupiah, Anda wajib mendaftarkan satu rekening bank aktif. Silahkan tambahkan bank pada halaman pengaturan bank, atau klik tombol "Pengaturan Bank"
        </P>
        <div className="grid md:grid-cols-2 grid-cols-1 md:gap-4 gap-2 w-full">
          <RoundedButton onClick={()=> setShow(false)} className="py-4 border border-hijau_hutan" color="bg-white">
            <div className="inline-flex items-center">
              <ButtonText
                classstyle="font-bold text-sm "
                text={"Kembali"}
                color="text-hijau_hutan"
              />
            </div>
          </RoundedButton>
          <RoundedButton onClick={handleTo} className="py-4">
            <div className="inline-flex items-center">
              <ButtonText
                classstyle="font-bold text-sm"
                text={"Pengaturan Bank"}
              />
            </div>
          </RoundedButton>
        </div>
      </CardModal>
    </Modal>
  );
};

export default ModalValidateBank;
