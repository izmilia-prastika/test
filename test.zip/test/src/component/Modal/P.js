import React from "react";

const P = ({ fontSize = "text-lg", children, className }) => {
  return (
    <p
      className={`font-quicksand font-medium text-hitam_2 mb-6 mt-6 text-center whitespace-pre-line ${fontSize} ${className}`}
    >
      {children}
    </p>
  );
};


export default P;
