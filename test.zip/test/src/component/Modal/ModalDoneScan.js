import Modal from "./Modal";
import CardModal from "../Card/CardModal";
import ModalTitleText from "../Text/ModalTitleText";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo"
import { useContext, useEffect, useRef, useState } from "react";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
// import RoundedButton from "../Button/RoundedButton";
// import ButtonText from "../Text/ButtonText";
// import ButtonModal from "./ButtonModal";
import P from './P';
import { DoneScan, FailScan,} from "../../assets";
// import { useNavigate } from "react-router-dom";

const ModalDoneScan = ({ status = true, isMaxReached = false, ...props }) => {
    const [num, setNum] = useState(5);
    const responsive = useContext(ResponsiveContext)
    // const navigate = useNavigate()
    const decreaseNum = () => {
        if (num > 0) {
            setNum((prev) => prev - 1);
        } else {
            clearInterval(intervalRef.current)
            setNum(5)
            props.setShow(false)
        }
    }
    let intervalRef = useRef();
    useEffect(() => {
        if (props.show) {
            intervalRef.current = setInterval(decreaseNum, 1000);
            return () => clearInterval(intervalRef.current);
        } else if (num < 0) {
            props.setShow(false)
            clearInterval(intervalRef.current);
        }

    }, [props.show, num]);

    return (
        <Modal responsive={responsive} {...props} >
            <CardModal>
                <ModalTitleText text={status ? "Yeay, kode berhasil diverifikasi!" : isMaxReached ? 'Maaf, kode sudah mencapai batas maksimal redeem' : 'Maaf, kode gagal diverifikasi'} />
                <img src={status ? DoneScan : FailScan} alt="" className="h-28" />
                <P fontSize="md:text-lg text-base">
                    {`Menu ini akan ditutup dalam ${num} detik`}
                </P>
            </CardModal>
        </Modal>
    );
};

export default ModalDoneScan;
