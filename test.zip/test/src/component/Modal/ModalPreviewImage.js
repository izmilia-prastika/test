import React, { useState } from 'react'
import SpinCircleLogo from '../../assets/animation/spin_circle_logo';
import Modal from '../Modal/Modal'

const ModalPreviewImage = ({
    setShow,
    show,
    imgSrc,
}) => {
    const [loading, setLoading] = useState(true);

    const imageLoaded = () => {
        // console.log('zap image loaded');
        setLoading(false);
    }
    return (
        <Modal setShow={setShow} show={show} positionMobile="items-center">
            <SpinCircleLogo className={loading ? "block" : "hidden"} />
            <img
                onLoad={imageLoaded}
                alt="asset"
                className={`max-w-full max-h-screen ${loading ? "hidden" : "block"}`}
                src={imgSrc}
                onClick={() => {
                    setShow(false);
                }}
            />
        </Modal>
    )
}

export default ModalPreviewImage