import React from "react";
import CardModal from "../Card/CardModal";
import Modal from "./Modal";

const ModalDropdown = ({...props}) => {
    const {children} = props;
    return (
        <Modal {...props}>
            <CardModal className={"max-h-modalmax overflow-hidden pb-4"}>
                {children}
            </CardModal>
        </Modal>
    )
}

export default ModalDropdown