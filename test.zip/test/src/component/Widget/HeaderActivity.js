import React, { useContext } from "react";
import filterContext from "../../context/Filter/filterContext";
import { LISTING, MAKE_BID_AUCTION, MAKE_OFFER, SOLD } from "../../utils/constants/activityTypes";
import InputRoundedDropdown from "../Input/InputRoundedDropdown";

const HeaderActivity = ({responsive}) => {
    const activitiesTypeData = [
        {
            name: "Semua"
        },
        {
            value: SOLD,
            name: "Terjual"
        },
        {
            value:MAKE_BID_AUCTION,
            name: "Penawaran Lelang"
        },
        {
            value: MAKE_OFFER,
            name:"Buat Penawaran"
        },
        {
            value: LISTING,
            name: "Menjual"
        }
    ]
    const FilterContext = useContext(filterContext)
    return (
        <div className="flex flex-col mb-4 md:px-0 px-4 md:items-start items-end">
            <InputRoundedDropdown
                className="md:w-60 w-24"
                placeholder="Semua"
                setValue={FilterContext?.setActivityType}
                value={FilterContext?.activityType}
                data={activitiesTypeData}
            />
        </div>
    )
}

export default HeaderActivity