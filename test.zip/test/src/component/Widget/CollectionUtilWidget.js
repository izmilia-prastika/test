import React from "react"
import { useNavigate } from "react-router-dom"
import { ElipseGreenPattern, ElipseOrangePattern } from "../../assets"
import ButtonLink from "../Button/ButtonLink"
import TextLink from "../Text/TextLink"

const CollectionUtilWidget = ({ params }) => {
    const navigate = useNavigate()
    return (
        <div className='inline-flex'>
            <div className="relative flex flex-col" onClick={() => navigate(`/update-collection/${params?.id}`)}>
                <ButtonLink classstyle="border-r-2 border-eo pr-4 mr-4 px-0 py-0" ><TextLink classstyle="underline" text="Ubah Koleksi"></TextLink></ButtonLink>
                <img alt="green pattern" className="absolute top-3" src={ElipseGreenPattern} />
            </div>
            <div className="relative flex flex-col "onClick={() => navigate('/create-asset')}>
                <ButtonLink classstyle="px-0 py-0" ><TextLink color="text-yellow-500" classstyle="underline" text="Tambah Asset"></TextLink></ButtonLink>
                <img alt="orange pattern" className="absolute top-3" src={ElipseOrangePattern} />
            </div>
        </div>
    )
}

export default CollectionUtilWidget