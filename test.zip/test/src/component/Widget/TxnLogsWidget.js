import React, { useContext } from 'react'
import filterContext from '../../context/Filter/filterContext'
import {
    TXN_TYPES_ACCEPT_OFFER,
    TXN_TYPES_BID_AUCTION,
    TXN_TYPES_BUY,
    TXN_TYPES_CANCEL_AUCTION,
    TXN_TYPES_CANCEL_BIDDER_AUCTION,
    TXN_TYPES_CANCEL_LISTING,
    TXN_TYPES_CANCEL_OFFER,
    TXN_TYPES_CREATE_ASSET,
    TXN_TYPES_MAKE_OFFER,
    TXN_TYPES_LISTING,
    TXN_TYPES_SETTLE_AUCTION,
    TXN_TYPES_ADD_BANK,
} from '../../utils/constants/transactionLogTypes'
import InputRoundedDropdown from '../Input/InputRoundedDropdown'


const typeTxn = [
    {
        value: null,
        name: 'Semua Jenis Transaksi',
    },
    {
        value: TXN_TYPES_BUY,
        name: 'Pembelian',
    },
    {
        value: TXN_TYPES_LISTING,
        name: 'Pengaktifan Penjualan',
    },
    {
        value: TXN_TYPES_CANCEL_LISTING,
        name: 'Pembatalan Penjualan',
    },
    {
        value: TXN_TYPES_CREATE_ASSET,
        name: 'Pembuatan Aset',
    },
    {
        value: TXN_TYPES_ACCEPT_OFFER,
        name: 'Penerimaan Penawaran',
    },
    {
        value: TXN_TYPES_CANCEL_OFFER,
        name: 'Penolakan Penawaran',
    },
    {
        value: TXN_TYPES_SETTLE_AUCTION,
        name: 'Penutupan Lelang',
    },
    {
        value: TXN_TYPES_CANCEL_AUCTION,
        name: 'Pembatalan Lelang',
    },
    {
        value: TXN_TYPES_CANCEL_BIDDER_AUCTION,
        name: 'Pembatalan Penawaran Lelang',
    },
    {
        value: TXN_TYPES_ADD_BANK,
        name: 'Penambahan Rekening Bank',
    },
    {
        value: TXN_TYPES_MAKE_OFFER,
        name: 'Penawaran Asset',
    },
    {
        value: TXN_TYPES_BID_AUCTION,
        name: 'Penawaran Lelang',
    },
]

const TxnLogsWidget = () =>  {
  const FilterContext = useContext(filterContext)
  return (
    <div>
        <InputRoundedDropdown 
            placeholder="Semua Jenis Transaksi"
            data={typeTxn}
            setValue={FilterContext?.setTypeTxn}
            value={FilterContext?.typeTxn}
        />
    </div>
  )
}

export default TxnLogsWidget