import React from "react";
import OptionCollectionWidget from "./OptionCollectionWidget";

const HeaderCollection = ({responsive}) => {
    return (
        <div className="flex flex-col md:mb-4 mt-10 mb-4 pb-4">
            {/* {!responsive && <p className="text-2xl font-bold font-quicksand text-hitam_2 mb-10">Daftar Koleksi</p>} */}
            <OptionCollectionWidget />
        </div>
    )
}

export default HeaderCollection