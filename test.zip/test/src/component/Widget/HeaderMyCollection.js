import React from "react";
import { useNavigate } from "react-router-dom";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";

const MobileBottomBar = () => {
    const navigate = useNavigate()
    const handleCreateCollection = () => navigate('/create-collection')
    return (
      <div className='fixed bottom-0 px-4 py-3 w-full border-t z-20 bg-white left-0'>
        <div className='grid'>
            <RoundedButton onClick={handleCreateCollection} className="px-10 py-3">
                <ButtonText>
                    Buat Koleksi
                </ButtonText>
            </RoundedButton>
        </div>
      </div>
    )
  }

const HeaderMyCollection = ({responsive}) => {
    const navigate = useNavigate()
    return (
        <div className="flex flex-row justify-between items-center md:px-20 px-4 md:py-7 py-5 my-collection-header-background">
            <p className="font-quicksand text-hitam_2 md:text-2xl text-base md:font-bold font-semibold">Koleksi Saya</p>
            {!responsive ? <RoundedButton onClick={()=>navigate('/create-collection')} className="px-10 py-4">
                <ButtonText>
                    Buat Koleksi
                </ButtonText>
            </RoundedButton> : <MobileBottomBar />}
            
        </div>
    )
}

export default HeaderMyCollection