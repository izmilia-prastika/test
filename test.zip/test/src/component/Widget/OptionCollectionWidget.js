import React, { useContext, useEffect, useState } from "react";
import { MagnifierLogoImg } from "../../assets";
import categoryContext from "../../context/Category/categoryContext";
import filterContext from "../../context/Filter/filterContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import InputRounded from "../Input/InputRounded";
import InputRoundedDropdown from "../Input/InputRoundedDropdown";



const OptionCollectionWidget = () => {
    const FilterContext = useContext(filterContext);
    const Responsive = useContext(ResponsiveContext)
    const [search, setSearch] = useState("")
    const [categories, setCategories] = useState({})
    const [verified, setVerified] = useState({})
    const CategoryContext = useContext(categoryContext);

    const verifiedData = [
        {
            value: 1,
            name: "Belum Terverifikasi"
        },
        {
            value: 2,
            name: "Terverifikasi"
        },
    ]

    useEffect(() => {
        /* eslint-disable */
        CategoryContext.getAllCategories()
    }, [])

    useEffect(() => {
        const timeOutId = setTimeout(() =>
            FilterContext?.setSearchCollection(search)
            , 500);
        return () => clearTimeout(timeOutId);
    }, [search]);

    const onChangeCategories = (e) => {
        setCategories(e)
        FilterContext?.categoryIds.find(cat => cat === e.value) ?
            FilterContext?.removeCategory(e.value)
            :
            FilterContext?.addCategory(e.value)
    }

    const onChangeVerified = e => {
        setVerified(e)
        console.log('zap',FilterContext?.verifiedIds,e.value    );
        FilterContext?.verifiedIds.find(cat => cat === e.value) ?
            FilterContext?.removeVerified(e.value)
            :
            FilterContext?.addVerified(e.value)
    }

    return (
        <div className="flex w-full justify-between flex-wrap pb-4">
            <div className="grid grid-cols-3 lg:grid-cols-8 gap-4 w-full">
            <InputRoundedDropdown data={
                CategoryContext.categories.map(({ name, id }) => ({
                    value: id,
                    name
                }))}
                value={categories}
                onChange={onChangeCategories}
                multi
                selected={FilterContext?.categoryIds}
                inputstyle="py-0"
                searchAble
                placeholder="Kategori"
                className="col-start-1 col-end-2"
                />
            <InputRoundedDropdown
                inputstyle="py-0"
                multi
                onChange={onChangeVerified}
                selected={FilterContext?.verifiedIds}
                value={verified}
                data={verifiedData}
                placeholder="Status"
                className="col-start-2 col-end-3"
                />
            {!Responsive && <InputRounded className="w-full col-start-7 col-end-9"
                inputstyle="md:bg-transparent bg-gray-100 md:border-gray-300 border-gray-400 md:border border-0"
                onChange={(e) => setSearch(e.target.value)}
                value={search}
                appendleft={<MagnifierLogoImg />} 
                placeholder="Cari nama koleksi..."
                />}
            </div> 
            {Responsive && <div className="w-full h-0.5 bg-gray-100 my-4"></div>}
            {Responsive && <div className="w-full">
                <InputRounded className="w-full col-start-7 col-end-9"
                    inputstyle="md:bg-transparent bg-gray-100 md:border-gray-300 border-gray-400 md:border border-0"
                    onChange={(e) => setSearch(e.target.value)}
                    value={search}
                    appendleft={<MagnifierLogoImg />} 
                    placeholder="Cari nama koleksi..."
                    />
            </div>}
        </div>
    )
}

export default OptionCollectionWidget