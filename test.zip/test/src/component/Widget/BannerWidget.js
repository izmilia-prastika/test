import { useContext, useEffect } from "react";
import Carousel from "react-multi-carousel";
import assetContext from "../../context/Asset/assetContext";
import { BANNER_CACHE_TYPE } from "../../utils/constants/assetCacheTypes";
import { MEDIUM_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";

const BannerWidget = ({ responsive, page, isStatic, imgSrc, svg, Title/* , height="100px" */ }) => {
    const AssetContext = useContext(assetContext)
    useEffect(() => {
        AssetContext.getCache([BANNER_CACHE_TYPE])
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const responsiveCarousel = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 1
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 1
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 1
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
    if (isStatic) {
        return (
            <img alt="banner" className="w-full object-cover h-60 lg:h-60 fhd:h-96" src={decodeURI(imgSrc + MEDIUM_THUMBNAIL_IMAGE_TYPE)} />
        )

    } else {
        return (
            <Carousel
                renderButtonGroupOutside={true}
                // itemClass="w-full"
                draggable
                infinite
                showDots
                ssr
                arrows={true}
                // containerClass="relative flex-col flex align-middle items-center justify-center z-0 w-full"
                autoPlay={true}
                autoPlaySpeed={5000}
                responsive={responsiveCarousel}
                removeArrowOnDeviceType={["mobile", "tablet"]}>
                {
                    page === "collection" ?
                        AssetContext?.bannersCollection ?
                            AssetContext?.bannersCollection?.map((banner,key) =>
                                <img alt="banner carousel" key={key} className="w-full" style={{ height: responsive ? "230px" : "364px" }} src={decodeURI(banner?.websiteFileUrl + MEDIUM_THUMBNAIL_IMAGE_TYPE)} />
                            )
                            :
                            <div>No Banner</div>
                        :
                        AssetContext?.banners ?
                            AssetContext?.banners?.map((banner,key) =>
                                <img alt="banner asset" key={key} className="w-full" style={{ height: responsive ? "230px" : "364px" }} src={decodeURI(banner?.websiteFileUrl + MEDIUM_THUMBNAIL_IMAGE_TYPE)} />
                            )
                            :
                            <div>No Banner</div>
                }
            </Carousel>
        )
    }
}

export default BannerWidget