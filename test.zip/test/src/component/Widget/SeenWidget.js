import React, { useState, useEffect, useRef, useContext } from "react";
import axios from "axios"
import EyeIcon from "../../assets/icon/eye_icon";
import classNames from "classnames";
import { useParams } from "react-router-dom";
import authContext from "../../context/Auth/authContext";
import env from "../../config/env";

const SeenWidget = ({ responsive = false }) => {
    const [views, setViews] = useState(null)
    const mounted = useRef(false)
    const params = useParams()
    const AuthContext = useContext(authContext)
    const getGa = async () => {
        if (window.localStorage.getItem("atga") === undefined) {
            const temp_ga = await AuthContext.gaToken()
            const getViewsByAssetId = await axios.get(`https://www.googleapis.com/analytics/v3/data/ga?access_token=${temp_ga?.access_token.access_token}&ids=ga:${env.GA_TABLE_ID}&dimensions=ga:pagePath&metrics=ga:pageviews&filters=ga:pagePath==/asset/${params?.id}&start-date=2005-01-01&end-date=today`)
            if (mounted.current) {
                setViews(getViewsByAssetId.data.totalsForAllResults["ga:pageviews"])
            }
        } else {
            const getViewsByAssetId = await axios.get(`https://www.googleapis.com/analytics/v3/data/ga?access_token=${AuthContext?.atga?.access_token.access_token}&ids=ga:${env.GA_TABLE_ID}&dimensions=ga:pagePath&metrics=ga:pageviews&filters=ga:pagePath==/asset/${params?.id}&start-date=2005-01-01&end-date=today`)
            if (mounted.current) {
                setViews(getViewsByAssetId.data.totalsForAllResults["ga:pageviews"])
            }
        }
    }

    useEffect(() => {
        mounted.current = true
        getGa()
        return () => {
            mounted.current = false
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const classLayout = classNames({ "grid-cols-3 grid gap-2 justify-center items-center": !responsive }, { "flex flex-row-reverse items-start gap-x-2": responsive })
    return (
        <div className={classLayout}>
            <p className="text-hitam font-quicksand text-base font-medium col-start-1 col-end-3 rever">
                {views && `${views} Dilihat`}
            </p>
            <EyeIcon className="col-start-3 justify-end" />
        </div>
    )
}

export default SeenWidget
