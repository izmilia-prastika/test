import React, { useContext, useEffect, useState } from "react";
import InputRounded from "../Input/InputRounded";
import InputRoundedDropdown from "../Input/InputRoundedDropdown";
import { MagnifierLogoImg } from '../../assets'

import collectionContext from '../../context/Collection/collectionContext'
import utilitasContext from '../../context/Utilitas/utilitasContext'
import categoryContext from '../../context/Category/categoryContext'
import filterContext from '../../context/Filter/filterContext'
import InputRoundedSliderDropdown from "../Input/InputRoundedSliderDropdown";
import { PRICE_ASC, PRICE_DESC, RECENT_LISTING, RECENT_SOLD } from "../../utils/constants/sortByAsset";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import { useLocation } from "react-router-dom";
import authContext from "../../context/Auth/authContext";
import { NOT_REDEEMED, REDEEMED } from "../../utils/constants/redemeedConstant";
import FolderStarIcon from "../../assets/icon/folder_star_icon";
import FolderListIcon from "../../assets/icon/folder_list_icon";
import CircleChecklistIcon from "../../assets/icon/circle_checklist_icon";

const MAX = 999999999999

const OptionWidget = ({ownerId}) => {
    const typeSell = [
        {
            value: REDEEMED,
            name: "Sudah Digunakan"
        },
        {
            value: NOT_REDEEMED,
            name: "Belum Digunakan"
        },
    ]

    const location = useLocation()

    const AuthContext = useContext(authContext);
    const CollectionContext = useContext(collectionContext);
    const CategoryContext = useContext(categoryContext);
    const FilterContext = useContext(filterContext);
    const UtilitasContext = useContext(utilitasContext);
    const Responsive = useContext(ResponsiveContext)

    const [categories, setCategories] = useState({})
    const [priceBoundary, setPriceBoundary] = useState([0, MAX])
    const [collectionData,setCollectionData] = useState([])
    const [collections, setCollections] = useState({})
    const [type, setType] = useState({})
    const [search, setSearch] = useState(FilterContext?.searchAsset)
    const [price, setPrice] = useState([0, MAX])
    const [getCollectionAgain, setGetCollectionAgain] = useState(false)

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(() => {
        if(getCollectionAgain && CollectionContext?.pageInfo?.endCursor !== null){
          fetchLoad()
          setGetCollectionAgain(false)
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [getCollectionAgain])

    const fetchLoad = async () => {
        const fetchAgain = await CollectionContext.getAllCollections({
          first: 10,
          after: CollectionContext?.pageInfo?.endCursor
        })
        setCollectionData(collectionData.concat(fetchAgain?.nodes))
      }
    const handleApplyButton = () => {
        FilterContext?.setPrice([parseFloat(price[0]), parseFloat(price[1])])
    }

    useEffect(() => {
        async function fetchData(){
            // const resCollection = await CollectionContext.getAllCollections({ownerId})
            // setCollectionData(resCollection)
            fetchLoad()
            UtilitasContext.getAllProject(AuthContext?.auth?.user?.id)
            // CategoryContext.getAllCategories()
            FilterContext?.setPrice([parseFloat(price[0]), parseFloat(price[1])])
            FilterContext?.resetFilter()
        }
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [location.pathname])

    // useEffect(() => {
    //     const timeOutId = setTimeout(() =>
    //         FilterContext?.setPrice([parseFloat(price[0]), parseFloat(price[1])])
    //         , 500);
    //     return () => clearTimeout(timeOutId);
    // }, [price]);

    useEffect(() => {
        /* eslint-disable */
        const timeOutId = setTimeout(async () => {
            if (search?.length >= 0) {
                await FilterContext?.setSearchAsset(search)
                await FilterContext?.setSearchTag("")
            }
        }
            , 500);
        return () => clearTimeout(timeOutId);
    }, [search]);
    const onChangeCategories = (e) => {
        setCategories(e)
        FilterContext?.categoryIds.find(cat => cat === e.value) ?
            FilterContext?.removeCategory(e.value)
            :
            FilterContext?.addCategory(e.value)
    }

    const onChangeCollections = (e) => {
        setCollections(e)
        FilterContext?.collectionIds.find(col => col === e.value) ?
            FilterContext?.removeCollection(e.value)
            :
            FilterContext?.addCollection(e.value)
    }

    const onChangeType = (e) => {
        setType(e)
        FilterContext?.statusType.includes(e.value) ?
            FilterContext?.removeStatusListing(e.value)
            :
            FilterContext?.addStatusListing(e.value)
    }
    const onSlideEndPrice = async (e) => {
        // setPrice([e.value[0],e.value[1]])
        if (priceBoundary[1] <= e.value[1]) {
            setPriceBoundary([0, e.value[1] + 100])
        }
    }
    const onChangePrice = async (e) => {
        await setPrice(e)
    }
    return (
        !Responsive ?
            <div className="flex flex-row justify-between bg-transparent pb-4">
                <div className="grid sm:grid-cols-2 lg:grid-cols-8 gap-4 w-full">
                    <InputRoundedDropdown data={
                        UtilitasContext?.projects?.map(({ projectName, utilityProjectId }) => ({
                            value: parseFloat(utilityProjectId),
                            name: projectName,
                        }))}
                        value={categories}
                        onChange={onChangeCategories}
                        selected={FilterContext?.categoryIds}
                        inputstyle="py-0"
                        searchAble
                        icon={<FolderStarIcon />}
                        multi
                        placeholder="Projek Utilitas" />
                    <InputRoundedDropdown data={
                        collectionData.map(({ name, id }) => ({
                            value: id,
                            name
                        }))}
                        setGetAgain={setGetCollectionAgain}
                        value={collections}
                        selected={FilterContext?.collectionIds}
                        onChange={onChangeCollections}
                        searchAble
                        icon={<FolderListIcon />}
                        multi
                        inputstyle="py-0"
                        placeholder="Koleksi" />
                    <InputRoundedDropdown
                        selected={FilterContext?.statusType}
                        inputstyle="py-0"
                        onChange={onChangeType}
                        icon={<CircleChecklistIcon size={18} color="#CCCCCC" />}
                        value={type}
                        placeholder="Status"
                        multi
                        data={typeSell} />
                   {/*  <InputRoundedSliderDropdown placeholder="Harga"
                        multi
                        priceBoundary={priceBoundary}
                        setPriceBoundary={setPriceBoundary}
                        onSlideEnd={onSlideEndPrice}
                        value={price}
                        setValue={setPrice}
                        onChange={onChangePrice}
                        handleApplyButton={handleApplyButton}
                    /> */}
                   {/*  <div className="col-start-6 col-end-9 inline-flex">
                        <InputRoundedDropdown
                            setValue={FilterContext?.setSortedBy}
                            value={FilterContext?.sortedBy}
                            data={sortedByData}
                            className="w-6/12 mr-4" placeholder="Sort By" />
                        <InputRounded
                            className="w-full col-start-8 col-end-9"
                            onChange={(e) => setSearch(e.target.value)}
                            value={search}
                            appendleft={
                                <MagnifierLogoImg />
                            }
                            placeholder='Cari nama aset disini'
                        />
                    </div> */}
                </div>
            </div> :
            <div>
                <div className="flex">
                    <div className="flex gap-4 overflow-scroll no-scrollbar h-auto">
                      
                    <InputRoundedDropdown data={
                        UtilitasContext?.projects?.map(({ projectName, utilityProjectId }) => ({
                            value: parseFloat(utilityProjectId),
                            name: projectName,
                        }))}
                        value={categories}
                        onChange={onChangeCategories}
                        selected={FilterContext?.categoryIds}
                        inputstyle="py-0"
                        searchAble
                        icon={<FolderStarIcon />}
                        multi
                        placeholder="Projek Utilitas" />
                    <InputRoundedDropdown data={
                        collectionData.map(({ name, id }) => ({
                            value: id,
                            name
                        }))}
                        value={collections}
                        selected={FilterContext?.collectionIds}
                        onChange={onChangeCollections}
                        searchAble
                        icon={<FolderListIcon />}
                        multi
                        inputstyle="py-0"
                        placeholder="Koleksi" />
                    <InputRoundedDropdown
                        selected={FilterContext?.statusType}
                        inputstyle="py-0"
                        onChange={onChangeType}
                        icon={<CircleChecklistIcon size={18} color="#CCCCCC" />}
                        value={type}
                        placeholder="Status"
                        multi
                        data={typeSell} />
                    </div>
                </div>
            </div>
    )
}

export default OptionWidget