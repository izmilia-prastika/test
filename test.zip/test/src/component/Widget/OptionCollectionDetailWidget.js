import React, { useContext, useEffect, useState } from "react";
import { MagnifierLogoImg } from "../../assets";
import authContext from "../../context/Auth/authContext";
import filterContext from "../../context/Filter/filterContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import { AUCTION, FIX_PRICE } from "../../utils/constants/listedType";
import { PRICE_ASC, PRICE_DESC, RECENT_LISTING, RECENT_SOLD } from "../../utils/constants/sortByAsset";
import InputRounded from "../Input/InputRounded";
import InputRoundedDropdown from "../Input/InputRoundedDropdown";
import InputRoundedSliderDropdown from "../Input/InputRoundedSliderDropdown";

const MAX = 999999999999

const WidgetLaptop = ({
    isOwnedDetail,
    setSortedBy,
    sortedBy,
    sortedByData,
    statusType,
    onChangeType,
    type,
    typeSell,
    price,
    setPrice,
    onChangePrice,
    search,
    setSearch,
    handleApplyButton,
    priceBoundary,
    setPriceBoundary,
    onSlideEndPrice,
}) => {
    return (
        <div className="grid gap-4 grid-cols-12 w-full">
            {isOwnedDetail ?
                <>
                <div className="col-start-1 col-end-3">
                    <InputRoundedDropdown
                        setValue={setSortedBy}
                        value={sortedBy}
                        data={sortedByData}
                        initValue={"Status Koleksi"}
                        placeholder="Sort By"
                        className="w-full" />
                </div>
                <div className="col-start-11 col-span-2">
                    <InputRounded
                        onChange={(e) => setSearch(e.target.value)}
                        value={search}
                        appendleft={<MagnifierLogoImg />} 
                        placeholder="Cari aset disini..."
                        className="w-full"
                        />
                </div>
                </>
                :
                <>
                <div className="col-start-1 col-end-3">
                    <InputRoundedDropdown
                        multi
                        selected={statusType}
                        inputstyle="py-0"
                        onChange={onChangeType}
                        value={type}
                        className="w-full"
                        placeholder="Status"
                        data={typeSell} />
                </div>
                <div className="col-start-3 col-end-5"> 
                    <InputRoundedSliderDropdown placeholder="Harga"
                        className="w-full"
                        value={price}
                        setValue={setPrice}
                        onChange={onChangePrice}
                        handleApplyButton={handleApplyButton}
                        priceBoundary={priceBoundary}
                        setPriceBoundary={setPriceBoundary}
                        onSlideEndPrice={onSlideEndPrice}
                        
                    />
                </div>
                <div className="col-start-9 col-end-11">
                    <InputRoundedDropdown
                        setValue={setSortedBy}
                        value={sortedBy}
                        data={sortedByData}
                        className="w-full"placeholder="Sort By" />
                </div>
                <div className="col-start-11 col-end-13">
                    <InputRounded className="w-full"
                        onChange={(e) => setSearch(e.target.value)}
                        value={search}
                        appendleft={<MagnifierLogoImg />} 
                        placeholder="Cari aset disini..."
                    />
                </div>
                </>
            }
        </div>
    )
}

const WidgetMobile = ({
    isOwnedDetail,
    setSortedBy,
    sortedBy,
    sortedByData,
    statusType,
    onChangeType,
    type,
    typeSell,
    price,
    setPrice,
    onChangePrice,
    search,
    setSearch,
    responsive,
    handleApplyButton,
    priceBoundary,
    setPriceBoundary,
    onSlideEndPrice,
}) => {
    return (
        <div className="w-full">
            <div className="flex justify-between">
                <div className="flex gap-4 w-full items-center">
                    {isOwnedDetail ?
                        <>
                            <InputRounded
                                className="w-full"
                                inputstyle="bg-gray-100 border-gray-400 placeholder-shown:italic"
                                onChange={(e) => setSearch(e.target.value)}
                                value={search}
                                appendleft={<MagnifierLogoImg />}
                                placeholder="Cari"
                            />

                            <InputRoundedDropdown
                                setValue={setSortedBy}
                                value={sortedBy}
                                data={sortedByData}
                                className="" placeholder="Sort By" />
                        </>
                        :
                        <>
                            <InputRoundedDropdown
                                multi
                                selected={statusType}
                                inputstyle="py-0"
                                onChange={onChangeType}
                                value={type}
                                className=""
                                placeholder="Status"
                                data={typeSell} />

                            <InputRoundedSliderDropdown placeholder="Harga"
                                className=""
                                priceBoundary={priceBoundary}
                                setPriceBoundary={setPriceBoundary}
                                onSlideEndPrice={onSlideEndPrice}
                                value={price}
                                setValue={setPrice}
                                onChange={onChangePrice}
                                handleApplyButton={handleApplyButton}
                            />
                        </>
                    }
                </div>
                {!isOwnedDetail &&
                    <div>
                        <InputRoundedDropdown
                            setValue={setSortedBy}
                            value={sortedBy}
                            data={sortedByData}
                            className="w-11/12" placeholder="Sort By" />
                    </div>
                }
            </div>
            {responsive && !isOwnedDetail && <div className="w-full h-0.5 bg-gray-100 my-4"></div>}
            {!isOwnedDetail && <div className="w-full">
                <InputRounded
                    className="w-full"
                    inputstyle="bg-gray-100 border-gray-400 placeholder-shown:italic"
                    onChange={(e) => setSearch(e.target.value)}
                    value={search}
                    appendleft={<MagnifierLogoImg />}
                    placeholder="Cari"
                />
            </div>}
        </div>
    )
}

const OptionCollectionDetailWidget = ({ owner }) => {
    const typeSell = [
        {
            value: AUCTION,
            name: "Buka Lelang"
        },
        {
            value: FIX_PRICE,
            name: "Beli Sekarang"
        },
    ]

    const sortedByData = [
        {
            value: RECENT_LISTING,
            name: "Baru Masuk Daftar Jual"
        },
        {
            value: RECENT_SOLD,
            name: "Baru Terjual"
        },
        {
            value: PRICE_DESC,
            name: "Harga Tertinggi"
        },
        {
            value: PRICE_ASC,
            name: "Harga Terendah"
        },
    ]


    const AuthContext = useContext(authContext)
    const FilterContext = useContext(filterContext)
    const Responsive = useContext(ResponsiveContext)

    const [priceBoundary, setPriceBoundary] = useState([0, MAX])
    const [type, setType] = useState({})
    const [search, setSearch] = useState("")
    const [price, setPrice] = useState([0, MAX])
    const isOwnedDetail = owner?.id === AuthContext?.auth?.user?.id

    const handleApplyButton = () => {
        FilterContext?.setPrice(price)
    }

    // useEffect(() => {
    //     const timeOutId = setTimeout(() =>
    //         FilterContext?.setPrice(price)
    //         , 500);
    //     return () => clearTimeout(timeOutId);
    // }, [price]);

    useEffect(() => {
        /* eslint-disable */

        const timeOutId = setTimeout(() =>
            FilterContext?.setSearchAsset(search)
            , 500);
        return () => clearTimeout(timeOutId);
    }, [search]);

    const onChangePrice = async (e) => {
        await setPrice(e)
    }

    const onSlideEndPrice = async (e) => {
        if (priceBoundary[1] <= e.value[1]) {
            setPriceBoundary([0, e.value[1] + 100])
        }
    }

    const onChangeType = (e) => {
        setType(e)
        FilterContext?.statusType.includes(e.value) ?
            FilterContext?.removeStatusListing(e.value)
            :
            FilterContext?.addStatusListing(e.value)
    }

    return (
        !Responsive ?
            <WidgetLaptop
                isOwnedDetail={isOwnedDetail}
                setSortedBy={FilterContext?.setSortedBy}
                sortedBy={FilterContext?.sortedBy}
                sortedByData={sortedByData}
                statusType={FilterContext?.statusType}
                onChangeType={onChangeType}
                type={type}
                typeSell={typeSell}
                price={price}
                setPrice={setPrice}
                onChangePrice={onChangePrice}
                handleApplyButton={handleApplyButton}
                search={search}
                setSearch={setSearch}
                priceBoundary={priceBoundary}
                setPriceBoundary={setPriceBoundary}
                onSlideEndPrice={onSlideEndPrice}
            />
            :
            <WidgetMobile
                responsive={Responsive}
                isOwnedDetail={isOwnedDetail}
                setSortedBy={FilterContext?.setSortedBy}
                sortedBy={FilterContext?.sortedBy}
                sortedByData={sortedByData}
                statusType={FilterContext?.statusType}
                onChangeType={onChangeType}
                type={type}
                typeSell={typeSell}
                price={price}
                setPrice={setPrice}
                onChangePrice={onChangePrice}
                handleApplyButton={handleApplyButton}
                search={search}
                setSearch={setSearch}
                priceBoundary={priceBoundary}
                setPriceBoundary={setPriceBoundary}
                onSlideEndPrice={onSlideEndPrice}
            />
    )
}

export default OptionCollectionDetailWidget