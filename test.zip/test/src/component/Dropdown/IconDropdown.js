import React, { useState } from "react";

const IconDropdown = ({icon,dataList,classList,className}) => {
    const [show,setShow] = useState(false)
    const handleOnclick = () => {
        console.log('zap',show);
        setShow(!show)
    }
    return(
        <div className={`inline-block relative ${className}`}>
            <div className="cursor-pointer" onClick={handleOnclick}>
                {icon}
            </div>
            <ul className={`bg-white absolute ${classList} ${!show && "hidden"}`}>
                {dataList?.map(({label,onClick,isVisible}, key) =>
                
                    isVisible &&
                    <li onClick={onClick} className="bg-white hover:bg-gray-400 cursor-pointer rounded-lg p-2" key={key}>
                        <p className="font-quicksand text-base text-hitam text-start">
                            {label}
                        </p>
                    </li>
                )}
            </ul>
        </div>
    )
}

export default IconDropdown