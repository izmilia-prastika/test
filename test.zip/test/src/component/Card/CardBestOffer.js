import { useNavigate } from "react-router-dom";
import VerifiedLogo from "../../assets/logo/verified_logo";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import Card from "./Card";

const CardBestOffer = ({ data, ...props}) => {
    const {id, thumbnailUrl, name, collectionByCollectionId} = data
    const navigate = useNavigate()
    return (
        <Card {...props} onClick={() => navigate(`/asset/${id}`)} height={400} width={274} className="flex flex-col items-center cursor-pointer landing-page-card-background">
            <div className="bg-black h-80 w-full items-center justify-center flex mb-4  rounded-xl">
                <img alt="collection" src={thumbnailUrl+SMALL_THUMBNAIL_IMAGE_TYPE} className="object-cover rounded-xl h-80" />
            </div>
            <div className="px-8 flex flex-col items-center ">
                <div className="flex flex-row items-center">
                    <p className="font-quicksand font-bold text-xl text-hijau_hutan mr-2">{collectionByCollectionId?.name}</p>
                    {collectionByCollectionId?.isVerified &&
                        <VerifiedLogo />
                    }
                </div>
                <p className="font-quicksand font-bold text-xl text-hitam mb-2">{name}</p>
                {/* <p className="font-quicksand font-normal text-center text-base text-hitam mb-8">{description}</p> */}
            </div>
        </Card>
    )
}

export default CardBestOffer