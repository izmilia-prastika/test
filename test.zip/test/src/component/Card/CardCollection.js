import React from "react";
import Card from "./Card";

const CardCollection = ({ width = "100%", height = "auto", ...props }) => {
    return (
        <Card {...props} className={`border shadow overflow-hidden rounded-xl relative px-0 py-0 ${props.className}`} /* width={width} */ height={height}>
            {props.children}
        </Card>
    )
}

export default CardCollection