import React from "react";
import Card from "./Card";

const CardAsset = (props) => {
    return (
        <Card {...props} className={`shadow overflow-hidden rounded-xl relative px-0 py-0 ${props.className}`}>
            {props.children}
        </Card>
    )
}

export default CardAsset