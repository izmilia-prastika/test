import React from "react";

const FooterCardAsset = (props) => {
    return (
        <div className="w-full">
            {props?.topAddon}

            {/* <div className={`absolute inset-x-0 z-20 gradient-background ${props.className}`}> */}
            <div className={`${props.className}`}>
                {props.children}
            </div>
        </div>

    )
}

export default FooterCardAsset