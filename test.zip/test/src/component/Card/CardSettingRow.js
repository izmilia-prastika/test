import NumberFormat from "react-number-format";
import { useNavigate } from "react-router-dom";
import { MaticTokenIcon } from "../../assets";
import { INVOICE_ACCEPT_OFFER, 
        INVOICE_BUY, 
        INVOICE_CANCEL_AUCTION, 
        INVOICE_CANCEL_LISTING, 
        INVOICE_CANCEL_OFFER, 
        INVOICE_CREATE_ASSET, 
        INVOICE_LISTING, 
        INVOICE_SETTLE_AUCTION,
        INVOICE_CANCEL_BIDDER_AUCTION,
        INVOICE_ADD_BANK,
    } from "../../utils/constants/invoiceTypes";
import {
    TXN_TYPES_ACCEPT_OFFER,
    TXN_TYPES_BID_AUCTION,
    TXN_TYPES_BUY,
    TXN_TYPES_CANCEL_AUCTION,
    TXN_TYPES_CANCEL_BIDDER_AUCTION,
    TXN_TYPES_CANCEL_LISTING,
    TXN_TYPES_CANCEL_OFFER,
    TXN_TYPES_CREATE_ASSET,
    TXN_TYPES_MAKE_OFFER,
    TXN_TYPES_LISTING,
    TXN_TYPES_SETTLE_AUCTION,
    TXN_TYPES_ADD_BANK,
    TXN_TYPES_EDIT_METADATA,
} from "../../utils/constants/transactionLogTypes"
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import Card from "./Card";
import ReactAudioPlayer from "react-audio-player";
import { Player, ControlBar, BigPlayButton } from 'video-react';
import { IMAGE_FILE_TYPE, MUSIC_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType";
import classNames from "classnames";
import { UserImage } from "../../assets";

const CardMobileSetting = ({ 
    assetId, 
    img,
    navigate, 
    label, 
    date, 
    subLabel, 
    cryptoPrice, 
    price, 
    button, 
    userImg, 
    userName, 
    userRole, 
    dateLeft,
    type,
    buttonCancel,
    isFromInvoice = false ,
    ...props }) => {
    const containerContent = classNames("bg-black flex items-center justify-center rounded-lg overflow-hidden", {"h-44": type===IMAGE_FILE_TYPE}, { "h-44": type === VIDEO_FILE_TYPE }, { "h-44": type !== IMAGE_FILE_TYPE && type !== VIDEO_FILE_TYPE })
    return (
        <Card {...props} className='bg-white shadow-lg mb-4 mx-4 p-4 rounded-lg' width={'%100'}>
            <div>
                <div className={containerContent}>
                    {
                        type === IMAGE_FILE_TYPE ?
                            <img alt="asset" onClick={() => navigate(`/asset/${assetId}`)} style={{ maxWidth: "320px", heigth: "180px", maxHeight: "180px", }} src={img !== null ? img + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} />
                            :
                            type === VIDEO_FILE_TYPE ?
                                <Player className="object-cover max-h-full max-w-full mr-5" fluid={false} height={180} width={320} preload="metadata" src={img}>
                                    <BigPlayButton className="custom-big-play-button" />
                                    <ControlBar autoHide={false} disableDefaultControls={true} />
                                </Player>
                                :
                                <ReactAudioPlayer
                                    src={img}
                                    autoPlay={false}
                                    controls
                                />
                    }
                </div>
                <div className="mt-3 flex justify-between mb-3">
                    <div className="mb-2">
                        <p onClick={() => navigate(`/asset/${assetId}`)} className={`${subLabel ? "mb-2" : "mb-0"} font-quicksand font-semibold text-base text-hitam`}>{label}</p>
                        {subLabel && <p className={`font-medium font-quicksand text-xs text-hitam_2 `}>{subLabel}</p>}
                    </div>
                    <div className="items-end">
                        <p className={`font-medium text-xs text-right font-quicksand whitespace-nowrap`}>{date ? date : dateLeft}</p>
                    </div>
                </div>
                <div className="flex justify-between items-center">
                    {cryptoPrice && <NumberFormat value={cryptoPrice} displayType={'text'} thousandSeparator={true}
                        renderText={(value, props) => <div className="flex-row flex items-center pr-3 mr-3">
                            <img alt="matic token" src={MaticTokenIcon} className={`self-center w-4 h-4 mr-2 `} />
                            <p className="font-semibold text-sm font-quicksand">{value}</p>
                        </div>
                        }
                    />}
                    {price &&
                        <NumberFormat thousandSeparator={true} value={price} displayType={"text"} renderText={(value) =>
                            <p className="font-semibold text-sm font-quicksand">Rp. {value}</p>
                        } />
                    }
                    <div className={`grid ${buttonCancel ? "grid-cols-2 w-full" : 'grid-cols-1 w-auto'} gap-x-2`}>
                        {!!buttonCancel && buttonCancel}
                        {button}
                    </div>
                </div>
                {userName &&
                    <div className="flex pt-3 border-t mt-4">
                        {userImg}
                        <div className="ml-4 justify-center items-center">
                            <p className="font-quicksand text-xs text-left mt-1">{userRole}</p>
                            <p className="font-quicksand text-sm text-left">{userName}</p>
                        </div>
                    </div>}
            </div>
        </Card>
    )
}

const CardSettingRow = ({
    img,
    label,
    subLabel,
    dateLeft,
    price,
    cryptoPrice,
    date, button,
    userImg,
    userRole,
    assetId,
    userName,
    typeTransaction,
    responsive,
    type,
    onClickUser,
    status = null,
    buttonCancel,
    invoiceStatus,
    isFiat = false,
    isFromInvoice = false,
}) => {
    const navigate = useNavigate()
    let invoiceType
    let txnLogType
    if(isFromInvoice){
    switch (typeTransaction) {
        case INVOICE_BUY:
            invoiceType = "Pembelian"
            break;
        case INVOICE_LISTING:
            invoiceType = "Aktifkan Penjualan"
            break;
        case INVOICE_CANCEL_LISTING:
            invoiceType = "Batalkan Penjualan"
            break;
        case INVOICE_CREATE_ASSET:
            invoiceType = "Pembuatan Asset"
            break;
        case INVOICE_ACCEPT_OFFER:
            invoiceType = "Terima Penawaran"
            break;
        case INVOICE_CANCEL_OFFER:
            invoiceType = "Batalkan Penawaran"
            break;
        case INVOICE_SETTLE_AUCTION:
            invoiceType = "Penutupan Lelang"
            break;
        case INVOICE_CANCEL_AUCTION:
            invoiceType = "Pembatalan Lelang"
            break;
        case INVOICE_CANCEL_BIDDER_AUCTION :
            invoiceType = "Pembatalan Penawaran Lelang"
            break;
        case INVOICE_ADD_BANK :
            invoiceType = "Penambahan Rekening Bank"
            break;
        default:
            break;
    }} else {
    switch (typeTransaction) {
        case TXN_TYPES_BUY:
            txnLogType = "Pembelian"
            break;
        case TXN_TYPES_LISTING:
            txnLogType = "Aktifkan Penjualan"
            break;
        case TXN_TYPES_CANCEL_LISTING:
            txnLogType = "Batalkan Penjualan"
            break;
        case TXN_TYPES_CREATE_ASSET:
            txnLogType = "Pembuatan Asset"
            break;
        case TXN_TYPES_ACCEPT_OFFER:
            txnLogType = "Terima Penawaran"
            break;
        case TXN_TYPES_CANCEL_OFFER:
            txnLogType = "Batalkan Penawaran"
            break;
        case TXN_TYPES_SETTLE_AUCTION:
            txnLogType = "Penutupan Lelang"
            break;
        case TXN_TYPES_CANCEL_AUCTION:
            txnLogType = "Pembatalan Lelang"
            break;
        case TXN_TYPES_CANCEL_BIDDER_AUCTION :
            txnLogType = "Pembatalan Penawaran Lelang"
            break;
        case TXN_TYPES_ADD_BANK :
            txnLogType = "Penambahan Rekening Bank"
            break;
        case TXN_TYPES_MAKE_OFFER :
            txnLogType = "Penawaran Asset"
            break;
        case TXN_TYPES_BID_AUCTION :
            txnLogType = "Penawaran Lelang"
            break;
        case TXN_TYPES_EDIT_METADATA :
            txnLogType = "Unggah Ulang Gambar"
            break;
        default:
            break;
    }}
    return (
        !responsive ?
            <Card className='setting-main-card inline-flex justify-between px-8 py-8' width={1070} height={191}>
                <div className="inline-flex">
                    <div className="h-32 w-52 flex items-center justify-center mr-5">
                        {
                            type === IMAGE_FILE_TYPE ?
                                <img alt="asset" src={img !== null ? img + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} onClick={() => navigate(`/asset/${assetId}`)} className="cursor-pointer h-32 w-52 rounded" />
                                : type === VIDEO_FILE_TYPE ?
                                    <Player className="object-cover max-h-full max-w-full mr-5" fluid={false} height={"100%"} width={"100%"} preload="metadata" src={img}>
                                        <BigPlayButton className="custom-big-play-button" />
                                        <ControlBar autoHide={false} disableDefaultControls={true} />
                                    </Player>
                                    : type === MUSIC_FILE_TYPE ? 
                                    <ReactAudioPlayer
                                        src={img}
                                        autoPlay={false}
                                        controls
                                    /> : <img alt="bank" src={UserImage} className="cursor-pointer h-32 w-52 rounded"/>
                        }
                    </div>
                    <div className={`flex flex-col  ${subLabel ? "pt-4" : "pt-5"}`}>
                        <p onClick={() => navigate(`/asset/${assetId}`)} className="mb-2 cursor-pointer text-hijau_hutan">{label}</p>
                        <p className={`font-medium font-quicksand mb-6 `}>{subLabel}</p>
                        <p className={`font-medium text-xs font-quicksand -mt-4 mb-3 `}>{dateLeft}</p>
                        {cryptoPrice && <NumberFormat value={cryptoPrice} displayType={'text'} thousandSeparator={true}
                            renderText={(value, props) => <div className="flex-row flex items-center pr-3 mr-3">
                                <img alt="matic token" src={MaticTokenIcon} className={`self-center w-4 h-4 mr-2 `} />
                                <p className="font-semibold text-sm font-quicksand">{value}</p>
                            </div>
                            }
                        />}
                        {price &&
                            <NumberFormat thousandSeparator={true} value={price} displayType={"text"} renderText={(value, props) =>
                                <p className="font-semibold text-sm font-quicksand">Rp. {value}</p>

                            } />
                        }
                    </div>
                </div>
                <div className="flex flex-col items-end justify-center">
                    <p className="font-medium text-xs font-quicksand text-right mb-1">{date}</p>
                    <p className="font-medium text-xs font-quicksand text-right mb-1">{isFromInvoice ? invoiceType : txnLogType}</p>
                    <div className="mt-auto flex">
                        {isFiat ? (status === 0 && invoiceStatus !==1) && buttonCancel : status === 0 && buttonCancel}
                        {button}
                    </div>
                    <div onClick={onClickUser} className="cursor-pointer flex flex-col items-center">
                        {userImg}
                        <p className="font-quicksand text-xs text-center mt-1">{userRole}</p>
                        <p className="font-quicksand text-sm text-center">{userName}</p>
                    </div>
                </div>
            </Card> : <CardMobileSetting
                assetId={assetId}
                img={img}
                type={type}
                navigate={navigate}
                label={label}
                subLabel={subLabel}
                date={date}
                cryptoPrice={cryptoPrice}
                price={price}
                button={button}
                buttonCancel={buttonCancel}
                typeTransaction={isFromInvoice ? invoiceType : txnLogType}
                userImg={userImg}
                userName={userName}
                userRole={userRole}
                dateLeft={dateLeft}
            />
    )
}

export default CardSettingRow