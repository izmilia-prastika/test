import React, { useEffect, useState } from "react";
import { format, intervalToDuration } from 'date-fns'

const FooterBiddingCard = ({ expDate, ...props }) => {
    const date = new Date(expDate)
    const [remaining, setRemaining] = useState(intervalToDuration({
        start: new Date(),
        end: date
    }))
    useEffect(() => {
        const intervalId = setInterval(
            () => setRemaining(intervalToDuration({
                start: new Date(),
                end: date
            })),
            1000
        )
        return () => clearInterval(intervalId);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <div className="bg-pink_kuning opacity-95 py-2 px-6 items-end justify-end">
            <p className="font-quicksand font-semibold text-xs text-hitam mb-1">Lelang berakhir {format(date, 'd MMM y,h:mm a')}</p>
            <div className="grid grid-flow-col gap-y-1 gap-x-0 items-center justify-start">
                {/* <div className="grid grid-rows-2 grid-cols-4 gap-y-1 gap-x-4 w-2/5 justify-items-center"> */}
                {(remaining?.months !== 0 || remaining?.days) !== 0 &&
                    <>
                        <div className="text-sm font-quicksand text-red-600 font-bold mr-1">{remaining?.months * 30 + remaining?.days}</div>
                        <div className="text-xs font-quicksand text-hitam font-normal mr-2">Hari</div>
                    </>
                }
                {remaining?.hours !== 0 &&
                    <>
                        <div className="text-sm font-quicksand text-red-600 font-bold mr-1">{remaining?.hours}</div>
                        <div className="text-xs font-quicksand text-hitam font-normal mr-2">Jam</div>
                    </>
                }
                {remaining?.minutes !== 0 &&
                    <>
                        <div className="text-sm font-quicksand text-red-600 font-bold mr-1">{remaining?.minutes}</div>
                        <div className="text-xs font-quicksand text-hitam font-normal mr-2">Menit</div>
                    </>
                }
                {remaining?.seconds !== 0 &&
                    <>
                        <div className="text-sm font-quicksand text-red-600 font-bold mr-1">{remaining?.seconds}</div>
                        <div className="text-xs font-quicksand text-hitam font-normal mr-2">Detik</div>
                    </>
                }
            </div>
        </div>
    )

}
export default FooterBiddingCard