import React from "react";

const HeaderCardAsset = (props) => {
    return (
        <div {...props} className={`absolute inset-x-0 top-0  z-10  ${props.className}`}>
            {props.children}
        </div>
    )
}

export default HeaderCardAsset