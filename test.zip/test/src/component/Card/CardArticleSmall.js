import React, { useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserImage } from '../../assets'

const CardArticleSmall = ({thumbNail, title, category, date, className, id, slug, categorySlug, onAll}) => {
    const navigate = useNavigate()
    const navToDetail = useCallback(() => navigate(`/article/${slug}/${id}`), [navigate, id, slug])
    const navToCategory = useCallback((slug) => navigate(`/article/category/${slug}`), [navigate])
    return (
    <div className={`grid grid-cols-1 items-center md:pb-8 pb-0 mb-8 md:w-auto ${onAll ? 'w-full' : 'w-72'}  ${className}`}>
        <div className='flex items-center justify-center overflow-hidden bg-black object-cover h-52 mb-4 w-full rounded-lg cursor-pointer' onClick={navToDetail}>
            <img alt='user' src={!!thumbNail ? thumbNail : UserImage} className='h-full w-full object-cover'/>
        </div>
        <div className='flex flex-col justify-start w-full'>
            <div className='w-full'>
                <p className='font-semibold font-quicksand text-base text-oranye mb-2 cursor-pointer' onClick={!!categorySlug ? () => navToCategory(categorySlug) : null}>{category}</p>
                <p className='font-quicksand font-semibold text-lg text-hitam mb-2 cursor-pointer line-clamp' onClick={navToDetail}>{title}</p>
            </div>
            <div className='w-full justify-end items-end'>
                <p className='font-quicksand font-semibold text-abu_86 text-sm text-left'>Diunggah pada {!!date ? date.substr(0, 10) : "bulan ini"}</p>
            </div>
        </div>
    </div>
  )
}

export default CardArticleSmall