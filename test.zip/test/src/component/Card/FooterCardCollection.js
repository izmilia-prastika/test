import React from "react";

const FooterCardCollection = (props) => {
    return (
        <div className={`flex flex-col bg-white ${props.className}`} style={{height:props?.height}}>
            {props.children}
        </div>
    )
}

export default FooterCardCollection