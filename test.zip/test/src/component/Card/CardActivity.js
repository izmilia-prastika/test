// import { format } from "date-fns";
import React, { useContext } from "react";
import NumberFormat from "react-number-format";
import ReactAudioPlayer from "react-audio-player";
import { useNavigate } from "react-router-dom";
import { Player, ControlBar,BigPlayButton } from 'video-react';
import classNames from "classnames";
import socketContext from "../../context/Socket/socketContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import { MaticTokenIcon, UserImage } from "../../assets";
import VerifiedLogo from "../../assets/logo/verified_logo";
import ButtonLinkAddress from "../Button/ButtonLinkAddress";
import Card from "./Card";
import InfoText from "../Text/InfoText";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import { IMAGE_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType";
import { LISTING, MAKE_BID_AUCTION, MAKE_OFFER, SOLD } from "../../utils/constants/activityTypes";
import { renderIntervalDateText } from "../../utils/helper";

const CardContent = ({ price, matic_price, assetByAssetId, navigate, accountByToAccount, accountByFromAccount, fromAccountWording, toAccountWording, createdAt }) => {
    return (
        <div className="flex flex-col p-2">
            <div className="flex-row flex w-full items-end">
                <div onClick={() => navigate(`/asset/${assetByAssetId?.id}`)} className="h-28 w-36 items-center rounded-xl overflow-hidden justify-center flex mr-3 cursor-pointer">
                        {assetByAssetId?.type === IMAGE_FILE_TYPE ?
                            <img src={assetByAssetId?.thumbnailUrl ? assetByAssetId?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} className="object-cover h-28 w-36 rounded-xl bg-black" alt="nft" />
                            : assetByAssetId?.type === VIDEO_FILE_TYPE ?
                                <Player className="object-cover max-h-full max-w-full" fluid={false} height={"100%"} width={"100%"} preload="metadata" src={assetByAssetId?.thumbnailUrl}>
                                    <BigPlayButton className="custom-big-play-button" />
                                    <ControlBar autoHide={false} disableDefaultControls={true} />
                                </Player>
                                :
                                <ReactAudioPlayer
                                    style={{width:'100%'}}
                                    src={assetByAssetId?.thumbnailUrl}
                                    autoPlay={false}
                                    controls
                                />}
                </div>
                {/* <img className="w-44 h-28 rounded mr-5 mb-3 cursor-pointer" onClick={() => navigate(`/asset/${assetByAssetId?.id}`)} src={assetByAssetId?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE} /> */}
                <div className="flex flex-col ml-4 justify-center">
                    <div className="flex flex-row items-center  mb-1">
                        <p onClick={() => navigate(`/collection/${assetByAssetId?.collectionByCollectionId?.id}`)} className="cursor-pointer mr-2 font-bold text-base font-quicksand text-hijau_tua">{assetByAssetId?.collectionByCollectionId?.name}</p>
                        {assetByAssetId?.collectionByCollectionId?.isVerified && <VerifiedLogo />}
                    </div>
                    <p onClick={() => navigate(`/asset/${assetByAssetId?.id}`)} className="cursor-pointer text-base font-medium font-quicksand mb-3">{assetByAssetId?.name}</p>
                    <div className="flex flex-row">
                        {
                            accountByToAccount &&
                            <div className={`flex flex-col ${accountByFromAccount && "border-r-2 pr-4 mr-4"}`}>
                                <p className="text-xs font-normal font-quicksand text-abu_86">{toAccountWording}</p>
                                <ButtonLinkAddress onClick={() => navigate(`/account/${accountByToAccount?.id}`)} address={accountByToAccount?.address} userName={accountByToAccount?.userName} />
                            </div>
                        }
                        {accountByFromAccount &&
                            <div className={`flex flex-col border-abu_f2`}>
                                <p className="text-xs font-normal font-quicksand text-abu_86">{fromAccountWording}</p>
                                <ButtonLinkAddress onClick={() => navigate(`/account/${accountByFromAccount?.id}`)} address={accountByFromAccount?.address} userName={accountByFromAccount?.userName} />
                            </div>
                        }
                    </div>
                </div>
            </div>
            <div className="flex flex-row justify-between mt-5 items-end">
                <div className="flex flex-col">
                    <p className="font-medium text-xs font-quicksand text-abu_86 mb-1">Seharga</p>
                    <div className="flex flex-row items-center">
                        <img className="h-4 w-4 mr-2" src={MaticTokenIcon} alt="matic-icon" />
                        <NumberFormat displayType="text" thousandSeparator={true} value={price} decimalScale={2} renderText={(val) => <p className="font-semibold mr-2 text-base font-quicksand text-abu_86">{val}</p>} />
                        <NumberFormat displayType="text" thousandSeparator={true} value={parseFloat(price) * matic_price} decimalScale={0} renderText={(val) => <p className="font-semibold text-base font-quicksand text-abu_86">( IDR {val} )</p>} />
                    </div>
                </div>
                 <p className="font-normal text-xs font-abu_86 font-quicksand">{renderIntervalDateText(createdAt)}</p>
            </div>
        </div>
    )
}

const CardContentMobile = ({ price, matic_price, assetByAssetId, navigate, accountByToAccount, accountByFromAccount, fromAccountWording, createdAt, toAccountWording }) => {
    const handleToCollection = () => navigate(`/collection/${assetByAssetId?.collectionByCollectionId?.id}`)
    const handleToDetail = () => navigate(`/asset/${assetByAssetId?.id}`)
    const userNameFrom = accountByFromAccount?.userName
    const addressFrom = accountByFromAccount?.address
    const userNameTo = accountByToAccount?.userName
    const addressTo = accountByToAccount?.address
    const profilePicFrom = accountByFromAccount?.profilePictureUrl
    const profilePicTo = accountByToAccount?.profilePictureUrl
    const containerContent = classNames("bg-black flex items-center justify-center rounded-lg overflow-hidden", {"h-44": assetByAssetId?.type===IMAGE_FILE_TYPE}, { "h-80": assetByAssetId?.type === VIDEO_FILE_TYPE }, { "h-44": assetByAssetId?.type !== IMAGE_FILE_TYPE && assetByAssetId?.type !== VIDEO_FILE_TYPE })
    return (
        <div className="h-full flex flex-col">
            <div className={containerContent}>
                {assetByAssetId?.type === IMAGE_FILE_TYPE ?
                    <img alt="nft asset" onClick={handleToDetail} src={assetByAssetId?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE} style={{ maxWidth: "320px", heigth: "180px", maxHeight: "180px", objectFit: "contain" }} />
                    : assetByAssetId?.type === VIDEO_FILE_TYPE ?
                        <Player className="object-cover max-h-full max-w-full" fluid={false} height={"100%"} width={"100%"} preload="metadata" src={assetByAssetId?.thumbnailUrl}>
                            <BigPlayButton className="custom-big-play-button" />
                            <ControlBar autoHide={false} disableDefaultControls={true} />
                        </Player> :
                        <ReactAudioPlayer style={{width:'100%'}} src={assetByAssetId?.thumbnailUrl} autoPlay controls/>}
            </div>
            <div className="flex flex-row items-start justify-between mt-3">
                <div>
                    <div className="flex flex-row items-center  mb-1">
                        <p onClick={handleToCollection} className="cursor-pointer mr-2 font-bold text-sm font-quicksand text-hijau_tua">{assetByAssetId?.collectionByCollectionId?.name}</p>
                        {assetByAssetId?.collectionByCollectionId?.isVerified && <VerifiedLogo />}
                    </div>
                    <p onClick={handleToDetail} className="cursor-pointer text-xs font-medium font-quicksand mb-3">{assetByAssetId?.name}</p>
                </div>
                <div>
                    <p className="font-normal text-xs font-abu_86 font-quicksand mt-auto ml-auto">{renderIntervalDateText(createdAt)}</p>
                </div>
            </div>
            <div className="flex flex-row items-center mt-1 mb-5">
                {accountByFromAccount && <OwnerInfo src={!!profilePicFrom ? profilePicFrom + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} onClick={() => navigate(`/account/${accountByFromAccount?.id}`)} label={fromAccountWording} value={userNameFrom ? userNameFrom : `${addressFrom?.substring(0, 5)}...${addressFrom?.substring(addressFrom?.length - 4, addressFrom?.length)}`} />}
                {accountByToAccount && <div className="border border-dashed w-6 h-0 mx-4 border-gray-400"></div>}
                {accountByToAccount && <OwnerInfo src={!!profilePicTo ? profilePicTo + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} onClick={() => navigate(`/account/${accountByToAccount?.id}`)} label={"Dari"} value={userNameTo ? userNameTo : `${addressTo?.substring(0, 5)}...${addressTo?.substring(addressTo?.length - 4, addressTo?.length)}`} />}
            </div>
            <div>
                <p className="font-medium text-xs font-quicksand text-abu_86 mb-1">Seharga</p>
                <div className="flex flex-row items-center">
                    <img alt="nft asset" className="h-4 w-4 mr-2" src={MaticTokenIcon} />
                    <NumberFormat displayType="text" thousandSeparator={true} value={price} decimalScale={2} renderText={(val) => <p className="font-semibold mr-2 text-base font-quicksand text-black">{val}</p>} />
                    <NumberFormat displayType="text" thousandSeparator={true} value={parseFloat(price) * matic_price} decimalScale={0} renderText={(val) => <p className="font-semibold text-base font-quicksand text-black">( IDR {val} )</p>} />
                </div>
            </div>
        </div>

    )
}

const OwnerInfo = ({ src, className, onClick, label, value }) => {
    return (
        <div className={`flex items-center`}>
            <img alt="user" src={src} className="h-8 w-8 rounded-full whitespace-pre-line mr-2" />
            <InfoText onClick={onClick} className={"mr-2"} label={label} value={value} />
        </div>
    )
}

const CardActivity = ({ width = 429, height = 228, data,...props }) => {
    const navigate = useNavigate()
    const { assetByAssetId, accountByFromAccount, accountByToAccount, createdAt, price, type } = data
    const SocketContext = useContext(socketContext)
    const Responsive = useContext(ResponsiveContext)
    const { matic_price } = SocketContext
    const toAccountWording = type === MAKE_OFFER || type === MAKE_BID_AUCTION
        ? "Ditawar oleh"
        :
        type === SOLD ? "Dibeli oleh" :
            "Dijual oleh"
    const fromAccountWording = type === LISTING ? "Dijual Oleh" : "Dari"
    const cardClass = classNames("card-activity-background rounded-lg", { "px-4 py-5": !Responsive }, { "p-5": Responsive })
    return (
        <Card className={cardClass} width={Responsive ? "100%" : width} height={Responsive ? "auto" : height}>
            {Responsive ? <CardContentMobile
                price={price}
                matic_price={matic_price}
                assetByAssetId={assetByAssetId}
                navigate={navigate}
                accountByToAccount={accountByToAccount}
                accountByFromAccount={accountByFromAccount}
                createdAt={createdAt}
                toAccountWording={toAccountWording}
                fromAccountWording={fromAccountWording}
            /> :
                <CardContent
                    price={price}
                    matic_price={matic_price}
                    assetByAssetId={assetByAssetId}
                    navigate={navigate}
                    accountByToAccount={accountByToAccount}
                    accountByFromAccount={accountByFromAccount}
                    createdAt={createdAt}
                    toAccountWording={toAccountWording}
                    fromAccountWording={fromAccountWording}
                />}
        </Card>
    )
}

export default CardActivity