import { isFuture } from "date-fns"
import { useEffect, useRef, useState } from "react"
import { AUCTION } from "../../utils/constants/listedType"
import FooterCardAssetInfo from "../Info/FooterCardAssetInfo"
import CardAsset from "./CardAsset"
import FooterBiddingCard from "./FooterBiddingCard"
import FooterCardAsset from "./FooterCardAsset"
import { checkERC721, checkERC1155 } from "../../utils/nft-check-helper"
import { ERC1155 } from "../../utils/constants/contractType"
import { MUSIC_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType"
import ReactAudioPlayer from "react-audio-player"
import PauseIcon from "../../assets/icon/pause_icon"
import PlayIcon from "../../assets/icon/play_icon"
import { MEDIUM_THUMBNAIL_IMAGE_TYPE, } from "../../utils/constants/renderImgTypes"
import { Player, ControlBar, PlayToggle, BigPlayButton } from 'video-react';


const CardItem = props => {

    const {
        setAsset,
        setModalPrice,
        setShowModalVerifiedCheckout,
        settypeTransaction,
        nft,
        setShowPickPayment,
        collectionData,
        i,
        updateFormInput,
        navigate,
        setShowFiat,
        createMarket,
        isAnotherAsset = false, 
        className = '',
        setCancelTitleModal,
        setAssetBid,
        setShowCancelListing,
        getAuctionBlockchainListed,
        isBidderAuctionBlockchainUnlisted,
        isBuyBlockchainListed,
        setShowBidSucces,
        getUserBidBlockchainListed,
        getBuyBlockchainListed,
        getBidContractIdBlockchainListed,
        isAssetBlockchainListed,
    } = props

    // const { socket } = SocketContext
    const vidRef = useRef()
    const [isVidPlay, setIsVidPlay] = useState(false)
    const [disableBuy, setDisableBuy] = useState(false)
    const [socketDisableBuy, setSocketDisableBuy] = useState(false)

    const handleClickPlayButton = (e) => {
        setIsVidPlay(!isVidPlay)
        console.log('zap');
        e.stopPropagation()
        isVidPlay ?
            vidRef?.current?.pause()
            :
            vidRef?.current?.play()
    }

    useEffect(() => {
        
        const check = async () => {
            if (nft?.assetByAssetId?.tokenStandardType === ERC1155) {
                setDisableBuy(await checkERC1155(nft?.assetByAssetId))
            } else {
                setDisableBuy(checkERC721(nft?.assetByAssetId))
            }
        }
        check()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (

        <CardAsset className={`flex-col flex hover:shadow-xl ${className} ${isAnotherAsset ? 'h-card_asset_another' : 'lg:h-card_asset_1366 2xl:h-card_asset_1536 fhd:h-card_asset'}`} key={i}>
            <div className="flex h-view_card w-full overflow-hidden object-cover bg-black justify-center items-center cursor-pointer" onClick={() => navigate(`/asset/${nft?.id}`)}>
                 {nft?.assetByAssetId?.type === MUSIC_FILE_TYPE ?
                    <ReactAudioPlayer src={nft?.assetByAssetId?.thumbnailUrl} autoPlay={false} controls/>  :
                        nft?.assetByAssetId?.type === VIDEO_FILE_TYPE ?
                        <Player className="object-cover max-h-full max-w-full" fluid={false} height={"100%"} width={"100%"} preload="metadata" ref={vidRef} src={nft?.assetByAssetId?.thumbnailUrl}>
                            <BigPlayButton className="custom-big-play-button" />
                            <ControlBar autoHide={false} disableDefaultControls={true}>
                                <PlayToggle />
                            </ControlBar>
                        </Player> :
                <img alt="asset" src={nft?.assetByAssetId?.thumbnailUrl+MEDIUM_THUMBNAIL_IMAGE_TYPE} className="object-cover w-full h-full" />}
                {nft?.assetByAssetId?.type === VIDEO_FILE_TYPE &&
                    <div className="absolute top-4 right-4">
                        {isVidPlay ? <PauseIcon onClick={handleClickPlayButton} /> : <PlayIcon onClick={handleClickPlayButton} />}</div>
                }
            </div>
            <FooterCardAsset className="px-6 pt-2 pb-4"
                topAddon={nft?.assetByAssetId?.isListed && nft?.assetByAssetId?.listedType === AUCTION && isFuture(new Date(nft?.assetByAssetId?.listedExpirationDate)) ?
                    <FooterBiddingCard expDate={nft?.assetByAssetId?.listedExpirationDate} /> : null
                    // : disableBuy !== null ? 
                    // <FooterAssetUnavailable setDisableBuy={setDisableBuy} createdDate={disableBuy.createdAt} /> :
                    // socketDisableBuy === true && <FooterAssetUnavailable setSocketDisableBuy={setSocketDisableBuy} minutes={5} />
                }>
                <FooterCardAssetInfo
                    idUtility={nft?.id}
                    data={nft?.assetByAssetId}
                    setAsset={setAsset}
                    setShowPickPayment={setShowPickPayment}
                    setModalPrice={setModalPrice}
                    setShowModalVerifiedCheckout={setShowModalVerifiedCheckout}
                    settypeTransaction={settypeTransaction}
                    socketDisableBuy={socketDisableBuy}
                    createMarket={createMarket}
                    disableBuy={disableBuy}
                    setShowFiat={setShowFiat}
                    getBidContractIdBlockchainListed={getBidContractIdBlockchainListed}
                    updateFormInput={updateFormInput}
                    setDisableBuy={setDisableBuy}
                    setSocketDisableBuy={setSocketDisableBuy}
                    collectionData={collectionData}
                    isAnotherAsset={isAnotherAsset}
                    setCancelTitleModal={setCancelTitleModal}
                    setAssetBid={setAssetBid}
                    setShowBidSucces={setShowBidSucces}
                    getUserBidBlockchainListed={getUserBidBlockchainListed}
                    getBuyBlockchainListed={getBuyBlockchainListed}
                    setShowCancelListing={setShowCancelListing}
                    getAuctionBlockchainListed={getAuctionBlockchainListed}
                    isBuyBlockchainListed={isBuyBlockchainListed}
                    isBidderAuctionBlockchainUnlisted={isBidderAuctionBlockchainUnlisted} 
                    isAssetBlockchainListed={isAssetBlockchainListed}           
                />
            </FooterCardAsset>
            {/* <HeaderCardAsset onClick={() => collectionData?.id && navigate(`/collection/${collectionData?.id}`)} className="cursor-pointer">
                <div className="flex flex-col gradient-background-t">
                    <div className="w-full items-center px-6 py-4 transform rotate-180 flex flex-row justify-start">
                        <img className="object-cover rounded-full  h-10 w-10" src={!!collectionData?.logoUrl ? collectionData?.logoUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} />
                        <p className="text-white font-quicksand text-sm pl-3.5 pr-2">
                            {collectionData?.name}
                        </p>
                        {collectionData?.isVerified &&
                            <VerifiedLogo />
                        }
                    </div>
                </div>
                {nft?.type === VIDEO_FILE_TYPE &&
                    <div className="flex w-full justify-end pt-4 pr-4">
                        {isVidPlay ?
                            <PauseIcon onClick={handleClickPlayButton} />
                            :
                            <PlayIcon onClick={handleClickPlayButton} />

                        }
                    </div>
                }
            </HeaderCardAsset>
            <div className="w-full h-full inline-flex items-center justify-center bg-transparent cursor-pointer" onClick={() => navigate(`/asset/${nft?.id}`)}>
                {nft?.type === MUSIC_FILE_TYPE ?
                    <ReactAudioPlayer
                        src={nft?.thumbnailUrl}
                        autoPlay={false}
                        controls
                    />
                    : nft?.type === VIDEO_FILE_TYPE ?
                        <Player preload="metadata" ref={vidRef} src={nft?.thumbnailUrl}>
                            <BigPlayButton className="custom-big-play-button" />
                            <ControlBar autoHide={false} disableDefaultControls={true}>
                                <PlayToggle />
                            </ControlBar>
                        </Player>
                        :

                        <img src={nft?.thumbnailUrl + SMALL_THUMBNAIL_IMAGE_TYPE} className="object-cover max-w-full mx-auto h-full align-middle" />
                }
            </div>
            <FooterCardAsset className="px-5 pt-7 pb-6"
                topAddon={nft?.isListed && nft?.listedType === AUCTION && isFuture(new Date(nft?.listedExpirationDate)) ?
                    <FooterBiddingCard expDate={nft?.listedExpirationDate} /> : null
                    // : disableBuy !== null ? 
                    // <FooterAssetUnavailable setDisableBuy={setDisableBuy} createdDate={disableBuy.createdAt} /> :
                    // socketDisableBuy === true && <FooterAssetUnavailable setSocketDisableBuy={setSocketDisableBuy} minutes={5} />
                }>
                <FooterCardAssetInfo
                    data={nft}
                    setAsset={setAsset}
                    setShowPickPayment={setShowPickPayment}
                    setModalPrice={setModalPrice}
                    setShowModalVerifiedCheckout={setShowModalVerifiedCheckout}
                    settypeTransaction={settypeTransaction}
                    socketDisableBuy={socketDisableBuy}
                    socketAmount={socketAmount}
                    createMarket={createMarket}
                    disableBuy={disableBuy}
                    setShowFiat={setShowFiat}
                    updateFormInput={updateFormInput}
                    setDisableBuy={setDisableBuy}
                    setSocketDisableBuy={setSocketDisableBuy}
                />
            </FooterCardAsset> */}
        </CardAsset>
    )
}

export default CardItem