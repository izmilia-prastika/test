import React from "react";

const FooterCard = ({ children }) => {
    return (
        <div className="bg-white rounded-b-md">
            {children}
        </div>
    )
}

export default FooterCard