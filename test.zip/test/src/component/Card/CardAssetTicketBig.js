import { format } from "date-fns";
import { Dummy } from "../../assets";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import Skeleton from 'react-loading-skeleton'
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";

const CardAssetTicketBig = ({ asetDetail, collection, loading }) => {
  return (
    <div className="bg-white shadow-md rounded-xl pb-6">
      <div className="rounded-t-xl overflow-hidden bg-black object-contain h-60 md:h-96 fhd:h-card_asset justify-center items-center flex">
        {!loading ? <img
          src={
            asetDetail?.assetByAssetId?.thumbnailUrl
              ? asetDetail?.assetByAssetId?.thumbnailUrl +
                SMALL_THUMBNAIL_IMAGE_TYPE
              : Dummy
          }
          alt=""
          className="w-full h-full"
        /> : <SpinCircleLogo className="justify-center items-center" type={'big'}/>}
      </div>
      <div className="justify-center bg-white items-center mt-4 md:mt-6">
        <p className="text-center text-sm md:text-base fhd:text-lg md:mb-2 font-quicksand font-semibold text-oranye">
          {!loading ? collection?.name ? collection.name : 'Belum masuk koleksi' : <Skeleton width={180} height={20}/>}
        </p>
        <p className="text-center md:text-2xl fhd:text-3xl mb-2 md:mb-6 font-quicksand font-extrabold text-hitam">
          {!loading ? asetDetail?.assetByAssetId?.name : <Skeleton width={200} height={28}/>}
        </p>
        <p className="text-center text-sm md:text-base fhd:text-lg font-quicksand text-abu_86 font-semibold">
          {!loading ? asetDetail?.assetByAssetId?.utilitiesExpiredDate ? format(new Date(asetDetail?.assetByAssetId?.utilitiesExpiredDate), "d MMMM y") : 'Maaf tanggal event belum tersedia...' : <Skeleton height={20} width={200}/>}
        </p>
      </div>
    </div>
  );
};

export default CardAssetTicketBig;
