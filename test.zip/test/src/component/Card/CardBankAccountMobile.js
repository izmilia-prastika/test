import React, { useContext, useEffect } from "react";
import CCardIcon from "../../assets/icon/ccard_icon";
import PersonIcon from "../../assets/icon/person_icon";
import Card from "./Card";
import classNames from "classnames";
import bankContext from "../../context/Bank/bankContext";
import AccountBalanceIcon from "../../assets/icon/account_balance_icon";
// import BinIcon from "../../assets/icon/bin_icon";
// import ChecklistIcon from "../../assets/icon/checklist_icon";
// import accountsBankContext from "../../context/AccounsBank/accountsBankContext";
// import authContext from "../../context/Auth/authContext";
// import Button from "../Button/Button";
// import ButtonLink from "../Button/ButtonLink";
// import ButtonText from "../Text/ButtonText";

const CardBankAccountMobile = ({
    data,
    setShowModalDelete,
    setIdDeleted,
    ...props
}) => {
    const { accountNumber, bankName, holderName} = data
    const BankContext = useContext(bankContext)
    useEffect(() => {
        if (data?.accountNumber !== "") {
            BankContext?.getAll()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data])
    // const selectedBank = BankContext.banks?.filter(el => el.code === bankName)
    const bgCard = classNames("flex flex-col gap-y-2 shadow-lg p-5 rounded-lg")

    return (
        <Card {...props} className={bgCard}>
            {/* <div className="flex w-full justify-between items-center">
                <img src={selectedBank[0]?.imageUrl} className="w-10" alt="bank id"/>
            </div> */}
            <div className="flex flex-row items-center">
                <AccountBalanceIcon size={5}/>
                <p className="font-semibold ml-2 font-quicksand text-xs">{bankName}</p>
            </div>
            <div>
                <div className="flex flex-row items-center">
                    <CCardIcon />
                    <p className="text-xs ml-2 text-hitam_2">{accountNumber}</p>
                </div>
            </div>
            <div>
                <div className="flex flex-row items-center">
                    <PersonIcon />
                    <p className="text-xs ml-2 text-hitam_2">{holderName}</p>
                </div>
            </div>
        </Card>
    )
}

export default CardBankAccountMobile