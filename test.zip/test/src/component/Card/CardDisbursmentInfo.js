import React from "react";
import NumberFormat from "react-number-format";
import { MaticTokenIcon } from "../../assets";
import Card from "./Card";

const CardDisbursmentInfo = ({ img, title, price, titleColor, className, submitButton, width = 388, height = 114, titleStyle = "flex flex-col md:pl-4 pl-0", isRp = true }) => {
    return (
        <Card className={`setting-info-card flex flex-row items-center ${className}`} height={height} width={width}>
            <img alt="disbursment" src={img} className="h-14 md:h-full"/>
            <div className={titleStyle}>
                <p className={`font-medium font-quicksand md:text-sm text-xs text-${titleColor}`}>{title}</p>
                <NumberFormat thousandSeparator={true} decimalScale={2} displayType="text" value={price} renderText={(value) =>
                    <div className="flex items-center">
                        {!isRp && <img src={MaticTokenIcon} className="h-4 w-4 mr-2" alt=""/>}
                        <p className="font-semibold font-quicksand md:text-lg text-sm">{isRp && "Rp."} {value}</p>
                    </div>
                } />
            </div>
            {submitButton}
        </Card>
    )
}

export default CardDisbursmentInfo