import { useContext, useState } from "react";
import accountsBankContext from "../../context/AccounsBank/accountsBankContext";
import authContext from "../../context/Auth/authContext";
import AccountBanksInfo from "../Info/AccountBanksInfo";
import ModalConfirmation from "../Modal/ModalConfirmation";
import Splitter from "../Panel/Splitter";
import SplitterPanel from "../Panel/SplitterPanel";
import Card from "./Card";
import CardBankAccountMobile from "./CardBankAccountMobile";
// import { ethers } from "ethers";
// import web3ModalContext from "../../context/Web3Modal/web3ModalContext";
// import BankContract from "../../artifacts/contracts/BankAccounts.sol/BankAccounts.json"
// import { bankAddres } from "../../config/configContract";

const CardBankAccount = ({responsive, data, handleEdit}) => {
    const AccountsBankContext = useContext(accountsBankContext)
    const AuthContext = useContext(authContext)
    const [idDeleted,setIdDeleted]  = useState("")
    const [showModalDelete, setShowModalDelete] = useState(false)

    const handleDelete = async () => {
        await AccountsBankContext.delete(idDeleted)
        await AccountsBankContext?.getById(AuthContext?.auth?.user?.id)
        setShowModalDelete(false)
    }
    return (
        <>
            {responsive ? 
            <div className="grid grid-cols-1 gap-4 mt-4">
                    <CardBankAccountMobile setShowModalDelete={setShowModalDelete} setIdDeleted={setIdDeleted} data={data} />
            </div> : 
            <Card className="py-0 px-0 setting-main-card mt-4" width={responsive ? "100%" : 1070}>
                <Splitter>
                    <SplitterPanel className={"px-10 pt-10 pb-8 justify-between flex flex-row"}>
                        <AccountBanksInfo setShowModalDelete={setShowModalDelete} setIdDeleted={setIdDeleted} data={data}  handleEdit={handleEdit} />
                    </SplitterPanel>
                </Splitter>
            </Card>
            }
            <ModalConfirmation show={showModalDelete} setShow={setShowModalDelete} onSubmit={handleDelete} responsive={responsive}/>
        </>
    )
}

export default CardBankAccount