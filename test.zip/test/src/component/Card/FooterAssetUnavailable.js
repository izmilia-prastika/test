import React, { useEffect, useState } from "react";
import { format, intervalToDuration, addMinutes, addSeconds } from 'date-fns'

const FooterAssetUnavailable = ({ createdDate, minutes, setSocketDisableBuy, setDisableBuy, ...props }) => {
    let date
    if (minutes) {
      date = addMinutes(new Date(), minutes)
    }
    if (createdDate) {
      const {seconds, minutes: minute} = intervalToDuration({
        start: new Date(), end: addMinutes(new Date(createdDate), 5)
      })
      date = addMinutes(new Date(), minute)
      date = addSeconds(date, seconds)
    }
    const [remaining, setRemaining] = useState(intervalToDuration({
        start: new Date(),
        end: date
    }))
    useEffect(() => {
        const intervalId = setInterval(
            () => {
              return setRemaining(intervalToDuration({
                start: new Date(),
                end: date
              }))
            } ,
            1000
        )
        return () => clearInterval(intervalId);
    }, [])
    useEffect(() => {
      if(minutes && remaining?.seconds === 0 && remaining?.minutes === 0) {
        setSocketDisableBuy(false)
      }
      if(remaining?.seconds === 0 && remaining?.minutes === 0 && createdDate) {
        setDisableBuy(false)
      }
    }, [remaining?.seconds])

    return (
        <div className="bg-pink_kuning opacity-95 py-4 px-6 items-end justify-end">
            <p className="font-quicksand font-semibold text-xs text-hitam mb-1">Aset Dikunci, Bisa Dibeli {format(date, 'd MMMM y,h:m a')}</p>
            <div className="grid grid-rows-2 grid-cols-4 gap-y-1 gap-x-4 w-2/5 justify-items-center">
                <div className="text-sm font-quicksand text-red-600 font-bold">{remaining?.months * 30 + remaining?.days}</div>
                <div className="text-sm font-quicksand text-red-600 font-bold">{remaining?.hours}</div>
                <div className="text-sm font-quicksand text-red-600 font-bold">{remaining?.minutes}</div>
                <div className="text-sm font-quicksand text-red-600 font-bold">{remaining?.seconds}</div>
                <div className="text-xs font-quicksand text-hitam font-normal">Hari</div>
                <div className="text-xs font-quicksand text-hitam font-normal">Jam</div>
                <div className="text-xs font-quicksand text-hitam font-normal">Menit</div>
                <div className="text-xs font-quicksand text-hitam font-normal">Detik</div>
            </div>
        </div>
    )

}
export default FooterAssetUnavailable