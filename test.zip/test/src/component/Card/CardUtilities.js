import React, { useState } from "react";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
import QRCode from "qrcode.react";
import Skeleton from "react-loading-skeleton";
import { PatternMembership } from "../../assets";
import {
  UTIL_TICKET_TYPE,
  UTIL_MEMBERSHIP_TYPE,
  UTIL_CODE_TYPE,
} from "../../utils/constants/utilitesTypes";
import { format } from "date-fns";
import { toast } from "react-toastify";
import ModalQrCode from "../Modal/ModalQrCode";
import CopyIcon from "../../assets/icon/copy_icon";

const QrCodeContent = ({ code, loading }) => {
  return (
    <div className="mb-8">
      {!loading ? (
        <QRCode id="myQR" value={code} size={200} includeMargin={true} />
      ) : (
        <Skeleton width={200} height={200} />
      )}
    </div>
  );
};

const CodeContent = ({ code, loading, handleCopy}) => {
  return (
    <div className="px-12 py-6 bg-hijau_notif rounded-lg mt-8 mb-12">
      {!loading ? (
        <div className="flex gap-x-4 items-center justify-center cursor-pointer" onClick={() => handleCopy(code)}>
          <p className="font-quicksand text-xl font-black">{code}</p>
          <CopyIcon />
        </div>
      ) : (
        <Skeleton height={29} width={180} />
      )}
    </div>
  );
};

const MembershipContent = ({ data, loading }) => {
  return (
    <div className="h-48 md:h-60 w-auto md:w-bar_notification rounded-3xl overflow-hidden relative mt-4 mb-8">
      <img
        src={PatternMembership}
        className="w-full h-full object-fill z-0"
        alt=""
      />
      <div className="z-20 absolute top-8 left-8">
        <p className="font-quicksand font-semibold text-white text-lg">
          Membership Card
        </p>
      </div>
      <div className="z-20 absolute bottom-8 left-8">
        {!loading ? (
          <p className="font-quicksand font-semibold text-white text-2xl mb-2">
            {data?.code}
          </p>
        ) : (
          <Skeleton height={26} width={200} className="mb-2" />
        )}
        <div className="mb-2">
          <p className="font-quicksand font-semibold text-white text-sm">
            VALID THRU
          </p>
          {!loading ? (
            <p className="font-quicksand font-semibold text-white text-sm">
              {data?.assetByAssetId?.utilitiesExpiredDate
                ? format(
                    new Date(data?.assetByAssetId?.utilitiesExpiredDate),
                    "MM/yy"
                  )
                : "Loading..."}
            </p>
          ) : (
            <Skeleton height={16} width={48} />
          )}
        </div>
      </div>
    </div>
  );
};

const CardUtilities = ({ data, caption, loading }) => {
  let Title;
  let TeksButton;
  let TitleModal;
  const typeUtilities = data?.assetByAssetId?.utilitiesType;
  const [show, setshow] = useState(false)
  const downloadQRCode = () => {
    const canvas = document.getElementById("myQR");
    const pngUrl = canvas
      .toDataURL("image/png")
      .replace("image/png", "image/octet-stream");
    let downloadLink = document.createElement("a");
    downloadLink.href = pngUrl;
    downloadLink.download = `myQR.png`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };
  
  const handleCopy = async (text) => {
    await navigator.clipboard.writeText(text);
    toast("Kode Berhasil Disalin", {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const handleShowQR = () => {
    setshow(!show)
  }

  switch (typeUtilities) {
    case 1:
      Title = "Kode QR Kamu";
      TeksButton = "Unduh Kode QR";
      break;
    case 2:
      Title = "Kode Kamu";
      TeksButton = "Lihat Kode QR";
      TitleModal = "Kode QR Kamu"
      break;
    case 3:
      Title = "Kartu Membership";
      TeksButton = "Lihat Kode QR"
      TitleModal = "Kode QR Membership"
      break;
    default:
      break;
  }
  return (
    <>
    <div className="justify-center flex flex-col bg-white items-center px-4 md:px-12 py-12 border border-gray-100 shadow-md rounded-lg mb-8 md:mb-0">
      <div
        id="header-ticket"
        className="mb-4 justify-center items-center flex flex-col"
      >
        {!loading ? (
          <p className="font-quicksand md:text-2xl fhd:text-3xl text-center font-extrabold mb-4">
            {Title}
          </p>
        ) : (
          <Skeleton height={28} width={200} className="mb-4" />
        )}
        {!loading ? (
          <p className="font-quicksand md:text-base fhd:text-lg text-center">
            {caption}
          </p>
        ) : (
          <Skeleton height={20} width={350} />
        )}
      </div>
      {typeUtilities === UTIL_CODE_TYPE ? (
        <QrCodeContent code={data?.code} loading={loading} />
      ) : typeUtilities === UTIL_TICKET_TYPE ? (
        <CodeContent code={data?.code} loading={loading} handleCopy={handleCopy}/>
      ) : (
        <MembershipContent data={data} loading={loading} />
      )}
        <RoundedButton
          className="py-4 px-12"
          onClick={() =>
            typeUtilities === UTIL_TICKET_TYPE
              ? handleShowQR() : 
              typeUtilities === UTIL_CODE_TYPE ? downloadQRCode() : handleShowQR()
          }
        >
          <ButtonText tx={TeksButton} classstyle="text-lg" />
        </RoundedButton>
    </div>
    <ModalQrCode 
      show={show} 
      title={TitleModal} 
      code={data?.code}
      setShow={setshow}
      downloadFunc={downloadQRCode}
      />
    </>
  );
};

export default CardUtilities;
