import React, { useCallback, useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserImage } from '../../assets'

const CardArticleBig = ({thumbNail, title, category, info, date, className, id, slug, categorySlug}) => {
    const [contentSubstring, setContentSubstring] = useState(info);
    const navigate = useNavigate()
    const navToDetail = useCallback(() => navigate(`/article/${slug}/${id}`), [navigate, slug, id])
    const navToCategory = useCallback((slug) => navigate(`/article/category/${slug}`), [navigate])
    useEffect(() => {
        const contents = document.getElementById(`content-${id}`)
        setContentSubstring(contents?.children[0]?.outerHTML);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
    <div className={`grid md:grid-cols-4 grid-cols-1 gap-x-8 border-b items-center pb-8 mb-8 ${className}`}>
        <div className='flex items-center justify-center overflow-hidden bg-black object-cover h-44 w-full md:mr-8 mr-0 md:mb-0 mb-4 rounded-lg cursor-pointer' onClick={navToDetail}>
            <img src={!!thumbNail ? thumbNail : UserImage} className='h-full w-full object-cover' alt='thumb'/>
        </div>
        <div className='flex flex-col justify-between md:h-full h-auto w-full md:col-span-3 col-auto'>
            <div className='w-full'>
                <p className='font-semibold font-quicksand md:text-base text-sm cursor-pointer text-oranye mb-3' onClick={()=>navToCategory(categorySlug)}>{category}</p>
                <p className='font-quicksand font-semibold md:text-lg text-base text-hitam mb-2 cursor-pointer line-clamp' onClick={navToDetail}>{title}</p>
                <p id={`content-${id}`} className='font-quicksand font-normal text-base text-hitam_2 w-full line-clamp cursor-pointer md:mb-0 mb-6' dangerouslySetInnerHTML={{ __html: contentSubstring}} onClick={navToDetail}></p>
            </div>
            <div className='w-full justify-end items-end'>
                <p className='font-quicksand font-semibold text-abu_86 text-sm text-right'>Diunggah pada {!!date ? date.substr(0,10) : "bulan ini"}</p>
            </div>
        </div>
    </div>
  )
}

export default CardArticleBig