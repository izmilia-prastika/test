import React, { useEffect, useMemo, useState } from "react";
import { format, intervalToDuration, isPast } from 'date-fns'

const CardBidding = ({ expDate, className, ...props }) => {
    const date = useMemo(()=>new Date(expDate),[expDate])
    const [remaining, setRemaining] = useState(intervalToDuration({
        start: new Date(),
        end: date
    }))
    const [isDateExpired,setIsDateExpired] = useState(false)
    useEffect(() => {
        const intervalId = setInterval(
            () => {
                setRemaining(intervalToDuration({
                    start: new Date(),
                    end: date
                }))
                if(isPast(date)){
                    setIsDateExpired(true)
                }
            },
            1000
        )
        // eslint-disable-next-line react-hooks/exhaustive-deps

        return () => clearInterval(intervalId);
    }, [date])
    if (isDateExpired) {
        return null
    } else {
        return (
            <div className={`md:bg-transparent bg-red-100 md:w-auto w-full opacity-95 md:items-end items-start md:justify-end justify-start ${className}`}>
                <p className="font-quicksand font-semibold text-base text-hitam mb-1">Lelang berakhir {format(date, 'd MMMM y,h:mm a')}</p>
                <div className="grid grid-rows-2 grid-cols-4 gap-y-1 gap-x-4 md:justify-items-end justify-items-start">
                    <div className="w-full text-center text-base font-quicksand text-red-600 font-bold">{remaining?.months * 30 + remaining?.days}</div>
                    <div className="w-full text-center text-base font-quicksand text-red-600 font-bold">{remaining?.hours}</div>
                    <div className="w-full text-center text-base font-quicksand text-red-600 font-bold">{remaining?.minutes}</div>
                    <div className="w-full text-center text-base font-quicksand text-red-600 font-bold">{remaining?.seconds}</div>
                    <div className="w-full text-center text-base font-quicksand text-hitam font-normal">Hari</div>
                    <div className="w-full text-center text-base font-quicksand text-hitam font-normal">Jam</div>
                    <div className="w-full text-center text-base font-quicksand text-hitam font-normal">Menit</div>
                    <div className="w-full text-center text-base font-quicksand text-hitam font-normal">Detik</div>
                </div>
            </div>
        )
    }

}
export default CardBidding