import React, { useContext } from "react";
import { Chart } from 'primereact/chart';
import ResponsiveContext from "../../context/Responsive/responsiveContext";

const LineCharts = (props) => {
    const Responsive = useContext(ResponsiveContext)
    return (
        <div className="card">
            <Chart type="line" height={Responsive ? "300px" : undefined} {...props} />
        </div>
    )
}

export default LineCharts