import React, { useContext, useEffect } from "react";
import assetActivitiesContext from "../../context/AssetActivities/assetActivitiesContext";
// import _ from 'lodash'
import { useParams } from "react-router-dom";
import EmptyStateSection from "../Panel/EmptyState";
import {format} from "date-fns"
import Table from "../Table/Table";
import NumberFormat from "react-number-format";
import { MaticTokenIcon } from "../../assets";
import ResponsiveContext from "../../context/Responsive/responsiveContext";

const PriceHistoryChart = ({ data, isActivePage }) => {
    const AssetActivitiesContext = useContext(assetActivitiesContext)
    const responsive = useContext(ResponsiveContext)
    const params = useParams()
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(async () => {
        if (isActivePage) {
            await AssetActivitiesContext?.getAssetPriceHistory(params?.id)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data, isActivePage])

    const columns = [
        {
            name: 'Transaksi ke',
            selector: (_, index) => Math.abs(index - AssetActivitiesContext?.priceHistory.length) ,
            width: "20%",
            // cell: (_, index) => <div className="pl-2">{index + 1}</div>,
        },
        {
            name: 'Tanggal',
            minWidth: '35%',
            maxWidth: '50%',
            selector: row =>        
                <div>
                    <p>{format(new Date(row?.createdAt), 'd MMMM y')}</p>
                </div>,
            sortable: true,
        },
        {
            name: 'Harga',
            minWidth: '35%',
            maxWidth: '50%',
            cell: row =>
                <NumberFormat value={row?.price} decimalScale={0} displayType={'text'} thousandSeparator={true}
                    renderText={(value, props) => <div className={`flex flex-row space-x-3 ${data?.publishedPrice === 0 && "invisible"}`}>
                        <img src={MaticTokenIcon} className="self-center w-4 h-4 -mr-2" alt="matic"/>
                        <p className='text-lg font-bold font-quicksand whitespace-nowrap text-hitam_2'>{row?.price}</p>
                    </div>
                    }
                />,
            sortable: true,
        },
    ];

    const customStyles = {
        rows: {
            style: {
                minHeight: '78px', // override the row height
                marginBottom: '10px',
                fontFamily: "Quicksand",
                fontStyle: "normal",
                fontWeight: "regular",
                fontSize: responsive ? "14px" : "18px",
                lineHeight: "17px",
                /* identical to box height */

                letterSpacing: "-0.017em",

                /* Text 1 */

                color: "#222222",
            },
        },
        headRow: {
            style: {
                fontFamily: "Quicksand",
                fontStyle: "normal",
                fontWeight: "bold",
                fontSize: responsive ? "14px" : "18px",
                lineHeight: "17px",
                /* identical to box height */

                letterSpacing: "-0.017em",

                /* Text 2 */

                color: "#3C3C3B",
            }
        },
        headCells: {
            style: {
                minHeight: '78px',
                marginTop: !responsive ? '0px' : '0px',
                marginRight: !responsive ? '0px' : '48px',
                // paddingLeft: !responsive ? '32px' : '16px', // override the cell padding for head cells
                paddingRight: !responsive ? '8px' : '0px',
            },
        },
        cells: {
            style: {
                // paddingLeft: !responsive ? '8px' : '0px', // override the cell padding for data cells
                paddingRight: !responsive ? '8px' : '0px',
                marginRight: !responsive ? '0px' : '48px',
            },
        },
    };

    return (
        AssetActivitiesContext?.priceHistory.length !== 0 ? 
        <Table 
            columns={columns}
            data={AssetActivitiesContext?.priceHistory} 
            pagination
            customStyles={customStyles}
            paginationPerPage={5}
            paginationRowsPerPageOptions={[5,10,15,20]}  
        /> :
        <EmptyStateSection text="Belum ada Sejarah Harga"/>
    )
}

export default PriceHistoryChart