import React, { useContext } from "react"
import { MaticTokenIcon } from "../../assets"
import socketContext from "../../context/Socket/socketContext"
import TextNumber from "../Text/TextNumber"

const CurrentPriceInfo = ({ price = 0, className }) => {
    const SocketContext = useContext(socketContext)
    const { matic_price } = SocketContext
    return (
        <div className={className}>
            <p className="font-quicksand font-medium text-base text-hitam mb-1.5">Harga Saat Ini</p>
            <div className="flex flex-row space-x-1">
                <img alt="matic token" src={MaticTokenIcon} className="h-4 w-4 self-center" />
                <TextNumber className="font-quicksand font-semibold  tracking-wide text-base text-hitam" text={price} />
                <p className="font-quicksand font-normal text-base tracking-wide  text-abu_86 px-2">atau</p>
                <p className="font-quicksand font-semibold text-base tracking-wide  text-hitam">IDR</p>
                <TextNumber className="font-quicksand font-semibold  tracking-wide text-base text-hitam" text={price * matic_price} />
            </div>
        </div>
    )
}

export default CurrentPriceInfo