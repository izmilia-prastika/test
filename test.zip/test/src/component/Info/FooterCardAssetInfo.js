import { isFuture } from "date-fns";
import { useContext,  useState, useRef, useCallback } from "react";
import NumberFormat from "react-number-format";
import { toast } from "react-toastify";
import { /* HeartLogoImg, */ MaticTokenIcon, RpIcon } from "../../assets";
import assetContext from "../../context/Asset/assetContext";
import assetBidDetailContext from "../../context/AssetBidDetail/assetBidDetailContext";
import authContext from "../../context/Auth/authContext";
import socketContext from "../../context/Socket/socketContext";
import { AUCTION } from "../../utils/constants/listedType";
import TYPE_TRANSACTION from "../../utils/constants/typeTransaction";
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
// import UnavailableAssetInfo from "./UnavailableAssetInfo";
// import Modal from "../Modal/Modal";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { ERC1155, ERC721 } from "../../utils/constants/contractType";
import { checkERC721, checkERC1155 } from "../../utils/nft-check-helper"
import { useNavigate } from "react-router-dom";
import env from "../../config/env";
import OwnerIcon from "../../assets/icon/owner_icon";
import VerifiedLogo from "../../assets/logo/verified_logo";
// import { INVOICE_PAID, INVOICE_UNPAID } from "../../utils/constants/invoiceStatus";
// import KebabDotIcon from "../../assets/icon/kebab_dot_icon";
// import IconDropdown from "../Dropdown/IconDropdown";
import useHandleSyncingData from "../../utils/hooks/useHandleSyncingData";
import assetAuctionContext from "../../context/AssetAuction/assetAuctionContext";
// import fiatContext from "../../context/FiatPayment/fiatContext";
import Swal from "sweetalert2";
import txnContext from "../../context/Txn/txnContext";
import { TXN_TYPES_BID_AUCTION, TXN_TYPES_BUY, TXN_TYPES_MAKE_OFFER } from "../../utils/constants/transactionLogTypes";
import { TXN_STATUS_PENDING } from "../../utils/constants/transactionLogStatus";
import { ASSET_PATHNAME } from "../../utils/constants/domainTypes";
import ModalWaiting from "../Modal/ModalWaiting";
import { UTIL_TICKET_TYPE, UTIL_CODE_TYPE } from "../../utils/constants/utilitesTypes";

const FooterCardAssetInfo = ({
    idUtility,
    settypeTransaction,
    setAsset,
    setModalPrice,
    setShowPickPayment,
    setShowModalVerifiedCheckout,
    socketDisableBuy, setSocketDisableBuy,
    data,
    disableBuy, setDisableBuy,
    createMarket,
    collectionData,
    isAnotherAsset,
    setCancelTitleModal,
    setAssetBid,
    setShowCancelListing,
    getAuctionBlockchainListed,
    isBidderAuctionBlockchainUnlisted,
    isBuyBlockchainListed,
    setShowBidSucces,
    getUserBidBlockchainListed,
    getBuyBlockchainListed,
    getBidContractIdBlockchainListed,
    isAssetBlockchainListed,
    // updateFormInput,
    // setShowFiat,
}) => {
    const SocketContext = useContext(socketContext)
    const navigate = useNavigate()
    const { matic_price } = SocketContext
    const AuthContext = useContext(authContext)
    const AssetBidDetailContext = useContext(assetBidDetailContext)
    const AssetAuctionContext = useContext(assetAuctionContext)
    // const FiatContext = useContext(fiatContext)
    const TxnContext = useContext(txnContext)
    const AssetContext = useContext(assetContext)
    const [loading, setLoading] = useState(false)
    const [loadingBtn, setLoadingBtn] = useState(false)
    const toastRefId = useRef(null)

    const {
        handleBtnSyncingAuctionBid,
        // handleBtnSyncingMakeOffer,
        handleBtnSyncingBuy,
    } = useHandleSyncingData(
        getUserBidBlockchainListed,
        getBuyBlockchainListed,
        setShowBidSucces,
    )
    
    // const handleOwnerAllowFiatBtnOnclick = ()=>{
    //     setAsset(data)
    //     setModalPrice(true)
    //     settypeTransaction(TYPE_TRANSACTION.ACTIVATE_FIAT)
    
    // }
    const popupContinuePurchase = (navigateFunc) => {
        Swal.fire({
            title:
                "Terdapat transaksi yang belum selesai sebelumnya.",
            icon: "info",
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Lanjutkan",
        }).then(async (result) => {
            if (result.isConfirmed) {
                await navigateFunc()
            }
        });
    }

    const handleToAccount = useCallback((isFiat) =>  navigate(`/history-txn/pending#${isFiat ? 'fiat' : 'crypto'}`), [navigate])

    // const handleButtonInvoiceContinueClick = () =>{
    //     if(disableBuy.status === INVOICE_PAID && AuthContext?.auth?.user?.id === disableBuy?.accountId){
    //       navigate('/setting/success-purchase')
    //     }else if (disableBuy.status === INVOICE_UNPAID && AuthContext?.auth?.user?.id === disableBuy?.accountId){
    //       navigate('/setting/active-purchase#fiat')
    //     }
    //   }

    // const functionFetchInvoice = async () => {
    //     /* const resUnpaidInvoices = await FiatContext?.allInvoice({ first: 1, status: INVOICE_UNPAID, assetId: row?.assetId, type: INVOICE_SETTLE_AUCTION })
    //     const resInvoices = await FiatContext?.allInvoice({ first: 1, status: INVOICE_PAID, assetId: row?.assetId, type: INVOICE_SETTLE_AUCTION, accountId: AuthContext?.auth?.user?.id })
    //     const { typeSourceId, type } = resInvoices?.nodes?.[0] || {}
    //     const assetAuctionsCheck = await AssetAuctionContext?.get(typeSourceId)
    //     const isComplete = await checkInvoiceAssetComplete({ invoice: resInvoices?.nodes?.[0], asset: row?.assetByAssetId, type, assetAuctionsCheck })
    //     console.log('zap invoice', isComplete, resInvoices);
    //     if (resUnpaidInvoices?.nodes?.[0]) {
    //         popupContinuePurchase(() => handleNavigateToPaymentSetting(resUnpaidInvoices?.nodes?.[0]))
    //     } else if (!isComplete) {
    //         if (resInvoices?.nodes?.[0]?.accountId === AuthContext?.auth?.user?.id) {
    //             popupContinuePurchase(() => handleNavigateToPaymentSetting(resInvoices?.nodes?.[0]))
    //         }
    //     } else {
    //     } */
    // }
    const handleBuyButtonOnclick = async (nft) => {
        if (!AuthContext.session) {
            AuthContext.setConnWallet(true)
        } else {
            setLoading(true)
            const isListed = await isBuyBlockchainListed(nft)
            
            const txnData = await TxnContext?.getTxn({
                assetId: nft?.id,
                status: TXN_STATUS_PENDING,
                accountId: AuthContext?.auth?.user?.id,
                type: TXN_TYPES_BUY,
            })
            if (txnData?.nodes?.length !== 0) {
                setLoading(false)
                popupContinuePurchase(() => handleToAccount(txnData?.nodes?.[0]?.isFiat))
            } else if (isListed) {
                handleBtnSyncingBuy(nft)

                toast.info('Data Tersinkronisasi', {
                    autoClose: 5000,
                    closeOnClick: true,
                });
                setLoading(false)
            } else {
                const res = await AssetBidDetailContext.isBidderHasBid({ assetId: nft?.id, bidderAccount: AuthContext?.auth?.user?.id, sellerAccount: nft?.ownerId })
                if (res?.length === 0) {
                    toastRefId.current = toast.loading("Please wait ... checking invoices")
                    const asset = await AssetContext.fetchAssetById(nft?.id)
                    if (nft?.tokenStandardType === ERC721) {
                        const checkOnClickERC721 = checkERC721(asset)
                        if (!loading) {
                            console.log("zap masuk checking checkOnClick721", checkOnClickERC721)
                            if (checkOnClickERC721) {
                                const timeout = setTimeout(() => {
                                    clearTimeout(timeout)
                                    setLoading(false)
                                    // toast.error("There are pending invoice")
                                    toast.update(toastRefId.current, { hideProgressBar: true, render: "There are pending invoices", type: "error", isLoading: false, autoClose: 2000, closeOnClick: true });
                                    console.log("zap toastId", toastRefId.current)
                                }, 1000)
                            } else {
                                const timeout = setTimeout(async () => {
                                    clearTimeout(timeout)
                                    toast.update(toastRefId.current, { hideProgressBar: true, render: "No pending invoice", type: "success", isLoading: false, autoClose: 2000, closeOnClick: true });
                                    console.log("zap toastId", toastRefId.current)
                                    const isListedMarketplace = await isAssetBlockchainListed(nft)
                                    setLoading(false)
                                    if (!isListedMarketplace) {
                                        toast.info("Asset ini baru saja dibeli oleh orang lain")
                                        await navigate(ASSET_PATHNAME + '/' + nft?.id, {
                                            state: { refresh: new Date() }
                                        })
                                    } else {
                                        console.log("zap hey im here")
                                        await setAsset(nft)
                                        await settypeTransaction(TYPE_TRANSACTION.BUY)
                                        if (nft?.isOwnerAllowedFiatTransaction) {
                                            // if (nft?.tokenStandardType === ERC721 && nft?.publishedPrice * matic_price > MAXIMUM_PAYMENT_LIMIT) {
                                            //     await setShowModalVerifiedCheckout(true)
                                            // } else {
                                            await setShowPickPayment(true)
                                            // }
                                        } else {
                                            await setShowModalVerifiedCheckout(true)
                                        }
                                    }
                                }, 1000)
                            }
                        }
                    } else if (nft?.tokenStandardType === ERC1155) {
                        const checkOnClickERC1155 = await checkERC1155(asset)
                        if (!loading) {
                            console.log("zap masuk checking checkOnClick1155", checkOnClickERC1155)
                            setLoading(true)
                            if (checkOnClickERC1155) {
                                const timeout = setTimeout(() => {
                                    clearTimeout(timeout)
                                    setLoading(false)
                                    toast.update(toastRefId.current, { hideProgressBar: true, render: "There are pending invoices", type: "error", isLoading: false, autoClose: 2000, closeOnClick: true });
                                    console.log("zap toastId", toastRefId.current)
                                }, 1000)
                            } else {
                                const timeout = setTimeout(async () => {
                                    clearTimeout(timeout)
                                    setLoading(false)
                                    toast.update(toastRefId.current, { hideProgressBar: true, render: "No pending invoice", type: "success", isLoading: false, autoClose: 2000, closeOnClick: true });
                                    console.log("zap toastId", toastRefId.current)
                                    await setAsset(nft)
                                    await settypeTransaction(TYPE_TRANSACTION.BUY)
                                    // disable fiat payment
                                    if (env.ALLOW_FIAT_PAYMENT && nft?.isOwnerAllowedFiatTransaction) {
                                        await setShowPickPayment(true)
                                    } else {
                                        await setShowModalVerifiedCheckout(true)
                                    }
                                }, 1000)
                            }
                        }
                    }
                } else {
                    setLoading(false)
                    toast.info('Anda sudah melakukan penawaran di aset ini, silahkan tunggu persetujuan dari penjual atau batalkan penawaran.',{ style: { width: "500px", right: "15em" }, autoClose:7000 })
                    /* eslint-disable */
                    throw 'Anda sudah melakukan penawaran di aset ini, silahkan tunggu persetujuan dari penjual atau batalkan penawaran.'
                }

            }
        }
    }

    const handleMakeofferButtonOnclick = async (nft) => {
        if (!AuthContext?.session) {
            AuthContext.setConnWallet(true)
        } else {
            setLoadingBtn(true)
            
            const txnData = await TxnContext?.getTxn({
                assetId: nft?.id,
                status: TXN_STATUS_PENDING,
                accountId: AuthContext?.auth?.user?.id,
                type: TXN_TYPES_MAKE_OFFER,
            })
            if (txnData?.nodes?.length !== 0) {
                setLoadingBtn(false)
                popupContinuePurchase(() => handleToAccount(txnData?.nodes?.[0]?.isFiat))
            }else {
                const res = await AssetBidDetailContext.isBidderHasBid({ assetId: nft?.id, bidderAccount: AuthContext?.auth?.user?.id, sellerAccount: nft?.ownerId })
                if (res?.length === 0) {
                    setAsset(nft);
                    setAssetBid(res?.[0]);
                    settypeTransaction(TYPE_TRANSACTION.MAKE_OFFER);
                    setModalPrice(true);
                    setLoadingBtn(false)
                } else {
                    setLoadingBtn(false)
                    toast.info('Penawaran anda sebelumnya masih diproses.')
                    /* eslint-disable */
                    throw 'Penawaran anda sebelumnya masih diproses.'
                }
            }
        }
    }

    const handleBidButtonOnclick = async (nft) => {
        if (!AuthContext.session) {
            AuthContext.setConnWallet(true)
        } else {
            setLoadingBtn(true)
            const resAuction = await AssetAuctionContext.getAuctionByAssetId(nft?.id);
            const { auctionContractId } = nft.assetsAuctionsByAssetId?.nodes?.[0]
            const auctionListed = await getAuctionBlockchainListed(auctionContractId)
            const bidderUnlisted = await isBidderAuctionBlockchainUnlisted(auctionContractId)

            const isUserHighestAuctionBidder = resAuction?.[0]?.assetsAuctionDetailsByAssetAuctionId?.nodes?.[0]?.bidderAccount === AuthContext?.auth?.user?.id
            const isBtnContinueAuctionBid = auctionListed?.bidder === AuthContext?.auth?.user?.address

            const txnData = await TxnContext?.getTxn({
                assetId: nft?.id,
                status: TXN_STATUS_PENDING,
                accountId: AuthContext?.auth?.user?.id,
                type: TXN_TYPES_BID_AUCTION,
            })
            if (txnData?.nodes?.length !== 0) {
                setLoadingBtn(false)
                popupContinuePurchase(() => handleToAccount(txnData?.nodes?.[0]?.isFiat))
            } else if (isBtnContinueAuctionBid) {
                if (!isUserHighestAuctionBidder) {
                    await handleBtnSyncingAuctionBid(nft, auctionListed)

                    toast.info('Data Tersinkronisasi', {
                        autoClose: 5000,
                        closeOnClick: true,
                    });
                }
                else{          
                    toast.info('Anda masih merupakan penawar tertinggi', {
                      autoClose: 5000,
                      closeOnClick: true,
                    });
                  }
                setLoadingBtn(false)
            } else if (isUserHighestAuctionBidder) {
                if (bidderUnlisted) {
                    await handleBtnSyncingCancelBidderAuction(resAuction?.filter(
                        (auction) => !auction?.isClosed
                    )?.[0])

                    toast.info('Data Tersinkronisasi', {
                        autoClose: 5000,
                        closeOnClick: true,
                    });
                } else {
                    setAssetBid(
                        AssetAuctionContext?.assetAuctionsByAsset?.filter(
                            (auction) => !auction?.isClosed
                        )?.[0]
                    );
                    setAsset(AssetContext?.asset);
                    settypeTransaction(TYPE_TRANSACTION.CANCEL_BID_AUCTION);
                    setCancelTitleModal("Apakah anda yakin untuk membatalkan Penawaran Lelang ?")
                    setShowCancelListing(true);
                }
                setLoadingBtn(false)
            } else {
                settypeTransaction(TYPE_TRANSACTION.BID)
                setAsset(nft)
                setModalPrice(true)
                setLoadingBtn(false)
            }
        }
    }

    const showBidFooterCard = (nft) =>
        <RoundedButton onClick={()=>handleBidButtonOnclick(nft)}
            disabled={nft?.ownerId === AuthContext?.auth?.user?.id}
            color={nft?.ownerId === AuthContext?.auth?.user?.id ? "bg-gray-500" : "bg-hijau_hutan"}
            // className={`col-start-2 col-end-4 py-2`}><ButtonText>Buat Penawaran</ButtonText></RoundedButton>
            className={`col-start-1 col-end-3 py-3`}>{loadingBtn ? <ButtonText classstyle="text-sm">Loading ... </ButtonText> : <ButtonText classstyle="text-sm">Ikuti Lelang</ButtonText>} </RoundedButton>

    const showListedFooterCard = (nft) =>

        <RoundedButton onClick={() => handleBuyButtonOnclick(nft)}
            disabled={nft?.ownerId === AuthContext?.auth?.user?.id}
            color={nft?.ownerId === AuthContext?.auth?.user?.id ? "bg-gray-500" : "bg-hijau_hutan"}
            // className="col-start-2 col-end-4 py-2"><ButtonText>Beli</ButtonText></RoundedButton>
            className="col-start-1 col-end-3 py-3">{loading ? <ButtonText classstyle="text-sm">Loading ... </ButtonText> : <ButtonText classstyle="text-sm">Beli</ButtonText>}</RoundedButton>
    const showOnlyMintedFooterCard = (nft) =>
        // assetBidDetail?.length === 0 ?
        (<RoundedButton onClick={()=>handleMakeofferButtonOnclick(nft)}
            disabled={nft?.ownerId === AuthContext?.auth?.user?.id}
            color={nft?.ownerId === AuthContext?.auth?.user?.id ? "bg-gray-500" : "bg-hijau_hutan"}
            // className="col-start-2 col-end-4 py-2"><ButtonText>Penawaran Lelang</ButtonText></RoundedButton>
            className="col-start-1 col-end-3 py-3">{loadingBtn ? <ButtonText classstyle="text-sm">Loading ... </ButtonText> :<ButtonText classstyle="text-sm">Buat Penawaran</ButtonText>}</RoundedButton>) /* :
            (<RoundedButton
            className="col-start-1 col-end-3 py-3 border-red-200 border-2"
            color="bg-white"
            onClick={async () => {
              if (!AuthContext?.session) {
                AuthContext?.setConnWallet(true)
              } else {
                await setCancelTitleModal(
                  "Apakah anda yakin untuk membatalkan penawaran ini?"
                );
                setAsset(nft);
                setAssetBid(assetBidDetail?.[0]);
                settypeTransaction(TYPE_TRANSACTION.CANCEL_MAKE_OFFER);
                setShowCancelListing(true);
              }
            }}
          >
            <ButtonText
              classstyle="text-sm"
              text="Batalkan Penawaran"
              color="tx-red-400"
            />
          </RoundedButton>) */

    return (
        <>  
            <div className="flex justify-between">
                {!isAnotherAsset && <div onClick={() => collectionData?.id && navigate(`/collection/${collectionData?.id}`)} className="cursor-pointer">
                    <div className="flex">
                        <p className={`font-quicksand lg:text-xs fhd:text-sm mr-2 ${collectionData?.name ? "text-oranye font-semibold" : "text-yellow-500 font-regular"} line-clamp-1`}>{collectionData?.name ? collectionData?.name : "Belum masuk koleksi"}</p>
                        {collectionData?.isVerified && <VerifiedLogo />}
                    </div>
                </div>}

                <NumberFormat value={ data?.remainingAmount} displayType={'text'} thousandSeparator={true}
                         renderText={(value, props) => <div className={`flex-col flex items-end border-yellow-500`}>
                        <p className="lg:text-base font-bold font-quicksand bg-space-nowrap text-hitam mb-2">{data?.tokenStandardType === 1 ? "1/1" : `1/${data?.amount !== null ? data?.amount : data?.remainingAmount}`}</p>
                 </div>}/>
            </div>
            <div className="grid grid-cols-12 mb-2">
                <div className="col-span-10">
                  
                    {!isAnotherAsset && <div className="flex flex-row justify-between w-full">
                            <p className='text-hitam text-base font-quicksand font-bold line-clamp-1'>{data?.name === "" ? "Tidak ada nama" : data?.name}</p>
                    </div>}
                </div>
            </div>
            <div className="grid grid-cols-2 w-full">
                {
        <RoundedButton onClick={() => navigate(`/asset/${idUtility}`)}
            disabled={data?.ownerId === AuthContext?.auth?.user?.id}
            color={data?.ownerId === AuthContext?.auth?.user?.id ? "bg-gray-500" : "bg-hijau_hutan"}
            // className="col-start-2 col-end-4 py-2"><ButtonText>Beli</ButtonText></RoundedButton>
            className="col-start-1 col-end-3 py-3">{loading ? <ButtonText classstyle="text-sm">Loading ... </ButtonText> : <ButtonText classstyle="text-sm">{`Lihat ${data?.utilitiesType ===UTIL_CODE_TYPE ?'Kode' : data?.utilitiesType === UTIL_TICKET_TYPE ?'Tiket':'Membership'}`}</ButtonText>}</RoundedButton>}
                {/* <RoundedButton onClick={() => navigate(`/asset/${nft?.id}`)} className={`border-hijau_hutan border-2 py-2
                                             ${AuthContext?.auth?.user?.id === nft?.ownerId && 'col-start-3 col-end-4 w-24'}`} color="transparent"><ButtonText color="hijau_hutan">Lihat</ButtonText></RoundedButton> */}
            </div>
            {/* <Modal backdrop={false} show={loading} >
            <div className="flex w-full h-screen justify-center items-center">
                <SpinCircleLogo black={"true"} type="big" />
            </div>
            </Modal> */}
            <ModalWaiting 
                invoiceUrl={null}
                loading={loading}
                show={loading}
                title={"Mohon Tunggu"}
                text={"Aset kamu sedang dipersiapkan."}
                backdrop={false}
                textButton="Sedang Dipersiapkan"
                showButton={false}
            />
        </>
    )
}

export default FooterCardAssetInfo