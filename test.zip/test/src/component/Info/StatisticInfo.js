import React, { useContext, useEffect } from "react";
import assetActivitiesContext from "../../context/AssetActivities/assetActivitiesContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import Expandable from "../Expandable/Expandable";
import MostTransactionList from "../List/MostTransactionList";

const StatisticInfo = ({ className, ...props }) => {
    const AssetActivitiesContext = useContext(assetActivitiesContext)
    const Responsive = useContext(ResponsiveContext)
    useEffect(() => {
        AssetActivitiesContext?.topSeller()
        AssetActivitiesContext?.topBuyer()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <div {...props} className={className}>
            {!Responsive && <p className="font-bold text-2xl font-quicksand mb-6">Statistik</p>}
            <Expandable className={"mb-8"} initialExpand={true} label={"Pembeli Terbanyak"}>
                <MostTransactionList data={AssetActivitiesContext?.topBuyers} />
            </Expandable>
            <Expandable initialExpand={true} label={"Penjual Terbanyak"}>
                <MostTransactionList data={AssetActivitiesContext?.topSellers} />
            </Expandable>
        </div>
    )
}

export default StatisticInfo