import React, { useContext, useEffect, useRef, useState } from "react";
import { MaticTokenIcon, RpIcon, UserImage } from "../../assets";
import VerifiedLogo from "../../assets/logo/verified_logo";
import accountContext from "../../context/Account/accountContext";
import socketContext from "../../context/Socket/socketContext";
// import env from "../../config/env";
import InfoText from "../Text/InfoText";
import collectionContext from "../../context/Collection/collectionContext";
// import FooterBiddingCard from "../Card/FooterBiddingCard";
import { AUCTION } from "../../utils/constants/listedType";
import CardBidding from "../Card/CardBidding";
import { useNavigate } from "react-router-dom";
import NumberFormat from "react-number-format";
import { ERC1155 } from "../../utils/constants/contractType";
// import SquareAmountIcon from "../../assets/icon/square_amount_icon";
// import InfoIcon from "../../assets/icon/info_icon";
import Badges from "../Badges/Badges";
import { renderUserLabel } from "../../utils/helper";
import { isFuture } from "date-fns";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import ShareLinkWidget from "../Widget/ShareLinkWidget";
import SeenWidget from "../Widget/SeenWidget";
import CopyIcon from "../../assets/icon/copy_icon";
import { toast } from "react-toastify";
import authContext from "../../context/Auth/authContext";
import InfoIcon from "../../assets/icon/info_icon";

// const INITIAL_AMOUNT = 1
// const { USER_ADDRESS_SCANNER } = env
const AssetInfoDetail = (props) => {
    const navigate = useNavigate()
    const { nft } = props
    const SocketContext = useContext(socketContext)
    const AccountContext = useContext(accountContext)
    const CollectionContext = useContext(collectionContext)
    const AuthContext = useContext(authContext)
    const [showInfoToken, setInfoToken] = useState(false)
    const { matic_price } = SocketContext
    const ownerAsset = AccountContext?.accounts?.find(account => account.id === nft?.ownerId)
    const creatorAsset = AccountContext?.accounts?.find(account => account.id === nft?.creatorId)
    const ref = useRef()
    const copyAddress = async (text) => {
        await navigator.clipboard.writeText(text);
        toast('Alamat berhasil disalin', {
            position: "bottom-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
      }
    const handleClickInfoToken = (e) => {
        setInfoToken(!showInfoToken)
        e.stopPropagation();
    }

    useEffect(() => {
        const handleClickOutside = (event) => {
          if (!ref?.current?.contains(event.target)) {
              setInfoToken(false)
          }
        };
        document.addEventListener("mousedown", handleClickOutside);
      // eslint-disable-next-line react-hooks/exhaustive-deps
      }, [ref]);

    return (
        <div className="flex-col w-full">
            <div className="flex flex-row justify-between w-full mb-3">
                <div className="flex flex-col ">
                    <div className="inline-flex items-center text-2xl font-quicksand text-hijau_tua mb-5">
                        <p onClick={() => navigate(`/collection/${nft?.collectionId}`)} className="cursor-pointer font-quicksand font-bold text-lg text-hijau_hutan mr-2">{CollectionContext?.collections?.find(collection => collection.id === nft.collectionId)?.name}</p>
                        {CollectionContext?.collections?.find(collection => collection.id === nft.collectionId)?.isVerified &&
                            <VerifiedLogo />
                        }
                    </div>
                    <p className="text-hitam_2 font-quicksand mb-4 lg:text-3xl fhd:text-4xl font-bold">{nft?.name}</p>
                    <div className="inline-flex items-center">
                        <div className="border-r-2 border-gray-300 inline-flex pr-8 mr-8 items-center">
                            <img alt="profile creator" src={!!creatorAsset?.profilePictureUrl ? creatorAsset?.profilePictureUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} className="lg:h-8 lg:w-8 fhd:h-10 fhd:w-10 rounded-full  mr-3  whitespace-pre-line" />
                            <InfoText onClick={() => { navigate(`/account/${creatorAsset?.id}`) }} className={" mr-2"} label="Pembuat"
                                value={renderUserLabel(creatorAsset?.userName, creatorAsset?.address)}
                            />
                            <CopyIcon size={5} className="ml-2 cursor-pointer" onClick={() => copyAddress(creatorAsset?.address)}/>
                        </div>
                        <div className="flex items-center">
                            <img alt="profile owner" src={!!ownerAsset?.profilePictureUrl ? ownerAsset?.profilePictureUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} className="lg:h-8 lg:w-8 fhd:h-10 fhd:w-10 rounded-full mr-3 " />
                            <InfoText onClick={() => navigate(`/account/${ownerAsset?.id}`)} className=" " label="Pemilik"
                                value={renderUserLabel(ownerAsset?.userName, ownerAsset?.address)} />
                            <CopyIcon size={5} className="ml-4 cursor-pointer" onClick={() => copyAddress(ownerAsset?.address)}/>
                        </div>
                    </div>
                    {/* <div className="grid grid-cols-9 gap-2 justify-center items-center mb-4 w-full">
                        <img src={creatorAsset?.profilePictureUrl ?? UserImage2} className="h-10 w-10 rounded-full col-start-1 col-end-2  whitespace-pre-line" />
                        <div className="col-start-2 col-end-6 inline-flex items-center">

                            <InfoText onClick={() => { navigate(`/account/${creatorAsset?.id}`) }} className={" mr-2"} label="Pembuat"
                                value={`${creatorAsset?.userName ?? creatorAsset?.address?.substring(0, 5)}...${creatorAsset?.address?.substring(creatorAsset?.address?.length - 4, creatorAsset?.address?.length)}`}

                            />
                            <hr className="border-dashed border-gray-300 w-full" />
                        </div>
                        <img src={ownerAsset?.profilePictureUrl ?? UserImage3} className="h-10 w-10 rounded-full col-start-6 col-end-7" />
                        <InfoText onClick={() => navigate(`/account/${ownerAsset?.id}`)} className="col-start-7 col-end-10" label="Pemilik"
                            value={`${ownerAsset?.userName ?? ownerAsset?.address?.substring(0, 5)}...${ownerAsset?.address?.substring(ownerAsset?.address?.length - 4, creatorAsset?.address?.length)}`}
                        />
                    </div> */}
                </div>
                <div className="flex flex-col items-end">

                    {nft?.listedType === AUCTION && nft?.isListed && isFuture(new Date(nft?.listedExpirationDate)) &&
                        <CardBidding className="mb-5" expDate={nft?.listedExpirationDate} />
                    }
                    <div className="flex flex-col items-end w-full mb-6">
                        <ShareLinkWidget />
                    </div>
                    <div className="flex flex-col items-end justify-center w-full mb-12">
                        <SeenWidget />
                        <div className="col-span-2 mt-4">
                            {AuthContext?.auth?.user?.id !== nft?.ownerId && nft?.isListed !== false && nft?.listedType !== AUCTION &&   
                            <div  ref={ref} className="flex gap-x-2 justify-end relative items-center">
                                <img src={MaticTokenIcon} className="self-end w-5 h-5" alt="matic token"/>
                                {nft?.isOwnerAllowedFiatTransaction && <img src={RpIcon} className="self-end w-5 h-5" alt="iconRP"/>}
                                <div onClick={(e) => handleClickInfoToken(e)} className='cursor-pointer'>
                                    <InfoIcon className="self-center mr-2" color={"#4AA82D"} />
                                </div>
                                <div className={`bg-white py-2 px-4 rounded-lg shadow-md absolute w-64 top-6 right-4 ${!showInfoToken && 'hidden'}`}>
                                    <p className="font-quicksand text-sm">{nft?.isOwnerAllowedFiatTransaction ? 'Aset ini dapat dibeli dengan rupiah dan matic' : 'Aset ini hanya dapat dibeli dengan matic'}</p>
                                </div>
                            </div>}
                        </div>
                    </div>
                    
                
                </div>
            </div>

            <p className="font-quicksand mb-8 tracking-wider lg:text-base fhd:text-lg font-medium text-hitam_2">{nft?.description}</p>

            {/* Ini Section harga dan seial */}
            <div className="flex w-full justify-between">
                <div>
                    <p className={`font-quicksand text-lg text-hitam_2 mb-2`}>Harga</p>
               
                    {nft?.publishedPrice !== 0 ? <NumberFormat value={Math.ceil(parseFloat(nft?.publishedPrice) * matic_price)} displayType={'text'} thousandSeparator={true}
                        renderText={(value, props) => 
                        <div className="flex-row flex items-center">
                            <div className="flex">
                                <img src={MaticTokenIcon} className={`self-center w-4 h-4 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`} alt="matic"/>
                                <p className={`font-quicksand font-semibold lg:text-lg fhd:text-2xl text-hitam_2 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`}>{nft?.publishedPrice}</p>
                            </div>
                            <p className={`font-quicksand font-semibold text-base text-abu_86 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`}> atau </p>
                            <p className={`font-quicksand font-semibold lg:text-lg fhd:text-2xl text-hitam_2 ${nft?.publishedPrice === 0 && "invisible"}`}> IDR {value} </p>
                        </div>
                        }
                    /> : <p className="font-quicksand font-semibold text-2xl text-hitam_2"> Pemilik belum pasang harga </p>
                    }
                </div>
                <div>
                {nft?.tokenStandardType === ERC1155 &&
                    <div className="justify-end items-end">
                        <p className={`font-quicksand text-right text-lg text-hitam_2 mb-2`}>Jumlah serial yang dimiliki</p>
                            <div className="flex justify-end">
                            <NumberFormat value={nft?.remainingAmount} displayType={'text'} thousandSeparator={true}
                                renderText={(value, props) => 
                                <div className="flex-row flex items-center border-gray-300">    
                                    {/* <SquareAmountIcon className="mr-2" /> */}
                                    <p className="font-quicksand font-semibold lg:text-lg fhd:text-2xl text-oranye">{value}</p>
                                </div>
                                }
                            />
                            <NumberFormat value={nft?.amount} displayType={'text'} thousandSeparator={true}
                                renderText={(value, props) => 
                                <div className="flex-row flex items-center border-gray-300">    
                                    <p className="font-quicksand font-semibold lg:text-lg fhd:text-2xl ml-2 text-oranye">/ {value}</p>
                                </div>
                                }
                            />
                            </div>
                    </div>
                    }
                </div>
            </div>
            {/* {nft?.publishedPrice === 0 && (<p className="font-quicksand font-semibold text-2xl text-hitam_2"> Pemilik belum pasang harga </p>)} */}
            <Badges 
                style={{ width: 'fit-content' }}
                fontSize="lg:text-sm 2xl:text-base fhd:text-lg"
                margin="items-center"
                className="mt-2 py-2 px-4"
            //     icon={
            //     <InfoIcon className="mr-2" />
            // }
                value={`Royalti ${nft?.royalti ?? 0} % untuk pembuat aset`}
            />
            {/*   <div className="flex-row flex items-center">
                <img src={MaticTokenIcon} className="self-center w-4 h-4 mr-2" />
                <p className="font-quicksand text-xl text-hitam_2 font-bold">{nft?.publishedPrice ?? 0} ( IDR {nft.publishedPrice * matic_price} )</p>
            </div> */}
        </div>
    )
}

export default AssetInfoDetail