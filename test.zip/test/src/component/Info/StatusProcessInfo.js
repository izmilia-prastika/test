import React from "react";
import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import SuccessIcon from "../../assets/icon/success_icon";
import FailIcon from "../../assets/icon/fail_icon";

const StatusProcessInfo = ({ label, status, ...props }) => {
    return (
        <>
        <div {...props} className="rounded-full md:py-4 py-3 px-6 w-full bg-gray-100 grid grid-cols-12 items-center">
            {
                status === "success" ?
                <div className="mr-3 -ml-2">
                        <SuccessIcon color={'#4AA82D'}/>
                    </div>
                    :
                    status === "process" ?
                    <div className="mr-0.5">
                        <SpinCircleLogo yellow={true}/>
                    </div>
                        :
                    status === "fail" ?
                    <div className="mr-3 -ml-1.5">
                        <FailIcon color={"#B92525"}/>
                    </div>
                    :
                    <div className="w-4 h-4" />
            }
            <p className="col-start-2 col-end-13 font-quicksand md:text-lg text-base text-red text-hitam_2 font-medium">{label}</p>
        </div>
           
        </>
    )
}

export default StatusProcessInfo