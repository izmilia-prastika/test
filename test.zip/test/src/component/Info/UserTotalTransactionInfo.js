import React, { useContext } from "react";
import NumberFormat from "react-number-format";
import { useNavigate } from "react-router-dom";
import { MaticTokenIcon, UserImage } from "../../assets";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import socketContext from "../../context/Socket/socketContext";
import { renderUserLabel } from "../../utils/helper";
import classNames from "classnames";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";

const UserTotalTransactionInfo = ({ data, ...props }) => {
    const { accountByAccountId, total } = data || {}
    const SocketContext = useContext(socketContext)
    const Responsive = useContext(ResponsiveContext)
    const { matic_price } = SocketContext
    const navigate = useNavigate()
    const containerClass = classNames("flex flex-row", { "border-b pb-5": Responsive })
    return (
        <div className={containerClass} {...props}>
            <img alt="profile account" onClick={() => navigate(`/account/${accountByAccountId?.id}`)} src={!!accountByAccountId?.profilePictureUrl ? accountByAccountId?.profilePictureUrl + SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} className="cursor-pointer md:h-14 md:w-14 h-11 w-11 md:rounded-2xl rounded-xl mr-4" />
            <div className="flex flex-col">

                <p onClick={() => navigate(`/account/${accountByAccountId?.id}`)} className="cursor-pointer font-medium md:text-base text-sm font-quicksand md:mb-0 mb-1 text-british_green_racing">{renderUserLabel(accountByAccountId?.userName, accountByAccountId?.address)}</p>
                <div className="flex flex-row items-center">

                    <img alt="matic token" src={MaticTokenIcon} className="mr-2 w-4 h-4" />
                    <NumberFormat displayType="text" thousandSeparator={true} decimalScale={2} value={total} renderText={(value) =>
                        <p className="mr-2 font-medium md:text-base text-sm font-quicksand">{value}</p>
                    } />
                    <NumberFormat displayType="text" thousandSeparator={true} decimalScale={0} value={total * matic_price} renderText={(value) =>
                        <p className="font-medium md:text-base text-sm font-quicksand line-clamp-1">(IDR {value})</p>
                    } />
                </div>
            </div>
        </div>
    )
}

export default UserTotalTransactionInfo