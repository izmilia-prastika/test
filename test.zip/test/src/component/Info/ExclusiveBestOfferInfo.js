import React from "react";

const ExclusiveBestOfferInfo = ({ className, img, title, content, width = "auto" }) => {
    return (
        <div className={className} style={{ width: width }}>
            <div className="h-56 w-56 bg-gray-white overflow-hidden object-cover">
                <img alt="best offer" src={img} className="object-cover"/>
            </div>
            <p className="md:font-bold font-semibold font-quicksand md:text-xl text-sm mt-5 md:mb-4 mb-2 text-center px-8">{title}</p>
            <p className="font-normal font-quicksand md:text-lg text-sm  text-center">{content}</p>
        </div>
    )
}

export default ExclusiveBestOfferInfo