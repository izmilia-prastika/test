import React, { useContext, useEffect } from "react";
import { BankImg } from "../../assets";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import CCardIcon from "../../assets/icon/ccard_icon";
// import ChecklistIcon from "../../assets/icon/checklist_icon";
// import PencilIcon from "../../assets/icon/edit_pencil_icon"
import PersonIcon from "../../assets/icon/person_icon";
// import accountsBankContext from "../../context/AccounsBank/accountsBankContext";
// import authContext from "../../context/Auth/authContext";
import bankContext from "../../context/Bank/bankContext";
// import Button from "../Button/Button";
// import ButtonLink from "../Button/ButtonLink";
// import ButtonText from "../Text/ButtonText";

const AccountBanksInfo = ({
    setShowModalDelete,
    setIdDeleted,
    handleEdit,
    data,
    loading,
    ...props
}) => {
    const { accountNumber, bankName, holderName } = data
    const BankContext = useContext(bankContext)
    useEffect(() => {
        if (data?.accountNumber !== "") {
            BankContext?.getAll()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data])
    // const selectedBank = BankContext.banks?.filter(el => el.code === bankName)
    // const AccountsBankContext = useContext(accountsBankContext)
    // const AuthContext = useContext(authContext)

    // const handleActivate = async () => {
    //     await AccountsBankContext?.activateBank(AuthContext?.auth?.user?.id, bankByBankId?.id)
    //     await AccountsBankContext?.getById(AuthContext?.auth?.user?.id)
    // }

    // const handleDelete = () => {
    //     setIdDeleted(id)
    //     setShowModalDelete(true)
    // }
    return (
        <div {...props} className="flex flex-row justify-between w-full">
           <div className="flex flex-col">
                <img src={BankImg} className="w-8 h-8 mb-3" alt=""/>
                <p className="mb-4 font-semibold font-quicksand">{bankName}</p>
                <div className="flex flex-row -mb-2">
                    <CCardIcon />
                    <p className="pr-2 border-r-2 border-abu_ea ml-2 mr-2 font-quicksand font-semibold text-hitam_2">{accountNumber}</p>
                    <PersonIcon />
                    <p className="pr-2  ml-2 mr-2 font-quicksand font-semibold text-hitam_2">{holderName}</p>
                </div>
            </div>
                {/* <div className="flex flex-row">
                        <div className="flex cursor-pointer" onClick={handleEdit}>
                            <PencilIcon />
                            <p className="font-quicksand ml-2 text-hijau_hutan">Edit Rekening Bank</p>
                        </div>
                </div> */}
        </div>
    )
}

export default AccountBanksInfo