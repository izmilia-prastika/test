import classNames from "classnames";
import React from "react";

const ModalInfo = ({ label, value, labelStyle, valueStyle, rightContent, leftContent }) => {
    return (
        <div className="border-b-2 w-full md:px-10 md:py-4 py-2 border-gray-100 flex flex-row items-center justify-between">
            {leftContent ??
                <p className={`font-quicksand font-normal  ${classNames({
                    'text-hitam_2 text-sm': !labelStyle.includes("text")
                })} ${labelStyle}`}>{label}</p>
            }
            {rightContent ??
                <p className={`font-quicksand font-normal  ${classNames({
                    'text-sm text-red-500': !valueStyle.includes("text")
                })} ${valueStyle}`}>{value}</p>
            }
        </div>
    )
}

export default ModalInfo