import React, { useContext } from "react";
import { MaticTokenIcon, UserImage } from "../../assets";
import VerifiedLogo from "../../assets/logo/verified_logo";
import accountContext from "../../context/Account/accountContext";
import socketContext from "../../context/Socket/socketContext";
// import env from "../../config/env";
import InfoText from "../Text/InfoText";
import collectionContext from "../../context/Collection/collectionContext";
// import assetContext from "../../context/Asset/assetContext";
// import FooterBiddingCard from "../Card/FooterBiddingCard";
import { AUCTION } from "../../utils/constants/listedType";
import CardBidding from "../Card/CardBidding";
import { useNavigate } from "react-router-dom";
import NumberFormat from "react-number-format";
import { ERC1155 } from "../../utils/constants/contractType";
import SquareAmountIcon from "../../assets/icon/square_amount_icon";
import { IMAGE_FILE_TYPE, VIDEO_FILE_TYPE } from "../../utils/constants/assetFileType";
import ReactAudioPlayer from "react-audio-player";
import classNames from "classnames";
import { SMALL_THUMBNAIL_IMAGE_TYPE } from "../../utils/constants/renderImgTypes";
import { Player, BigPlayButton } from 'video-react';
import RoundedButton from "../Button/RoundedButton";
import ButtonText from "../Text/ButtonText";
import Badges from "../Badges/Badges";
import InfoIcon from "../../assets/icon/info_icon";

const CardAsset = ({onClick, thumbnailUrl, params, authContext, SeenWidget, nft, responsive}) => {
    const containerContent = classNames("bg-black flex items-center justify-center rounded-t-lg overflow-hidden", {"h-44": nft?.type===IMAGE_FILE_TYPE}, {"h-80" : nft?.type === VIDEO_FILE_TYPE }, {"h-44" : nft?.type !== IMAGE_FILE_TYPE && nft?.type !== VIDEO_FILE_TYPE })
    return (
    <div className="shadow-sm rounded-lg mx-4 border">
        <div className={containerContent}>
            {nft?.type === IMAGE_FILE_TYPE ? 
                <img alt="asset" src={thumbnailUrl+SMALL_THUMBNAIL_IMAGE_TYPE} style={{ maxWidth: "320px", heigth: "180px", maxHeight:"180px", objectFit: "contain",}}/>
                : nft?.type === VIDEO_FILE_TYPE ? 
                        <Player className="object-cover max-h-full max-w-full" fluid={false} height={"100%"} width={"100%"} playsInline preload="metadata" src={thumbnailUrl}>
                            <BigPlayButton position="center" />
                        </Player> : 
                <ReactAudioPlayer src={thumbnailUrl} autoPlay controls/>}
        </div>
          <div className="flex flex-col justify-between">
            <div className="px-3 pt-3">
              <p className="text-hitam_2 font-quicksand text-sm font-bold w-full line-clamp">{nft?.name}</p>
            </div>
            <div className="flex flex-row w-full p-3 rounded-b-lg items-center justify-between">
                <SeenWidget params={params} AuthContext={authContext} responsive={responsive}/>
                <Badges icon={<InfoIcon className="mr-2 self-center" />}
                 value={`Royalti ${nft?.royalti ?? 0} %`}
                />
            </div>
          </div>
            {nft?.type === IMAGE_FILE_TYPE && <div className="flex py-0 px-2 w-full mb-4">
                <RoundedButton onClick={onClick} className="w-full py-3">
                    <ButtonText tx="Lihat Gambar Asli" />
                </RoundedButton>
            </div>}
    </div>
    )
}

const OwnerInfo = ({src, className, onClick, label, value}) => {
    return (
        <div className={`flex`}>
            <img alt="owner" src={src} className="h-8 w-8 rounded-full whitespace-pre-line mr-2"/>
            <InfoText onClick={onClick} className={" mr-2"} label={label} value={value}/>
        </div>
    )
}

const OwnerInfoGroup = ({creatorAsset, ownerAsset}) => {
    const navigate = useNavigate()
    const handleAccount = () => navigate(`/account/${creatorAsset?.id}`)
    const handleOwner = () => navigate(`/account/${ownerAsset?.id}`)
    return (
        <div className="inline-flex mt-6 items-center mx-4">
            <OwnerInfo src={!!creatorAsset?.profilePictureUrl ? creatorAsset?.profilePictureUrl+SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} onClick={handleAccount} label={"Pembeli"} value={`${creatorAsset?.userName ?? creatorAsset?.address?.substring(0, 5)}...${creatorAsset?.address?.substring(creatorAsset?.address?.length - 4, creatorAsset?.address?.length)}`}/>
            <div className="border border-dashed w-6 h-0 mx-4 border-gray-400"></div>
            <OwnerInfo src={!!ownerAsset?.profilePictureUrl ? ownerAsset?.profilePictureUrl+SMALL_THUMBNAIL_IMAGE_TYPE : UserImage} onClick={handleOwner} label={"Pemilik"} value={`${ownerAsset?.userName ?? ownerAsset?.address?.substring(0, 5)}...${ownerAsset?.address?.substring(ownerAsset?.address?.length - 4, creatorAsset?.address?.length)}`}/>
        </div>
    )
}

const FooterPriceActive = ({nft, matic_price, socketAmount}) => {
    return(
        <div className="mx-4">
        <NumberFormat value={Math.ceil(parseFloat(nft?.publishedPrice) * matic_price)} displayType={'text'} thousandSeparator={true}
                renderText={(value, props) => <div className="flex-row flex items-center">
                    {nft?.tokenStandardType === ERC1155 &&
                        <NumberFormat value={nft?.remainingAmount} displayType={'text'} thousandSeparator={true}
                            renderText={(value, props) => <div className="flex-row flex items-center pr-3 mr-3 border-r-2 border-gray-300">
                                <SquareAmountIcon className="mr-2" />
                                <p className="font-quicksand font-semibold text-lg text-hitam_2">{value}</p>
                            </div>
                            }
                        />
                    }
                    <img src={MaticTokenIcon} className={`self-center w-4 h-4 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`} alt="matic"/>
                    <p className={`font-quicksand font-semibold text-lg text-hitam_2 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`}>{nft?.publishedPrice}</p>
                    <p className={`font-quicksand font-semibold text-sm text-abu_86 mr-2 ${nft?.publishedPrice === 0 && "invisible"}`}> atau </p>
                    <p className={`font-quicksand font-semibold text-lg text-hitam_2 ${nft?.publishedPrice === 0 && "invisible"}`}> IDR {value} </p>
                </div>
                }
            />
            {nft?.publishedPrice === 0 && (<p className="font-quicksand font-semibold text-2xl text-hitam_2"> Pemilik belum pasang harga </p>)}
        </div>
        )
}

const AssetInfoDetailMobile = ({
    onClick,
    thumbnailUrl, 
    params, 
    authContext, 
    nft, 
    // disableBuy, 
    // socketDisableBuy, 
    // setDisableBuy, 
    // setSocketDisableBuy,
    // RenderBtn,
    SeenWidget,
    ShareLinkWidget,
    responsive,
    }) => {
    const SocketContext = useContext(socketContext)
    const AccountContext = useContext(accountContext)
    const CollectionContext = useContext(collectionContext)
    const navigate = useNavigate()
    const { matic_price } = SocketContext
    const ownerAsset = AccountContext?.accounts?.find(account => account.id === nft?.ownerId)
    const creatorAsset = AccountContext?.accounts?.find(account => account.id === nft?.creatorId)
    // console.log(nft.collectionId, "TES")
    const handleToCollection = () => {
        navigate(`/collection/${nft?.collectionId}`)
        // console.log("PRESS")
    }
    return (
       <div className="flex flex-col w-full">
           <div className="flex justify-between mb-4 mx-4">
                <div className="inline-flex items-center">
                    <p className="font-quicksand font-bold text-base text-hijau_tua mr-2 break-words" onClick={handleToCollection}>{CollectionContext?.collections?.find(collection => collection.id === nft.collectionId)?.name}</p>
                    {CollectionContext?.collections?.find(collection => collection.id === nft.collectionId)?.isVerified && <VerifiedLogo />}
                </div>
                <ShareLinkWidget />
           </div>
           <CardAsset 
            onClick={onClick} 
            thumbnailUrl={thumbnailUrl} 
            params={params} 
            authContext={authContext} 
            nft={nft} 
            SeenWidget={SeenWidget}
            responsive={responsive}
            />
            <OwnerInfoGroup ownerAsset={ownerAsset} creatorAsset={creatorAsset}/>
            <p className="font-quicksand mb-6 mt-6 mx-4 text-sm text-hitam_2">{nft?.description}</p>
            <div className="border w-full h-0 mb-4 border-gray-100"></div>
            <div className="flex flex-col items-end">
                    {nft?.listedType === AUCTION &&
                        <CardBidding className="mb-5 px-4 pt-3 pb-2" expDate={nft?.listedExpirationDate} />
                    }
            </div>
            {nft?.publishedPrice !== 0 && <FooterPriceActive nft={nft} matic_price={matic_price} />}  
       </div>
    )
}

export default AssetInfoDetailMobile