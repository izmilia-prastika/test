import React from "react";
import ExclamationIcon from "../../assets/icon/exclamation_icon";

const ExclamationInfo = ({ value = "Akun Rekening Bank yang aktif maksimal berjumlah 1 (satu) buah" ,className}) => {
    return (
        <div className={`inline-flex items-center ${className}`}>
            <ExclamationIcon className="mr-2 items-start" />
            <p className="font-quicksand md:font-medium font-normal md:text-base text-xs">{value}</p>
        </div>
    )
}

export default ExclamationInfo