import { useEffect, useState } from "react";
import ButtonText from "../Text/ButtonText";
import {  intervalToDuration, addMinutes, add } from 'date-fns'

const UnavailableAssetInfo = ({ createdDate, setSocketDisableBuy, setDisableBuy, ...props }) => {
    let date, minutes
    if (createdDate) {
      const {seconds, minutes: minute} = intervalToDuration({
        start: new Date(), end: addMinutes(new Date(createdDate), 5)
      })
      date = add(new Date(), {
        minutes: minute,
        seconds
      })
    } else {
      minutes = 5
      date = addMinutes(new Date(), minutes)
    }
    const [remaining, setRemaining] = useState(intervalToDuration({
        start: new Date(),
        end: date
    }))
    useEffect(() => {
      const intervalId = setInterval(
        () => {
          return setRemaining(intervalToDuration({
            start: new Date(),
            end: date
          }))
            } ,
            1000
        )
        return () => clearInterval(intervalId);
      }, [date])
    useEffect(() => {
      // console.log(remaining, date, new Date(), "zap")
      if(minutes && remaining?.seconds === 0 && remaining?.minutes === 0) {
        setSocketDisableBuy(false)
      }
      if(remaining?.seconds === 0 && remaining?.minutes === 0 && createdDate) {
        setDisableBuy(false)
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [remaining?.seconds])

    return (
      // <ButtonText>Tunggu {remaining?.minutes < 10 ? `0${remaining?.minutes}` : remaining?.minutes } : {remaining?.seconds < 10 ? `0${remaining?.seconds}` : remaining?.seconds}</ButtonText>
      <ButtonText classstyle="text-base" color="text-hijau_hutan">Sedang dalam transaksi</ButtonText>
    )

}
export default UnavailableAssetInfo