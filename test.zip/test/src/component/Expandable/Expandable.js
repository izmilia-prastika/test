import React, { useState } from "react";
import ChevronDownIcon from "../../assets/icon/chevron_down_icon";
import ChevronUpIcon from "../../assets/icon/chevron_up_icon";

const Expandable = ({ label, initialExpand, children ,className, small=false}) => {
    const [isExpand, setIsExpand] = useState(initialExpand)
    return (
        <div className={className}>
            <div className={`flex flex-row items-center justify-between w-full ${small ? "" : "mb-6"}`}>

                <p className={`font-medium md:${small ? "text-base" : "text-xl"} text-sm font-quicksand`}>{label}</p>
                {isExpand
                    ? <ChevronUpIcon className="cursor-pointer" onClick={() => setIsExpand(false)} />
                    : <ChevronDownIcon className="cursor-pointer" onClick={() => setIsExpand(true)} />
                }
            </div>
            {isExpand && children}
        </div>
    )
}

export default Expandable