import React from "react";

const TabPanel = ({ children, isActive}) => {
    return (
        <div className={`${!isActive && "hidden"}`}>
            {children}
        </div>
    )
}

export default TabPanel