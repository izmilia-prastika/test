import React, { lazy, useCallback, useContext, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import articleContext from '../../context/Article/articleContext'
const Expandable = lazy(() => import('../Expandable/Expandable'))
const PieChartIcon = lazy(() => import('../../assets/icon/pie_chart_icon'))

const SidePanelArticle = ({titleSection, categories, className, style, onClick, type=1}) => {
const navigate = useNavigate() 
const navToDetail = useCallback((slug, id) => navigate(`/article/${slug}/${id}`), [navigate])
const ArticleContext = useContext(articleContext)
const {articles} = ArticleContext 
let newData = {};
let newArr = [];
articles.forEach((val) => {
  const year = String(new Date(val.publishedAt).getFullYear())
  const month = String(new Date(val.publishedAt).toLocaleString("default", {month: 'short'}))
  if (!newData[year]) {
    newData[year] = {}
  }
    if (!newData[year][month]) {
      newData[year][month] = []
    }
  newData[year][month].push(val)
});
Object.keys(newData).forEach((year) => {
  newArr.push({
    year,
    data: Object.keys(newData[year]).map((month) => ({
      month,
      data: newData[year][month],
    })),
  });
});

useEffect(() => {
  async function fetchData() {
    type !== 1 && await ArticleContext.getArticles() 
  }
  fetchData()
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [])
return (
    <div className={`shadow-lg rounded-lg overflow-y-auto p-7 ${className}`} style={style}>
        <div className='flex items-center'>
            <PieChartIcon />
            <p className='font-quicksand font-bold text-base text-hitam ml-2'>{titleSection}</p>
        </div>
    <div className='ml-8 mt-2'>
        {type === 1 ? categories?.map(({name, id, slug}, idx) => 
        <div className='py-1' key={idx}>
             <p key={idx} className='font-quicksand cursor-pointer font-medium text-base hover:text-hijau_hutan' onClick={()=>onClick(slug)}>{name}</p>
        </div>
        ) : 
            newArr?.map(({year, data}, idx)=> 
            <Expandable key={idx} label={year} small initialExpand={true}>
                {data.map(({month, data}, idx)=> 
                <Expandable key={idx} label={month} small className='ml-4 py-2'> 
                    {data.map(({title, slug, id}, idx)=>
                    <p key={idx} className='py-2 font-quicksand font-normal text-base cursor-pointer text-hitam_2 hover:text-hijau_hutan' onClick={() => navToDetail(slug, id)}>{title.substr(0,15)}...</p>
                    )}
                </Expandable>)}
            </Expandable>
        )
        }
    </div>
</div>
)}

export default SidePanelArticle 