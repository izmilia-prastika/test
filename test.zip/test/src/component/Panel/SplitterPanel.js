import React from "react";

const SplitterPanel = ({ children, isFirst, isLast, className, borderColor = "abu_ea", ...props }) => {
    return (
        <div {...props} style={{ borderBottomWidth: "0.5px", borderTopWidth: "1px" }} className={`${isFirst && "rounded-t-md border-t-2"} ${isLast && "rounded-b-md"} border-r-2 border-l-2 border-${borderColor} ${className}`}>
            {children}
        </div>
    )
}

export default SplitterPanel