import React from "react";
import { EmptyState } from "../../assets";


const EmptyStateSection = ({className, imgSize, text}) => {
    return (
        <div className={`${className} flex flex-col items-center h-full justify-center py-28`}>
                        <img src={EmptyState} className={`h-${imgSize}`} alt="emtpy_state"/>
                        <p className="md:text-xl text-base font-quicksand -mt-4 text-gray-600">{text}</p>
        </div>
    )
}

EmptyStateSection.defaultProps = {
    text: "Belum ada transaksi",
    className: "",
    imgSize: 48,
}

export default EmptyStateSection