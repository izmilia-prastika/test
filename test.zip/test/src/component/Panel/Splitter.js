import React, { Children, cloneElement } from "react";

const Splitter = ({ children, className }) => {
    const arrayChildren = Children.toArray(children);
    return (
        <div className={className}>
            {
                Children.map(arrayChildren, (child, index) => {
                    const isFirst = index === 0
                    const isLast = index === arrayChildren.length - 1
                    return (
                        <>
                            {
                                cloneElement(child, {
                                    isFirst, isLast
                                })
                            }
                        </>
                    );
                })
            }
        </div>
    )
}

export default Splitter