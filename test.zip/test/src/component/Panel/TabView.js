import React, { Children, cloneElement } from "react";

const TabView = ({ children, className = "grid grid-flow-col w-full", activeIndex, onTabChange, ...props }) => {
    const arrayChildren = Children.toArray(children);

    const onChangeHeader = (e) => onTabChange(e)
    return (
        <div className="w-full" {...props}>
            <div className={className}>
                {Children.map(arrayChildren, (child, index) => {
                    const isActive = activeIndex === index
                    return (
                        <p className={`cursor-pointer whitespace-nowrap md:px-6 px-4 pt-3 md:pb-4 pb-3 text-center md:text-base text-sm font-quicksand  ${isActive ? "text-hijau_hutan border-b-2 border-hijau_hutan font-bold" : "text-hitam_2 border-b-2 border-abu_ea font-medium"}`}
                            onClick={() => onChangeHeader(index)}>
                            {child.props.header}
                        </p>
                    )
                })}
            </div>
            {Children.map(arrayChildren, (child, index) => {
                const isActive = activeIndex === index
                return (
                    <>
                        {
                            cloneElement(child, {
                                isActive
                            })
                        }
                    </>
                );
            })}
        </div>
    )
}

export default TabView