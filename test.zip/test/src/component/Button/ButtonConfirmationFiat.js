import { ethers } from 'ethers'
import React, { useContext, useState } from 'react'
import { nftaddress, nftmarketaddress } from '../../config/configContract'
import txnContext from '../../context/Txn/txnContext'
// import web3ModalContext from '../../context/Web3Modal/web3ModalContext'
import { TXN_STATUS_CANCELED } from '../../utils/constants/transactionLogStatus'
import TYPE_TRANSACTION from '../../utils/constants/typeTransaction'
import NFTMarketplace from '../../artifacts/contracts/NFTMarketplace.sol/NFTMarketplace.json'
import NFT from '../../artifacts/contracts/NFT.sol/NFT.json'
import { ERC721 } from '../../utils/constants/contractType'
import RoundedButton from './RoundedButton'
import ButtonText from '../Text/ButtonText'

const jsonRpcProvider = process.env.REACT_APP_PROVIDER_LINK ? new ethers.providers.JsonRpcProvider(process.env.REACT_APP_PROVIDER_LINK) :
    new ethers.providers.getDefaultProvider()

const ButtonConfirmationFiat = ({ asset, invoice, type, index, idTxn, tokenStdType, buyerAddress, amount,listedType, ...props }) => {
    
    const TxnContext = useContext(txnContext)
    // const { web3Modal } = useContext(web3ModalContext)
    const [loading, setLoading] = useState(false)
    const handleCheck = async () => {
        if(tokenStdType === ERC721){
            const tokenContract = new ethers.Contract(nftaddress, NFT.abi, jsonRpcProvider)
            const ownerAddress = await tokenContract.ownerOf(asset?.tokenId)
            if(ownerAddress !== buyerAddress){
              props?.setIsAmount(false)
                await TxnContext?.update(idTxn, {status: TXN_STATUS_CANCELED})
                setLoading(false)
                props?.handleCancelTxn()
            } else {
                setLoading(false)
                props?.handleContinue()
            }
        } else {
            const rpcProviderContract = new ethers.Contract(nftmarketaddress, NFTMarketplace.abi, jsonRpcProvider)
            const marketTokenItem = await rpcProviderContract.getMarketTokenItem(asset?.itemContractId)
            if(amount <= marketTokenItem.amount.toNumber()) {
                props?.handleContinue()
                setLoading(false)
            }else {
                props?.setIsAmount(true)
                await TxnContext?.update(idTxn, {status: TXN_STATUS_CANCELED})
                props?.handleCancelTxn()
                setLoading(false)
            }
        }
    } 
    return (
        <RoundedButton disabled={loading} onClick={async () => {
            setLoading(true)
            if (type === TYPE_TRANSACTION.BUY) {
                await handleCheck()
            } else {
                await props?.handleContinue()
                setLoading(false)
            }
        }} className="py-3 md:px-7 px-4 " color="bg-biru_tua">
            {loading ?
                <ButtonText tx='loading...' /> :
                <ButtonText tx="Selesaikan Transaksi" classstyle="text-xs" />
            }
        </RoundedButton>
)}

export default ButtonConfirmationFiat