import env from '../../config/env'
import classNames from "classnames";

const { USER_ADDRESS_SCANNER } = env
const ButtonLinkAddress = ({ userName, address, valueColor = "yellow-500", className, onClick = () => window.open(`${USER_ADDRESS_SCANNER}/${address}`)}) => {
    return (
        <p className={`${classNames({
            "text-sm": className?.includes('text'),
            "font-bold": className?.includes('font'),
        })}
         cursor-pointer font-quicksand text-${valueColor} ${className}`} onClick={onClick}>{userName ? userName : address ? `${address?.substring(0, 5)}...${address?.substring(address?.length - 4, address?.length)}` : `-`}</p>

    )
}

export default ButtonLinkAddress