import { ethers } from 'ethers'
import React, { useContext, useState } from 'react'
import { nftmarketaddress } from '../../config/configContract'
// import web3ModalContext from '../../context/Web3Modal/web3ModalContext'
import { ERC721 } from '../../utils/constants/contractType'
import ButtonText from '../Text/ButtonText'
import RoundedButton from './RoundedButton'
import NFTMarketplace from '../../artifacts/contracts/NFTMarketplace.sol/NFTMarketplace.json'
import { TXN_TYPES_ACCEPT_OFFER, TXN_TYPES_ADD_BANK, TXN_TYPES_BID_AUCTION, TXN_TYPES_BUY, TXN_TYPES_CANCEL_AUCTION, TXN_TYPES_CANCEL_BIDDER_AUCTION, TXN_TYPES_CANCEL_LISTING, TXN_TYPES_CANCEL_OFFER, TXN_TYPES_CREATE_ASSET, TXN_TYPES_EDIT_METADATA, TXN_TYPES_LISTING, TXN_TYPES_MAKE_OFFER, TXN_TYPES_SETTLE_AUCTION } from '../../utils/constants/transactionLogTypes'
import { TXN_STATUS_CANCELED } from '../../utils/constants/transactionLogStatus'
import txnContext from '../../context/Txn/txnContext'


const jsonRpcProvider = process.env.REACT_APP_PROVIDER_LINK ? new ethers.providers.JsonRpcProvider(process.env.REACT_APP_PROVIDER_LINK) :
    new ethers.providers.getDefaultProvider()

const ButtonConfirmationCrypto = ({ asset, type, index, idTxn, tokenStdType, buyerAddress, amount, listedType,price, ...props }) => {

    const TxnContext = useContext(txnContext)
    // const { web3Modal } = useContext(web3ModalContext)
    const [loading,setLoading]=useState(false)
    
    const handleCancelTxn = () => {
        props?.setShowModalCancel(true)
    }
    const checkIsClear = async () => {
        setLoading(true)
        console.log('type transaction log,', type);

        props?.setSelectedIndex(index + 1)
        if (type === TXN_TYPES_CREATE_ASSET) {
            setLoading(false)
            await props?.handleCreateAsset(asset)
        } else if (type === TXN_TYPES_BUY) {
            // const connection = await web3Modal.connect()
            // const provider = new ethers.providers.Web3Provider(connection)
            // const signer = provider.getSigner()
            // const userAddress = await signer.getAddress();
            if (tokenStdType === ERC721) {
                // const tokenContract = new ethers.Contract(nftaddress, NFT.abi, jsonRpcProvider)
                // const ownerAddress = await tokenContract.ownerOf(asset?.tokenId)
                // if(ownerAddress !== buyerAddress){
                //   setIsAmount(false)
                //     await TxnContext?.update(idTxn, {status: TXN_STATUS_CANCELED})
                //     handleCancelTxn()
                // } else {
                setLoading(false)
                props?.handleBuyButtonOnClick(asset, idTxn)
                // }
            } else {
                const rpcProviderContract = new ethers.Contract(nftmarketaddress, NFTMarketplace.abi, jsonRpcProvider)
                const marketTokenItem = await rpcProviderContract.getMarketTokenItem(asset?.itemContractId)
                if (amount <= marketTokenItem.amount.toNumber()) {
                    setLoading(false)
                    await props?.handleBuyButtonOnClick(asset)
                } else {
                    props?.setIsAmount(true)
                    await TxnContext?.update(idTxn, { status: TXN_STATUS_CANCELED })
                    setLoading(false)
                    handleCancelTxn()
                }
            }
        } else if (type === TXN_TYPES_CANCEL_LISTING) {
            await props?.handleCancelListingBtnOnClick(asset)
        } else if (type === TXN_TYPES_LISTING) {
            await props?.handleListingButtonOnclick(asset, listedType)
        } else if (type === TXN_TYPES_ACCEPT_OFFER) {
            await props?.handleAcceptOffer(props?.assetBidsDetailCheck[index], asset)
        } else if (type === TXN_TYPES_CANCEL_OFFER) {
            await props?.handleCancelMakeofferBtnOnClick(asset, index)
        } else if (type === TXN_TYPES_SETTLE_AUCTION) {
            await props?.acceptAuctionBtnOnclick(props?.assetAuctionsCheck[index]?.[0], asset)
        } else if (type === TXN_TYPES_CANCEL_AUCTION) {
            await props?.handleCancelAuctionBtnOnclick(asset, index)
        } else if (type === TXN_TYPES_BID_AUCTION) {
            await props?.handleBidderAuctionBtnOnclick(asset, index,idTxn,price)
        } else if (type === TXN_TYPES_MAKE_OFFER) {
            await props?.handleMakeOfferBtnOnclick(asset)
        } else if (type === TXN_TYPES_CANCEL_BIDDER_AUCTION) {
            await props?.handleCancelBidAuctionBtnOnclick(asset, index)
        } else if (type === TXN_TYPES_EDIT_METADATA) {
            await props?.handleUpdateMetadataBtnOnclick(asset)
        } else if (type === TXN_TYPES_ADD_BANK) {
            await props?.handleContinueBank()
        }
        setLoading(false)
    }
    return (
        <RoundedButton disabled={loading} onClick={checkIsClear} className="py-3 md:px-7 px-4 md:w-auto w-full " color="bg-biru_tua">
            {loading ?
                <ButtonText tx='loading...' /> :
                <ButtonText tx={props?.responsives ? "Selesaikan" : "Selesaikan Transaksi"} classstyle="text-xs" />
            }
        </RoundedButton>)
}

export default ButtonConfirmationCrypto