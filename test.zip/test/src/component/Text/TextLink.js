import React from "react";
import { useTranslation } from "react-i18next";

const TextLink = (props) => {
    const { tx, text, children, classstyle, color = "text-hijau_hutan", textSize = 'text-lg', onClick } = props
    const { t } = useTranslation();
    const translatedText = tx && t(tx)
    const content = translatedText || text || children

    return <p className={`${color} font-quicksand font-bold ${textSize} ${classstyle}`} onClick={onClick}>
        {content}
    </p>
}

export default TextLink