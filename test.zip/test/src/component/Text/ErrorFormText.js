import React from 'react'
import { useTranslation } from 'react-i18next';

const ErrorFormText = (props) => {
    const { tx, text, children, classstyle } = props
    const { t } = useTranslation();
    const translatedText = tx && t(tx)
    const content = translatedText || text || children

    return (
        <p className={`text-sm text-red-500 font-quicksand ${classstyle}`} >
            {content}
        </p >
    )
}

export default ErrorFormText