import React from "react";

const HorizontalInfoText = (props) => {
    const { label, value, valueColor = "text-hitam_2",onClick, labelColor = "text-gray-500", responsive } = props
    let newValue;
    if(value?.length > 25 && responsive){
        newValue = `${value.substring(0, 14)}...${value.substring(value.length-4, value.length)}`
    }
    else {
        newValue = value;
    }
    return (
        <div className="flex">
            <p style={{ width: '35%' }} className={`md:text-lg tracking-tight text-xs whitespace-nowrap font-quicksand ${labelColor}`}>{label} </p>
            <p className="md:text-lg tracking-tight text-xs whitespace-nowrap font-quicksand ">:</p>
            <p style={{ width: '100%' }} onClick={onClick} className={`${onClick&& 'cursor-pointer'} md:text-lg tracking-tight text-xs font-quicksand font-bold break-all ${valueColor} justify-self-start ml-2`}>{newValue}</p>
        </div>
    )
}

export default HorizontalInfoText
