import React from "react";

const InfoText = (props) => {
    const { label, value, className,onClick } = props
    return (
        <div className={`flex-col flex ${className}`}>
            <p className="md:text-sm text-xs font-quicksand text-abu_86">{label}</p>
            <p onClick={onClick} className=" cursor-pointer lg:text-base fhd:text-lg text-xs font-quicksand font-bold text-hitam_2">{value}</p>
        </div>
    )
}

export default InfoText