import React from 'react'
import NumberFormat from 'react-number-format'

const TextNumber = ({ text, className }) => {
    return (
        <NumberFormat
            thousandSeparator={'.'}
            displayType={'text'}
            value={text}
            decimalSeparator={','}
            renderText={(value,props) => {
                return <p className={className}>{value}</p>
            }}
        />
    )
}

export default TextNumber