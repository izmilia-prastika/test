import React from "react";
import { useTranslation } from "react-i18next";

const TitleText = ({ tx, text, children ,classstyle, textSize="text-xl", textSizeMobile="text-base" }) => {
    const { t } = useTranslation();
    const translatedText = tx && t(tx)
    const content = translatedText || text || children

    return <p className={`text-hitam font-quicksand font-semibold md:${textSize} ${textSizeMobile}  ${classstyle}`}>
        {content}
    </p>
}

export default TitleText