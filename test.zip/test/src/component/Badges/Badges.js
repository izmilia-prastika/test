import classNames from "classnames";
import React from "react";

const Badges = ({ style, margin = 'md:py-2 py-1 px-4 md:mt-4 mt-0 items-center justify-center', icon, value, bgColor = "green-50", txtColor = "british_green_racing", className, fontSize = 'text-xs' }) => {
  return (
    <div 
      {...(style && {style: style} )}
      className={`bg-${bgColor} ${classNames({
      "rounded-full": !className?.includes("rounded")
    })}  ${margin} flex flex-row ${className}`}>
      {icon}
      <p className={`font-quicksand font-bold ${fontSize} text-${txtColor} break-normal`}>
        {value}
      </p>
    </div>
  )
}

export default Badges