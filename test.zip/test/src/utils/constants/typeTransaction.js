const TYPE_TRANSACTION = {
    BID: 'auction',
    BUY: 'buy',
    MAKE_OFFER: 'make offer',
    ACCEPT_MAKE_OFFER: 'accept make offer',
    CANCEL_MAKE_OFFER: 'cancel make offer',
    LISTING: 'listing',
    CANCEL_LISTING: "cancel listing",
    CANCEL_AUCTION: "cancel auction",
    CANCEL_BID_AUCTION: "cancel bid auction",
    ACCEPT_AUCTION: "finish auction",
    LISTING_AUCTION: "listing auction",
    FIAT_BUY: "buy with fiat",
    ACTIVATE_FIAT: "activate fiat",
    CREATE_ASSET: "create asset",
    ADD_BANK: 'add bank',
    EDIT_BANK: 'edit bank',
    EDIT_COLLECTION:'edit collection',
    EDIT_METADATA:'edit metadata',
}

export default TYPE_TRANSACTION
