export const ERC721 = 1
export const ERC1155 = 2