export const UTIL_CODE_TYPE = 1
export const UTIL_TICKET_TYPE = 2
export const UTIL_MEMBERSHIP_TYPE = 3