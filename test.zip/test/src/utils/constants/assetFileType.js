export const IMAGE_FILE_TYPE = 1;
export const VIDEO_FILE_TYPE = 2;
export const MUSIC_FILE_TYPE = 3;