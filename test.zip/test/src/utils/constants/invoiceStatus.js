export const INVOICE_UNPAID = 0;
export const INVOICE_PAID = 1;
export const INVOICE_EXPIRED = 2;