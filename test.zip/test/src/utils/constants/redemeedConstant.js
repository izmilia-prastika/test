export const REDEEMED = 0
export const NOT_REDEEMED = 1