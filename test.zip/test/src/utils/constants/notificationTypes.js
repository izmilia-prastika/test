export const NOTIFICATION_BUY=1
export const NOTIFICATION_MAKE_OFFER=2
export const NOTIFICATION_BID_AUCTION=3
export const NOTIFICATION_BID_AUCTION_EXPIRED=4
// Comment	1->Aset Terjual 2->Aktivitas Penawaran 3->Penawaran Lelang 4-> Penawaran Lelang Asset Kadalursa