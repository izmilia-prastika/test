export const MINTING = 1
export const LISTING = 2
export const TRANSFER = 3
export const SOLD = 4
export const MAKE_OFFER = 5
export const MAKE_BID_AUCTION = 6
export const CANCEL_OFFER = 7
export const CANCEL_AUCTION = 8