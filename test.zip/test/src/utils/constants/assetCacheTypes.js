export const RANDOM_ASSETS_CACHE_TYPE = "randomAssets"
export const CATEGORIES_CACHE_TYPE = "categories"
export const TOP_TAGS_CACHE_TYPE = "topTags"
export const BANNER_CACHE_TYPE = "banners"