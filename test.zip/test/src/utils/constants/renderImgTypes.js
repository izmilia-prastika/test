export const ORIGINAL_THUMBNAIL_IMAGE_TYPE = "?x-oss-process=style/original"
export const MEDIUM_THUMBNAIL_IMAGE_TYPE = "?x-oss-process=style/medium"
export const SMALL_THUMBNAIL_IMAGE_TYPE = "?x-oss-process=style/small"