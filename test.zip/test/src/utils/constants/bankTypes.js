export const bankTypes = [{
	"name": "Bank Central Asia (BCA)",
	"code": "BCA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Mandiri",
	"code": "MANDIRI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank CIMB Niaga",
	"code": "CIMB",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Danamon",
	"code": "DANAMON",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Permata",
	"code": "PERMATA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Panin",
	"code": "PANIN",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Sinarmas",
	"code": "SINARMAS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank BRI Agroniaga",
	"code": "AGRONIAGA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank BJB",
	"code": "BJB",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank BJB Syariah",
	"code": "BJB_SYR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank BNI Syariah",
	"code": "BNI_SYR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Central Asia (BCA) Syariah",
	"code": "BCA_SYR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank DKI",
	"code": "DKI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Syariah BRI",
	"code": "BRI_SYR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Syariah Mandiri",
	"code": "MANDIRI_SYR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Tabungan Negara (BTN)",
	"code": "BTN",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Aceh",
	"code": "ACEH",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Bali",
	"code": "BALI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Bengkulu",
	"code": "BENGKULU",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Daerah Istimewa Yogyakarta (DIY)",
	"code": "DAERAH_ISTIMEWA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Daerah Istimewa Yogyakarta (DIY) UUS",
	"code": "DAERAH_ISTIMEWA_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jambi",
	"code": "JAMBI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jambi UUS",
	"code": "JAMBI_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jawa Tengah",
	"code": "JAWA_TENGAH",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jawa Tengah UUS",
	"code": "JAWA_TENGAH_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jawa Timur",
	"code": "JAWA_TIMUR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Jawa Timur UUS",
	"code": "JAWA_TIMUR_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Barat",
	"code": "KALIMANTAN_BARAT",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Barat UUS",
	"code": "KALIMANTAN_BARAT_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Selatan",
	"code": "KALIMANTAN_SELATAN",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Selatan UUS",
	"code": "KALIMANTAN_SELATAN_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Tengah",
	"code": "KALIMANTAN_TENGAH",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Timur",
	"code": "KALIMANTAN_TIMUR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Kalimantan Timur UUS",
	"code": "KALIMANTAN_TIMUR_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Lampung",
	"code": "LAMPUNG",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Maluku",
	"code": "MALUKU",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Nusa Tenggara Barat",
	"code": "NUSA_TENGGARA_BARAT",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Nusa Tenggara Barat UUS",
	"code": "NUSA_TENGGARA_BARAT_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Nusa Tenggara Timur",
	"code": "NUSA_TENGGARA_TIMUR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Papua",
	"code": "PAPUA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Riau Dan Kepri",
	"code": "RIAU_DAN_KEPRI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Riau Dan Kepri UUS",
	"code": "RIAU_DAN_KEPRI_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sulawesi Tengah",
	"code": "SULAWESI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sulawesi Tenggara",
	"code": "SULAWESI_TENGGARA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sulselbar",
	"code": "SULSELBAR",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sulselbar UUS",
	"code": "SULSELBAR_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sulut",
	"code": "SULUT",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumatera Barat",
	"code": "SUMATERA_BARAT",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumatera Barat UUS",
	"code": "SUMATERA_BARAT_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumsel Dan Babel",
	"code": "SUMSEL_DAN_BABEL",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumsel Dan Babel UUS",
	"code": "SUMSEL_DAN_BABEL_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumut",
	"code": "SUMUT",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Sumut UUS",
	"code": "SUMUT_UUS",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Rakyat Indonesia (BRI)",
	"code": "BRI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Negara Indonesia (BNI)",
	"code": "BNI",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Maybank",
	"code": "MAYBANK",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BPD Banten (formerly Bank Pundi Indonesia)",
	"code": "BANTEN",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "BTPN Syariah (formerly BTPN UUS and Bank Sahabat Purba Danarta)",
	"code": "BTPN_SYARIAH",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "GoPay",
	"code": "GOPAY",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "OVO",
	"code": "OVO",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Mandiri E-Cash",
	"code": "MANDIRI_ECASH",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "DANA",
	"code": "DANA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "LinkAja",
	"code": "LINKAJA",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "ShopeePay",
	"code": "SHOPEEPAY",
	"can_disburse": true,
	"can_name_validate": true
},
{
	"name": "Bank Syariah Indonesia (BSI)",
	"code": "BSI",
	"can_disburse": true,
	"can_name_validate": true
},]