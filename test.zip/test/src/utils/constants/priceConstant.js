import env from "../../config/env"

export const BCA_LIMIT = env.BCA_LIMIT
export const OTHERS_LIMIT = env.OTHERS_LIMIT
export const MAXIMUM_PAYMENT_LIMIT = 100000000
export const MINIMUM_PAYMENT_LIMIT = 0
export const BANK_FEE=env.BANK_FEE