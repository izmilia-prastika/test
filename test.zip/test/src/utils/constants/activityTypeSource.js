export const CRYPTO_ACTIVITY = 1
export const FIAT_ACTIVITY = 2