export const POLYGON_MAINNET = {
  chainId: 137,
  rpcUrl: ["https://polygon-rpc.com/"],
  chainName: "POLYGON MAINNET",
  nativeCurrency: {
    name: "MATIC",
    symbol: "MATIC",
    decimals: 18,
  },
  blockExplorerUrl:["https://polygonscan.com/"]
}

export const POLYGON_MUMBAI = {
  chainId: 80001,
  rpcUrl: ["https://rpc-mumbai.matic.today/"],
  chainName: "POLYGON MUMBAI",
  nativeCurrency: {
    name: "MATIC",
    symbol: "MATIC",
    decimals: 18,
  },
  blockExplorerUrl:["https://mumbai.polygonscan.com/"]
}

export const ETHEREUM_RINKEBY = {
  chainId: 4,
  rpcUrl: [""],
  chainName: "Rinkeby",
  nativeCurrency: {
    name: "ETH",
    symbol: "ETH",
    decimals: 18,
  },
  blockExplorerUrl:["https://rinkeby.etherscan.io"]
}