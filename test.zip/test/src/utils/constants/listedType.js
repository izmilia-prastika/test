export const FIX_PRICE = 0
export const AUCTION = 1