import axios from "axios";
import env from "../config/env";

const { API_URL } = env;

const getAuth = () => {
  const auth = JSON.parse(window.localStorage.getItem("auth"));
  return auth;
};

const api = axios.create();

api.interceptors.request.use(config => {
  config.baseURL = API_URL
  config.timeout = 60000
  config.headers["Authorization"] = `Bearer ${getAuth()?.accessToken}`
  return config
})

// api.interceptors.response.use(undefined, error => {
//   const navigate = useNavigate()
//   if(error.message === "Network Error" && !error.response) {
//     toast.error("Maaf terjadi kesalahan pada koneksi, Silahkan coba pada beberapa saat lagi")
//     navigate("/")
//   }
// })

export default api;