import React, { useContext, useEffect, useState } from "react";
import assetContext from "../../context/Asset/assetContext";

const useFilterAsset = () => {
    const AssetContext = useContext(assetContext)

    const [categories, setCategories] = useState([]);

    useEffect(async () => {
        const res = await AssetContext.getAllAssets({
            first: 4,
            categoryId: { ...categories.map(category => category.value) }
        })
    }, [categories])
    return {
        categories,
        setCategories
    }
}

export default useFilterAsset