import * as yup from "yup";
import { yupResolver } from '@hookform/resolvers/yup';

const schema = yup.object({
    ktpNpwpUrl: yup.mixed().required('File Identitas perlu diisi'),
    buktiKepemilikanAsetUrl: yup.mixed().required('Bukti Kepemilikan perlu diisi'),
    namaPic: yup.string().required('Nama tidak boleh kosong'),
    alamatPic: yup.string().required('Alamat tidak boleh kosong'),
    noTelpPic: yup.string().required('Kontak tidak boleh kosong'),
    alamatEmailPic: yup.string().required('email tidak boleh kosong')
}).required();

const JoinNowValidation = yupResolver(schema)
export default JoinNowValidation