import * as yup from "yup";
import { yupResolver } from '@hookform/resolvers/yup';
import { AUCTION } from "../constants/listedType";

const schema = yup.object({
    thumbnailUrl: yup.mixed().required('File Asset perlu diisi'),
    name: yup.string().required('Nama tidak boleh kosong'),
    category: yup.mixed().required('Kategori harus dipilih'),
    amount: yup.number().moreThan(0,'Jumlah Asset kurang dari 1').required('Jumlah Asset tidak boleh kosong'),
    price: yup.number().when('isListed',{
        is:true,
        then:yup.number().required('Harga tidak boleh kosong').typeError("Harga tidak boleh kosong")
    }),
    duration: yup.mixed().when('typeSell',{
        is: AUCTION,
        then:yup.date().typeError('Format tanggal tidak valid').required('Durasi tidak boleh kosong')
    }
    )
  }).required();

const CreateAssetValidation = yupResolver(schema)
export default CreateAssetValidation