import * as yup from "yup";
import { yupResolver } from '@hookform/resolvers/yup';

const schema = yup.object({
    fileUrl: yup.mixed().required('File Collection perlu diisi'),
    name: yup.string().required('Nama tidak boleh kosong'),
    category: yup.mixed().required('Kategori harus dipilih'),
    price: yup.number().when('isListed', {
        is: true,
        then: yup.number().required('Harga tidak boleh kosong')
    }),
    namePic: yup.mixed().when('isVerifying', {
        is: true,
        then: yup.string().required('Nama PIC tidak boleh kosong')
    }),
    address: yup.mixed().when('isVerifying', {
        is: true,
        then: yup.string().required('Alamat PIC tidak boleh kosong')
    }),
    phone: yup.mixed().when('isVerifying', {
        is: true,
        then: yup.string().required('Kontak PIC tidak boleh kosong')
    }),
    idCardFile: yup.mixed().when('isVerifying', {
        is: true,
        then: yup.mixed().typeError('Format file tidak valid').required('File identitas perlu diisi')
    }),
    requirementFile: yup.mixed().when('isVerifying', {
        is: true,
        then: yup.mixed().typeError('Format file tidak valid').required('Bukti kepemilikan perlu diisi')
    })
}).required();

const CollectionValidation = yupResolver(schema)
export default CollectionValidation