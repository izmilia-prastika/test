import axios from "axios";
const config = {
  timeout: 5000,
};

const api = axios.create(config);

const checkIpfs = async (hash) => {
  try {
    const check = await api.post(
      `https://ipfs.infura.io:5001/api/v0/object/stat?arg=${hash}`
    );
    if (hash === check.data.Hash) {
      // console.log("Ada CID file IPFS yang sama");
      return true;
    }
  } catch (error) {
    // console.log("Belum ada CID file IPFS yang sama");
    return false;
  }
};

export default checkIpfs;
