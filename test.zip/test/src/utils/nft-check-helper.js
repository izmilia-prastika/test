// import { compareAsc, isAfter  } from "date-fns"
// import { INVOICE_PAID, INVOICE_UNPAID  } from "./constants/invoiceStatus"
import { INVOICE_BUY, INVOICE_ACCEPT_OFFER, INVOICE_CANCEL_LISTING, INVOICE_CREATE_ASSET, INVOICE_LISTING, INVOICE_CANCEL_OFFER, INVOICE_SETTLE_AUCTION, INVOICE_CANCEL_AUCTION, INVOICE_CANCEL_BIDDER_AUCTION  } from "./constants/invoiceTypes"
// import api from "./api"
// import { ethers } from "ethers"
// import { ERC1155 } from "./constants/contractType"
// import { nftmarketaddress } from "../config/configContract"
// import NFTMulti from "../artifacts/contracts/NFTMulti.sol/NFTMulti.json"
// import NFTMarketplace from "../artifacts/contracts/NFTMarketplace.sol/NFTMarketplace.json"
import { AUCTION } from "./constants/listedType"
import _ from "lodash";

// const checkUnpaidInvoiceExist = (conditionalInvoice) => conditionalInvoice.filter(node => node?.status === INVOICE_UNPAID).length !== 0

// const getUnpaidInvoices = (conditionalInvoice) => conditionalInvoice.filter(node => node?.status === INVOICE_UNPAID)?.[0]

// const checkPaidInvoicenBuy = (conditionalInvoice, nft) => (
//   conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY)?.[0] &&
//   compareAsc(new Date(conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY)?.[0].updatedAt), new Date(nft?.updatedAt)) === 1
// )
// const checkPaidInvoicenBuyERC721 = (conditionalInvoice, nft) => (
//   conditionalInvoice?.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY).length !== 0 &&
//   conditionalInvoice?.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY)?.[0]?.accountId !== nft?.ownerId &&
//   compareAsc(new Date(conditionalInvoice?.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY)?.[0]?.updatedAt), new Date(nft?.updatedAt)) === 1 &&
//   nft?.tokenStandardType !== ERC1155
// )
// const getPaidInvoicenBuy = (conditionalInvoice) => conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_BUY)?.[0]

// const checkPaidInvoicenAcceptOffer = (conditionalInvoice, nft) => (
//   conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_ACCEPT_OFFER)?.[0] &&
//   compareAsc(new Date(conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_ACCEPT_OFFER)?.[0].updatedAt), new Date(nft?.updatedAt)) === 1
// )

// const checkPaidInvoicenAcceptOfferERC721 = (conditionalInvoice, nft) => (
//   conditionalInvoice?.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_ACCEPT_OFFER).length !== 0 &&
//   compareAsc(new Date(conditionalInvoice?.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_ACCEPT_OFFER)?.[0]?.updatedAt), new Date(nft?.updatedAt)) === 1 &&
//   nft?.tokenStandardType !== ERC1155
// )
// const getPaidInvoicenAcceptOffer = (conditionalInvoice) => conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_ACCEPT_OFFER)?.[0]

// const checkPaidInvoicenCancelListing = (conditionalInvoice, nft) => (
//   conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_CANCEL_LISTING)?.[0] &&
//   compareAsc(new Date(conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_CANCEL_LISTING)?.[0].updatedAt), new Date(nft?.updatedAt)) === 1
// )
// const checkPaidInvoicenCancelListingERC721 = (conditionalInvoice, nft) => (
//   conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_CANCEL_LISTING).length !== 0 &&
//   compareAsc(new Date(conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_CANCEL_LISTING)?.[0]?.updatedAt), new Date(nft?.updatedAt)) === 1 &&
//   nft?.tokenStandardType !== ERC1155
// )

// const getPaidInvoiceCancelListing = (conditionalInvoice) => conditionalInvoice.filter(node => node?.status === INVOICE_PAID && node?.type === INVOICE_CANCEL_LISTING)?.[0]

export const checkERC721 = (nft) => {
  // let result
  // const conditionalInvoice = nft?.conditionalInvoice?.nodes

  if (nft?.isTransactionActive) {
    return true
  } else {
    return false
  }

  // if (nft?.conditionalInvoice?.nodes?.length === 0) {
  //   result = false
  // } else if (checkUnpaidInvoiceExist(conditionalInvoice)) {
  //   result = getUnpaidInvoices(conditionalInvoice)
  // } else if (checkPaidInvoicenBuyERC721(conditionalInvoice, nft)) {
  //   result = getPaidInvoicenBuy(conditionalInvoice)
  // } else if (checkPaidInvoicenAcceptOfferERC721(conditionalInvoice, nft)) {
  //   result = getPaidInvoicenAcceptOffer(conditionalInvoice)
  // } else if (checkPaidInvoicenCancelListingERC721(conditionalInvoice, nft)) {
  //   result = getPaidInvoiceCancelListing(conditionalInvoice)
  // } else {
  //   result = false
  // }

  // console.log("zap checkERC271", nft?.id, result)

  // return result
}

// const readRedisOrContractERC1155 = async (nft, nftInvoice) => {
//   const provider = process.env.REACT_APP_PROVIDER_LINK ? new ethers.providers.JsonRpcProvider(process.env.REACT_APP_PROVIDER_LINK) :
//     new ethers.providers.getDefaultProvider()

//   const contract = new ethers.Contract(nftmarketaddress, NFTMarketplace.abi, provider)
//   const marketTokenItem = await contract.getMarketTokenItem(nft?.itemContractId)

//   const tokenBalance = marketTokenItem.amount

//   const amount = nftInvoice?.amount

//   if (nft?.remainingAmount - amount !== tokenBalance.toNumber()) {
//     // socket.emit("client_erc1155", { itemContractId: nft?.itemContractId, balanceOf: tokenBalance.toNumber() })
//     return nftInvoice
//   }

//   return false
// }

export const checkERC1155 = (nft) => {
  // const conditionalInvoice = nft?.conditionalInvoice?.nodes
  if (nft?.isTransactionActive) {
    return true
  } else {
    return false
  }
  // if (checkUnpaidInvoiceExist(conditionalInvoice)) {
  //   return getUnpaidInvoices(conditionalInvoice)
  // } else if (checkPaidInvoicenBuy(conditionalInvoice, nft)) {
  //   const nftInvoice = getPaidInvoicenBuy(conditionalInvoice)
  //   const isListed = await readRedisOrContractERC1155(nft, nftInvoice)
  //   return isListed
  // } else if (checkPaidInvoicenAcceptOffer(conditionalInvoice, nft)) {
  //   const nftInvoice = getPaidInvoicenAcceptOffer(conditionalInvoice)
  //   return await readRedisOrContractERC1155(nft, nftInvoice)
  // } else if (checkPaidInvoicenCancelListing(conditionalInvoice, nft)) {
  //   return getPaidInvoiceCancelListing(conditionalInvoice)
  // }
  // return false
}

export const checkInvoiceAssetComplete = async ({
  invoice,
  asset,
  assetBidsDetailCheck,
  assetAuctionsCheck,
  assetAuctionCheckByAssetId,
  isSigns,
  type,
  authContext: AuthContext
}) => {
  console.log('zap check invoice asset : ',invoice,
  asset,
  assetBidsDetailCheck,
  assetAuctionsCheck,
  assetAuctionCheckByAssetId,
  isSigns,
  type,
  AuthContext,
  !assetBidsDetailCheck?.assetsBidByAssetBidId?.isClosed
  );
  
  const checkCancelBidAuction = (prop) =>
    !assetAuctionsCheck?.assetsAuctionDetailsByAssetAuctionId?.nodes?.[0]?.bidderAccount === AuthContext?.auth?.user?.id ?
      false
      :
      true

  const checkCreateAsset = (prop) =>
    _.isNil(prop?.asset?.tokenId) || _.isNil(prop?.asset?.itemContractId) ?
      false
      :
      prop?.asset?.listedType === AUCTION ?
        assetAuctionCheckByAssetId && assetAuctionCheckByAssetId?.length > 0 ?
          true
          :
          false
        :
        true

  const checkBuyAsset = (prop) =>
    isSigns ?
      false
      :
      true

  const checkCancelListing = (prop) =>
    prop?.asset?.isListed /*&& isAfter(new Date(prop?.invoice?.updatedAt), new Date(prop?.asset?.updatedAt))*/ ?
      false
      :
      true

  const checkActivateListing = (prop) =>
    !prop?.asset?.isListed  /*&& isAfter(new Date(prop?.invoice?.updatedAt), new Date(prop?.asset?.updatedAt))*/ ?
      false
      :
      true

  const checkAcceptOffer = (prop) =>
    !assetBidsDetailCheck?.assetsBidByAssetBidId?.isClosed ?
      false
      :
      true
  const checkCancelOffer = (prop) =>
    !assetBidsDetailCheck?.isCanceled ?
      false
      :
      true

  const checkAcceptAuction = (prop) =>
    !assetAuctionsCheck?.isClosed ?
      false
      :
      true

  const checkCancelAuction = (prop) =>
    !assetAuctionsCheck?.isClosed ?
      false
      :
      true
  return (
    type === INVOICE_CREATE_ASSET ?
      checkCreateAsset({ asset: asset, invoice: invoice })
      :
      type === INVOICE_BUY ?
        checkBuyAsset({ asset: asset, invoice: invoice })
        :
        type === INVOICE_CANCEL_LISTING ?
          checkCancelListing({ asset: asset, invoice: invoice })
          :
          type === INVOICE_LISTING ?
            checkActivateListing({ asset: asset, invoice: invoice })
            :
            type === INVOICE_ACCEPT_OFFER && assetBidsDetailCheck?.assetsBidByAssetBidId?.assetByAssetId?.id === asset?.id ?
              checkAcceptOffer({ asset: asset, invoice: invoice })
              :
              type === INVOICE_CANCEL_OFFER ?
                checkCancelOffer({ asset: asset, invoice: invoice })
                :
                type === INVOICE_SETTLE_AUCTION ?
                  checkAcceptAuction({ asset: asset, invoice: invoice })
                  :
                  type === INVOICE_CANCEL_AUCTION ?
                    checkCancelAuction({ asset: asset, invoice: invoice })
                    :
                    type === INVOICE_CANCEL_BIDDER_AUCTION ?
                      checkCancelBidAuction({ asset: asset, invoice: invoice })
                      : true
  )
}