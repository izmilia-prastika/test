export async function handleItemId(asset, contract, address) {
    let itemId = await contract.getErc1155TokenOwnerMapping(asset?.tokenId, address)
    while (itemId.toNumber() === 0) {
        itemId = await contract.getErc1155TokenOwnerMapping(asset?.tokenId, address)
        if (itemId.toNumber() !== 0) {
            break;
        }
    }
    return itemId
}