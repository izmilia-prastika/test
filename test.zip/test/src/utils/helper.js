import { intervalToDuration } from "date-fns";
import { ethers } from "ethers";
import env from "../config/env";

export const WEB_HOST = window.location.protocol + "//" + window.location.host;

export const comparePricePercentage = (initialPrice, comparedPrice) => {
    return (initialPrice && comparedPrice ?
        initialPrice >= comparedPrice ?
            (initialPrice - comparedPrice) / comparedPrice * 100
            :
            (comparedPrice - initialPrice) / initialPrice * 100
        : null)
}

export const calculateGasFee = (gasPrice) => {
    return gasPrice !== 0 ? Math.ceil(gasPrice * 3 / 1000) * 1000 : 0
}

export function toDataUrl(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function() {
        callback(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
}

export const renderFileUploadPath = (type, address) => `/${type}/${address}/`

export const renderUserLabel = (username, address) => {
    return `${username ?? address?.substring(0, 5)}${!username ? "..." : ""}${!username ? address?.substring(address?.length - 4, address?.length) : ""}`
}

export const convertNumber = (value) => {
    return value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1')
}

export const renderIntervalDateText = (value) => {
    const { years, months, weeks, days, hours, minutes, seconds } = intervalToDuration({
        start: new Date(value),
        end: new Date()
    })
    if (years > 0) {
        return `${years} Tahun Yang Lalu`
    } else if (months) {
        return `${months} Bulan Yang Lalu`

    } else if (weeks) {
        return `${weeks} Minggu Yang Lalu`

    } else if (days) {
        return `${days} Hari Yang Lalu`

    } else if (hours) {
        return `${hours} Jam Yang Lalu`

    } else if (minutes) {
        return `${minutes} Menit Yang Lalu`

    } else if (seconds) {
        return `${seconds} Detik Yang Lalu`
    }
}

export const gasPriceGetter = () => {
    return ethers.utils.parseUnits(env.GAS_PRICE, env.GAS_PRICE_FORMAT)
}