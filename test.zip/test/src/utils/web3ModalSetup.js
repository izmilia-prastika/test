
import Web3Modal from "web3modal";

const web3ModalSetup = () => new Web3Modal({
  cacheProvider: true
})
export default web3ModalSetup