import {
    REDEEM_CODE,
    RESET_REDEEM_CODE,
    SET_LOADING,
    SET_MAX_REACHED,
    SET_STATUS_REDEEM,
} from '../types';

const reducer = (state, action) => {
    switch (action.type) {
        case REDEEM_CODE:
            return {
                ...state,
                stateRedeem: action.payload,
                loading: false,
            }
        case RESET_REDEEM_CODE:
            return {
                canRedeem: undefined,
                isMaxReached: false,
                loading: false
            }
        case SET_STATUS_REDEEM:
            return {
                ...state,
                canRedeem: action.payload,
                loading: false,
            }
        case SET_MAX_REACHED:
            return {
                ...state,
                isMaxReached: action.payload,
                loading: false,
            }
        case SET_LOADING:
            return {
                ...state,
                loading: true
            };
        default:
            return state;
    }
};

export default reducer
