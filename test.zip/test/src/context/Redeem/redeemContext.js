import { createContext } from 'react';

const redeemContext = createContext();

export default redeemContext;