import React, { useReducer } from 'react';
import RedeemContext from './redeemContext';
import RedeemReducer from './redeemReducer';
// import { post } from '../../utils/graphql-api';
import { REDEEM_CODE, RESET_REDEEM_CODE, SET_LOADING, SET_MAX_REACHED, SET_STATUS_REDEEM } from '../types';
import api from '../../utils/api'

const RedeemState = props => {
    const initialState = {
        stateRedeem: undefined,
        canRedeem: undefined,
        isMaxReached: false,
        loading: false
    };

    const [state, dispatch] = useReducer(RedeemReducer, initialState);

    const resetCode = async () => {
        setLoading();
        await dispatch({
            type: RESET_REDEEM_CODE,
        })
    }

    // Search Users
    const redeemCode = async (codeScan) => {
        let res
        setLoading();
        try {
            res = await api.post("/klaim/redeem", { code: codeScan });
            // res = await api.post("/utilities/redeem", { code: 'ASWE231231234' });
            // console.log(res, "TES")
            await dispatch({
                type: REDEEM_CODE,
                payload: res?.data,
            })
            await dispatch({
                type: SET_STATUS_REDEEM,
                payload: true,
            })
        } catch (err) {
            if (err?.response?.status === 403 && err?.response?.data?.message?.includes('reached')) {
                await dispatch({
                    type: SET_STATUS_REDEEM,
                    payload: false,
                })
                await dispatch({
                    type: SET_MAX_REACHED,
                    payload: true,
                })
                console.log(err?.response, 'TES')
            } else {
                await dispatch({
                    type: SET_STATUS_REDEEM,
                    payload: false,
                })
                await dispatch({
                    type: SET_MAX_REACHED,
                    payload: false,
                })
                console.log(err?.response, 'TES')
            }
        }
        // });

        return res?.data
    };
    // Set Loading
    const setLoading = () => dispatch({ type: SET_LOADING });
    return (
        <RedeemContext.Provider
            value={{
                redeemState: state.redeemState,
                canRedeem: state.canRedeem,
                isMaxReached: state.isMaxReached,
                loading: state.loading,
                redeemCode,
                resetCode,
            }}
        >
            {props.children}
        </RedeemContext.Provider>
    );
};

export default RedeemState;
