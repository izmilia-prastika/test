import { createContext } from 'react';

const txnContext = createContext();

export default txnContext;
