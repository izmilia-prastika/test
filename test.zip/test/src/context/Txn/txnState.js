import React, { useReducer } from 'react';
import TxnContext from './txnContext';
import TxnReducer from './txnReducer';
// import { ALL_COLLECTION,SET_LOADING } from '../types';
import { post } from '../../utils/graphql-api';
import { SET_LOADING, GET_TXN_LOG, ADD_TXN_LOG, DELETE_TXN_LOG, UPDATE_TXN_LOG } from '../types';

const TxnState = props => {
  const initialState = {
    txnPending: [],
    pageInfo: {},
    loadingTxn: false
  };

  const [state, dispatch] = useReducer(TxnReducer, initialState);

  const getTxn = async (prop) => {
    setLoading()
    const res = await post('getTransactionLogs', { ...prop })
    await dispatch({
      type: GET_TXN_LOG,
      payload: res?.data?.data?.allTransactionsLogs
    })
    return res?.data?.data?.allTransactionsLogs
  }

  
  const add = async (input) => {
    setLoading()
    const res = await post('addTransactionLog', { ...input })
    await dispatch({
      type: ADD_TXN_LOG,
      payload: res?.data?.data?.createTransactionsLog?.transactionsLog
    })
    return res?.data?.data?.createTransactionsLog?.transactionsLog
  }
  
  const _delete = async (id) => {
    setLoading()
    const res = await post('deleteTransactionLog', { id})
    await dispatch({
      type: DELETE_TXN_LOG,
      payload: res?.data?.data?.deleteTransactionLog?.transactionsLog
    })
    return res?.data?.data?.deleteTransactionLog?.transactionsLog
  }
  
  const update = async (id,patch) => {
    setLoading()
    const res = await post('updateTranscationLog', { id,patch })
    await dispatch({
      type: UPDATE_TXN_LOG,
      payload: res?.data?.data?.updateTranscationLog?.transactionsLog
    })
    return res?.data?.data?.updateTranscationLog?.transactionsLog
  }
  const setLoading = () => dispatch({ type: SET_LOADING });
  return (
    <TxnContext.Provider
      value={{
        txnPending: state.txnPending,
        loadingTxn: state.loadingTxn,
        pageInfo: state.pageInfo,
        setLoading,
        getTxn,
        delete: _delete,
        update,
        add
      }}
    >
      {props.children}
    </TxnContext.Provider>
  );
};

export default TxnState;
