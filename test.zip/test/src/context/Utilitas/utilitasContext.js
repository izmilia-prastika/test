import { createContext } from 'react';

const utilitasContext = createContext();

export default utilitasContext;
