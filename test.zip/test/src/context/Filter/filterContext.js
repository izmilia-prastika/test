import { createContext } from 'react';

const filterContext = createContext();

export default filterContext;
