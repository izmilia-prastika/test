import {
  ADD_FILTER_CATEGORIES_ID,
  ADD_FILTER_COLLECTIONS_ID,
  REMOVE_FILTER_CATEGORIES_ID,
  REMOVE_FILTER_COLLECTIONS_ID,
  ADD_FILTER_STATUS_LISTING,
  REMOVE_FILTER_STATUS_LISTING,
  SET_FILTER_PRICE,
  SET_FILTER_SEARCH_ASSET,
  SET_FILTER_SORTED_BY,
  SET_FILTER_ACTIVITY_ASSET,
  SET_FILTER_SEARCH_COLLECTION,
  SET_FILTER_VERIFIED,
  ADD_FILTER_VERIFIED,
  REMOVE_FILTER_VERIFIED,
  GET_TOP_COLLECTIONS,
  GET_TOP_ASSETS,
  GET_TOP_ACCOUNTS,
  GET_SMART_SEARCH,
  SET_FILTER_SEARCH_TAG,
  SET_CATEGORY,
  SET_TYPE_TXN,
  RESET_FILTER,
} from '../types';

const reducer = (state, action) => {
  switch (action.type) {
    case RESET_FILTER:
      return {
        ...state,
        categoryIds: [],
        collectionIds: [],
        verifiedIds: [],
        statusType: [],
        priceRange: [0, 1000],
        tags: [],
        searchAsset: undefined,
        searchTag: "",
        sortedBy: null,
      }
    case ADD_FILTER_VERIFIED:
      return {
        ...state,
        verifiedIds: state.verifiedIds.concat(action.payload),
        loading: false
      };
    case REMOVE_FILTER_VERIFIED:
      return {
        ...state,
        verifiedIds: state.verifiedIds.filter((v) => v !== action.payload),
        loading: false
      };
    case ADD_FILTER_CATEGORIES_ID:
      return {
        ...state,
        categoryIds: state.categoryIds.concat(action.payload),
        loading: false
      };
    case REMOVE_FILTER_CATEGORIES_ID:
      return {
        ...state,
        categoryIds: state.categoryIds.filter((v) => v !== action.payload),
        loading: false
      };
    case ADD_FILTER_COLLECTIONS_ID:
      return {
        ...state,
        collectionIds: state.collectionIds.concat(action.payload),
        loading: false
      };
    case REMOVE_FILTER_COLLECTIONS_ID:
      return {
        ...state,
        collectionIds: state.collectionIds.filter((v) => v !== action.payload),
        loading: false
      };
    case ADD_FILTER_STATUS_LISTING:
      return {
        ...state,
        statusType: state.statusType.concat(action.payload),
        loading: false
      };
    case REMOVE_FILTER_STATUS_LISTING:
      return {
        ...state,
        statusType: state.statusType.filter((v) => v !== action.payload),
        loading: false
      };
    case SET_FILTER_PRICE:
      return {
        ...state,
        loading: false,
        priceRange: action.payload,

      }
    case SET_FILTER_SEARCH_ASSET:
      return {
        ...state,
        loading: false,
        searchAsset: action.payload,
        isTag: action?.isTag,
      }
    case SET_FILTER_SEARCH_TAG:
      return {
        ...state,
        loading: false,
        searchTag: action.payload
      }
    case GET_SMART_SEARCH:
      return {
        ...state,
        loading: false,
        topCollections: action?.payload?.collections?.map(({ _source }) => _source),
        topAssets: action?.payload?.assets?.map(({ _source }) => _source),
        topAccounts: action?.payload?.accounts?.map(({ _source }) => _source),
        topTags: action?.payload?.top_tags,
        tags: action?.payload?.tags?.map(({ _source }) => _source),
      }
    case SET_FILTER_SEARCH_COLLECTION:
      return {
        ...state,
        loading: false,
        searchCollection: action.payload
      }
    case SET_FILTER_VERIFIED:
      return {
        ...state,
        loading: false,
        isVerified: action.payload
      }
    case SET_FILTER_SORTED_BY:
      return {
        ...state,
        loading: false,
        sortedBy: action.payload
      }

    case SET_FILTER_ACTIVITY_ASSET:
      return {
        ...state,
        loading: false,
        activityType: action.payload
      }
    case GET_TOP_COLLECTIONS:
      return {
        ...state,
        loading: false,
        topCollections: action.payload
      }
    case GET_TOP_ASSETS:
      return {
        ...state,
        loading: false,
        topAssets: action.payload
      }
    case GET_TOP_ACCOUNTS:
      return {
        ...state,
        loading: false,
        topAccounts: action.payload
      }
    case SET_CATEGORY:
      return {
        ...state,
        categoryIds: action.payload ? [action.payload] : []
      }
    case SET_TYPE_TXN:
      return {
        ...state,
        typeTxn: action.payload
      }
    default:
      return state;
  }
};

export default reducer
