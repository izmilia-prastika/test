import { createContext } from 'react';

const authContext = createContext();

export default authContext;
