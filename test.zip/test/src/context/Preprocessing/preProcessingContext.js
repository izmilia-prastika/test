import { createContext } from 'react';

const preProcessingContext = createContext();

export default preProcessingContext;
