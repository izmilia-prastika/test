import { createContext } from 'react';

const web3ModalContext = createContext();

export default web3ModalContext;
