import { createContext } from 'react';

const ResponsiveContext = createContext();

export default ResponsiveContext;
