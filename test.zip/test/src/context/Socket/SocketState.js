import { useEffect, useReducer } from "react";
import SocketContext from "./socketContext";
import SocketReducer from "./socketReducer";
import {
  SET_LOADING,
  SET_MATIC_PRICE,
  ADD_BID_DATA,
} from "../types";
// import env from "../../config/env";
// import { NOTIFICATION_BUY, NOTIFICATION_MAKE_OFFER, NOTIFICATION_BID_AUCTION  } from "../../utils/constants/notificationTypes"
import api from "../../utils/api";

// const socket = io.connect(env.SOCKET_IO_URL, 
//   { 
//     path: env.DEV === "false" ? '/api/socket.io' : "/socket.io/",
//     transports: ['websocket', 'polling']
//   }
// )

const SocketState = (props) => {
  const initialState = {
    // socket,
    matic_price: 0,
    bid: new Map(),
    notification: [],
    loading: false,
  };

  const [state, dispatch] = useReducer(SocketReducer, initialState);

  // Set Loading
  const setLoading = () => dispatch({ type: SET_LOADING });

  const setMaticPrice = (newPrice) => {
    setLoading();
    dispatch({
      type: SET_MATIC_PRICE,
      payload: newPrice,
    });
  };

  const addBidData = (newBidData) => {
    setLoading();
    dispatch({
      type: ADD_BID_DATA,
      payload: newBidData,
    });
  };

  // const addNotificationData = (newNotificationData) => {
  //   setLoading();
  //   dispatch({
  //     type: ADD_NOTIFICATION_DATA,
  //     payload: newNotificationData,
  //   });
  // };

  const fetchMatic = async () => {
    const getMatic = await api.get("/matic_price")
    const newPrice = getMatic.data?.matic_price?.["matic-network"]?.idr
    console.log("zap getMatic", getMatic.data)
    setMaticPrice(newPrice)
  }

  useEffect(() => {
    // socket.on("matic_price", (data) => {
    //   const newPrice = JSON.parse(data);
    //   console.log("zap matic",newPrice)
    //   setMaticPrice(newPrice["matic-network"].idr);
    // });
    // socket.on("broadcastBid", (data) => {
    //   addBidData(data)
    // })
    /* eslint-disable */

    fetchMatic()
    
    const intervalId = setInterval(() => {
      fetchMatic()
      console.log("zap fetch matic")
    }, 60000)

    return () => clearInterval(intervalId)
  }, []);

  // useEffect(() => {
  //   socket.on("server_notification", (data) => {
  //     const userId =
  //       JSON.parse(window.localStorage.getItem("auth")).user?.id ?? null;
  //     if (userId) {
  //       if (userId === data?.accountId) {
  //         addNotificationData(data);
  //         const type =
  //           data.type && data.type === NOTIFICATION_BUY
  //             ? "Penjualan Berhasil"
  //             : data.type === NOTIFICATION_MAKE_OFFER
  //               ? "Penawaran Masuk"
  //               : data.type === NOTIFICATION_BID_AUCTION
  //               ? "Lelang Masuk"
  //               : ""
  //         const assetName = data?.assetName;
  //         const userName = data?.bidderName;
  //         const address = data?.bidderAccount;
  //         toast.info(
  //           `${type} untuk asset ${assetName} ${data.type === NOTIFICATION_MAKE_OFFER || data.type === NOTIFICATION_BID_AUCTION && data.bidderAccount
  //             ? `, dari ${userName !== null ? userName : `${address?.substring(0, 5)}...${address?.substring(address?.length - 4, address?.length)}`}`
  //             : ""
  //           }`,
  //           { autoClose: 10000 }
  //         );
  //       }
  //     }
  //   });
  //   return () => socket.off("server_notification");
  // }, [window.localStorage.getItem("auth")]);

  return (
    <SocketContext.Provider
      value={{
        // socket: state.socket,
        matic_price: state.matic_price,
        bid:state.bid,
        addBidData,
      }}
    >
      
      {props.children}
    </SocketContext.Provider>
  );
};

export default SocketState;
