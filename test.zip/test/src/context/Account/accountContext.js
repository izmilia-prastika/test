import { createContext } from 'react';

const accountContext = createContext();

export default accountContext;
