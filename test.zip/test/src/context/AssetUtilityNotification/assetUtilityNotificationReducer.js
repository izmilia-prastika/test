import {
  ALL_ASSET_UTILITY_NOTIFICATION,
  GET_ASSET_UTILITY_NOTIFICATION,
  SET_LOADING,
  UPDATE_ASSET_UTILITY_NOTIFICATION,
} from '../types';

const reducer = (state, action) => {
  switch (action.type) {
    case ALL_ASSET_UTILITY_NOTIFICATION:
      return {
        ...state,
        notifications: action.payload,
        // pageInfo: action.payload.pageInfo,
        loading: false
      };
      case GET_ASSET_UTILITY_NOTIFICATION:
        return {
          ...state,
          notification: action.payload,
          // pageInfo: action.payload.pageInfo,
          loading: false
        };
        case UPDATE_ASSET_UTILITY_NOTIFICATION:
          return {
            ...state,
            // pageInfo: action.payload.pageInfo,
            loading: false
          };
    case SET_LOADING:
      return {
        ...state,
        loading: true
      };
    default:
      return state;
  }
};

export default reducer
