import { createContext } from 'react';

const assetUtilityNotificationContext = createContext();

export default assetUtilityNotificationContext;
