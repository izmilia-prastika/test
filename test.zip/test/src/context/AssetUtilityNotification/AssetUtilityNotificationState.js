import React, { useReducer } from 'react';
import notificationContext from './assetUtilityNotificationContext';
import notificationReducer from './assetUtilityNotificationReducer';
// import { ALL_COLLECTION,SET_LOADING } from '../types';
import { post } from '../../utils/graphql-api';
import { SET_LOADING, ALL_ASSET_UTILITY_NOTIFICATION, UPDATE_ASSET_UTILITY_NOTIFICATION, GET_ASSET_UTILITY_NOTIFICATION, CONFIRM_ASSET_UTILITY_NOTIFICATION } from '../types';
import api from '../../utils/api';

const AssetUtilityNotificationState = props => {
  const initialState = {
    notifications: [],
    notification: {},
    totalCount: 0,
    pageInfo: {},
    loading: false
  };

  const [state, dispatch] = useReducer(notificationReducer, initialState);

   // get all  notification
   const getAll = async (params) => {
    setLoading();
      const res = await api.get("utilities/pooling_notification", { params });
      // console.log("TES", res)
      dispatch({
        type: GET_ASSET_UTILITY_NOTIFICATION,
        payload: res?.data?.assetUtilityNotification
      });
      return res?.data?.assetUtilityNotification
  };

   // get all  notification
   const confirm = async (body) => {
    setLoading();
      const res = await api.post("utilities/confirm_utility", { ...body });
      // console.log("TES", res)
      dispatch({
        type: CONFIRM_ASSET_UTILITY_NOTIFICATION,
        payload: res?.data
      });
      return res?.data
  };

  const update = async(id,patch) =>{
    setLoading();

    const res = await post("updateAssetsUtilitiesNotificationById", { id,patch });
    // console.log("TES", res)
    dispatch({
      type: UPDATE_ASSET_UTILITY_NOTIFICATION,
      payload: res?.data
    });
    return res?.data
  }

  // Set Loading
  const setLoading = () => dispatch({ type: SET_LOADING });
  return (
    <notificationContext.Provider
      value={{
        notifications: state.notifications,
        notification: state.notification,
        loading: state.loading,
        totalCount: state.totalCount,
        pageInfo: state.pageInfo,
        getAll,
        update,
        confirm,
      }}
    >
      {props.children}
    </notificationContext.Provider>
  );
};

export default AssetUtilityNotificationState;
