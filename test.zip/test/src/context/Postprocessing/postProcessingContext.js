import { createContext } from 'react';

const postProcessingContext = createContext();

export default postProcessingContext;
