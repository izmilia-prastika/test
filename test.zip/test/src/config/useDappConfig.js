import { ChainId, Config } from "@usedapp/core"

const useDappConfig: Config = {
    readOnlyChainId: ChainId.Mumbai,
    readOnlyUrls: {
        [ChainId.Mumbai]: 'https://polygon-mumbai.infura.io/v3/b001ea207b28421da1e48b5a0fd94f06',
    },
}

export default useDappConfig