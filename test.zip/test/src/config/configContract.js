
import env from "../config/env"

export const nftmarketaddress = env.NFT_MARKETPLACE_ADDRESS
export const nftaddress = env.NFT_ADDRESS
export const nftauctionaddress = env.NFT_AUCTION_ADDRESS
export const nftmultiaddress = env.NFT_MULTI_ADDRESS
export const bankAddres = env.BANK_ADDRESS


const relayLookupWindowBlocks = () => {
  if (env.NETWORK_NAME === "rinkeby") {
    return 1e5
  } else {
    return 990
  }
}

const relayRegistrationLookupBlocks = () => {
  if (env.NETWORK_NAME === "rinkeby") {
    return 1e5
  } else {
    return 990
  }
}

const pastEventsQueryMaxPageSize = () => {
  if (env.NETWORK_NAME === "rinkeby") {
    return 2e4
  } else {
    return 990
  }
}


export const paymasterConfig = {
  paymasterAddress: env.PAYMASTER_ADDRESS,
  relayLookupWindowBlocks: relayLookupWindowBlocks(),
  relayRegistrationLookupBlocks: relayRegistrationLookupBlocks(),
  pastEventsQueryMaxPageSize: pastEventsQueryMaxPageSize(),
  loggerConfiguration: {
    logLevel: 'error'
  }
}