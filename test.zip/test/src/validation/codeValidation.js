import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'

const schema = yup.object({
    codeField: yup.string().required('Kode tidak boleh kosong')
}).required();


const CodeValidation = yupResolver(schema)
export default CodeValidation