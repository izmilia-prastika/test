import "./App.scss"
import AuthState from "./context/Auth/AuthState";
import { ToastContainer } from "react-toastify";
import Web3ModalState from "./context/Web3Modal/Web3ModalState";
import 'react-loading-skeleton/dist/skeleton.css'
import Layout from "./container/Layout/Layout";
import RedeemState from "./context/Redeem/RedeemState";
import AccountState from "./context/Account/AccountState";

function App() {
  return (
    <Web3ModalState>
      <AccountState>
        <AuthState>
          <RedeemState>
            <ToastContainer />
            <Layout />
          </RedeemState>
        </AuthState>
      </AccountState>
    </Web3ModalState>
  );
}

export default App;
