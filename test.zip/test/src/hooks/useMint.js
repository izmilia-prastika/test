import axios from "axios";
import { useEffect, useState } from "react";
import env from "../config/env";

const { API_URL } = env

const useMint = ({ assetInput, activityMintInput, activityListInput }) => {
  const [categories, setCategories] = useState(null);
  const [collections, setCollections] = useState(null);

  useEffect(() => {
    async function fetchData() {
      const collectionData = await post("getAllCollections");
      const categoryData = await post("getAllCategories");
      setCategories(categoryData);
      setCollections(collectionData);
    }
    fetchData();
  }, []);

  const initialData = {
    categories,
    collections,
  };

  const post = (id, v) => {
    return axios.post(API_URL, { id, var: v });
  };

  const trigger = async () => {
    if (
      assetInput !== null &&
      activityMintInput !== null &&
      activityListInput !== null
    ) {
      const createAsset = await post("createAsset", { ...assetInput });
      const createMintActivity = await post("createAssetActivities", {
        assetId: createAsset.data.data.createAsset.asset.id,
        ...activityMintInput,
      });
      if (createAsset.data.data.createAsset.asset.isListed) {
        const createListActivity = await post("createAssetActivities", {
          assetId: createAsset.data.data.createAsset.asset.id,
          ...activityListInput,
        });
      }

      //   variables: {
      // createAsset({
      //     ...assetInput,
      //   },
      // }).then((payload) => {
      //   createAssetsActivity({
      //     variables: {
      //       assetId: payload.data.createAsset.asset.id,
      //       ...activityMintInput,
      //     },
      //   }).then(() => {
      //     if (payload.data.createAsset.asset.isListed)
      //       createAssetsActivity({
      //         variables: {
      //           assetId: payload.data.createAsset.asset.id,
      //           ...activityListInput,
      //         },
      //       });
      //   });
      // });
    }
  };

  return { initialData, trigger };
};

export default useMint;
