import { lazy } from 'react';
// import ActivePurchase from '../pages/ActivePurchase/ActivePurchase';
// import ExpiredPurchase from '../pages/ExpiredPurchase/ExpiredPurchase';
// import SuccessPurchase from '../pages/SuccessPurchase/SuccessPurchase';

// import LandingPage from '../pages/LandingPage/LandingPage'
// const LandingPage = lazy(() => import('../pages/LandingPage/LandingPage'));
const Dashboard = lazy(() => import('../pages/Dashboard/Dashboard'));


// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/home', name: 'Scan Asset', component: Dashboard/*  , layout: "" */ },
];

export default routes;
