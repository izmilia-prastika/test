import MarketPlaceIcon from "../assets/icon/marketplace_icon"
import ActivityIcon from "../assets/icon/activity_icon"
// import FaqIcon from "../assets/icon/faq_icon"
import ArticleIcon from "../assets/icon/article_icon"
import BecomePartnerIcon from "../assets/icon/become_partner_icon"

const nav = [
  
  {
    name: 'Marketplace',
    disabled:true,
    url: '/assets',
    collapse: true,
    icon: MarketPlaceIcon,
    children: [
      {
        name: 'Aset Ekslusif',
        url: '/asset-exclusive-partner',
      },
      {
        name: 'navigation.allAsset',
        url: '/assets',
      },
      {
        name: 'navigation.allCollection',
        url: '/collection',
      },
    ]
  },
  {
    name: 'Aktivitas',
    url: '/activity',
    icon : ActivityIcon,
  },
  {
    name: 'Mau Jadi Partner?',
    url: '/exclusive-partner',
    icon : BecomePartnerIcon,
  },
  // {
  //   name: 'FAQ',
  //   url: '/faq',
  //   icon : FaqIcon,
  // },
  // {
  //   name: 'Artikel',
  //   url: '/article',
  //   icon : ArticleIcon,
  // },
  {
    name: 'Informasi',
    disabled:true,
    url: '/',
    collapse: true,
    icon: ArticleIcon,
    children: [
      {
        name: 'Artikel',
        url: '/article',
      },
      {
        name: 'FAQ',
        url: '/faq',
      },
    ]
  },
]
export default nav