import { useContext, useEffect, useCallback } from "react"
import { IlusClaimEo } from "../../assets"
import MetamaskIcon from "../../assets/icon/metamask_icon"
import { useNavigate } from "react-router-dom";
import RoundedButton from "../../component/Button/RoundedButton"
import ButtonText from "../../component/Text/ButtonText"
import authContext from "../../context/Auth/authContext"
import web3ModalContext from "../../context/Web3Modal/web3ModalContext"
import Cookies from "js-cookie";
import accountContext from "../../context/Account/accountContext"
import { ethers } from "ethers";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
import env from "../../config/env";
import { intervalToDuration, isPast } from "date-fns"
import { toast } from "react-toastify";
import { ETHEREUM_RINKEBY, POLYGON_MAINNET, POLYGON_MUMBAI } from "../../utils/constants/metamaskConfig";

const LandingPage = () => {

  const navigate = useNavigate();
  const AuthContext = useContext(authContext);
  const AccountContext = useContext(accountContext);
  const responsive = useContext(ResponsiveContext)
  const { web3Modal, injectedProvider, setInjectedProvider, localChainId, setLocalChainId } = useContext(web3ModalContext)

  const {
    session,
    setSession,
    // metamaskLoading,
    setMetamaskLoading,
    // web3Connection,
    setWeb3Connection,
    // changeAccount,
    setChangeAccount,
    setChangeNetwork,
    setConnWallet,
    setWrongAccount
  } = AuthContext

  let usedChainId

  if (env.NETWORK_NAME === "polygon") {
    usedChainId = POLYGON_MAINNET.chainId
  } else if (env.NETWORK_NAME === "mumbai") {
    usedChainId = POLYGON_MUMBAI.chainId
  } else if (env.NETWORK_NAME === "rinkeby") {
    usedChainId = ETHEREUM_RINKEBY.chainId
  }

  useEffect(() => {
    if (Cookies.get("web3login") === "true") {
      console.log("zap keset web3login")
      setSession(true)
    }
    AccountContext.getAllAccounts();
    if (Cookies.get("unResponsiveMetamask") === "true") {
      console.log('zap connect');
      connect()
      Cookies.remove("unResponsiveMetamask")
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadWeb3Modal = useCallback(async () => {
    const connection = await web3Modal.connectTo("injected");
    const provider = new ethers.providers.Web3Provider(connection);
    setWeb3Connection(connection)
    setInjectedProvider(provider);
    const { chainId } = await provider.getNetwork();
    setLocalChainId(chainId);
    const signer = provider.getSigner();
    const userAddress = await signer.getAddress();
    const loggedAddress = JSON.parse(localStorage.getItem("auth"))?.user?.address
    // console.log("zap perbandingan userAddress", userAddress, JSON.parse(localStorage.getItem("auth"))?.user?.address)
    if (userAddress !== loggedAddress) {
      setWrongAccount(true)
    }
    connection.on("chainChanged", (chainId) => {
      setLocalChainId(parseInt(chainId));
      setInjectedProvider(new ethers.providers.Web3Provider(connection));
    });
    connection.on("accountsChanged", async (e) => {
      setChangeAccount(true)
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setInjectedProvider]);

  useEffect(() => {
    setMetamaskLoading(false)
    async function checkCache() {
      if (web3Modal.cachedProvider && session) {
        // setMetamaskLoading(true)
        console.log("zap check cache metamask")
        const provider = new ethers.providers.Web3Provider(window.ethereum)
        let unlocked
        try {
          console.log("zap masuk try block")
          const timeoutId = setTimeout(async () => {
            // toast.error("zap metamask is not responding")
            clearTimeout(timeoutId)
            await handleLogout()
          }, 15000)
          const accounts = await provider.listAccounts()
          unlocked = accounts.length > 0
          clearTimeout(timeoutId)
          setMetamaskLoading(false)
        } catch (error) {
          console.log("zap masuk error block")
          unlocked = false
        }
        if (unlocked) {
          await loadWeb3Modal()
        } else {
          // toast.error("Cookies logged in but metamask not unlocked")
          await handleLogout()
        }
      }
    }
    checkCache();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const logoutOfWeb3Modal = async () => {
    navigate('/')
    await web3Modal.clearCachedProvider();
    if (
      injectedProvider &&
      injectedProvider.provider &&
      typeof injectedProvider.provider.disconnect == "function"
    ) {
      await injectedProvider.provider.disconnect();
    }
    setTimeout(() => {
      window.location.reload();
    }, 1);
  };

  const constructMessageHash = (userAddress) => {
    const messageHash = ethers.utils.solidityKeccak256(
      ["string"],
      [`I want to login with ${userAddress}`]
    );
    return messageHash;
  };

  const connect = async () => {
    try {
      setMetamaskLoading(true)
      if (typeof window.ethereum !== "undefined") {
        const connection = await web3Modal.connectTo("injected");
        setWeb3Connection(connection)
        const provider = new ethers.providers.Web3Provider(connection);
        const { chainId } = await provider.getNetwork();
        setInjectedProvider(provider);
        const signer = provider.getSigner();
        const userAddress = await signer.getAddress();
        const messageHash = constructMessageHash(userAddress);
        const signature = await signer.signMessage(messageHash);
        const input = {
          signature,
          userAddress,
        };
        await AuthContext.login(input);
        Cookies.set("web3login", true);
        setSession(true)
        setConnWallet(false)
        setLocalChainId(chainId);
      } else {
        if (responsive && env.DEV === "false") {
          window.open(`https://metamask.app.link/dapp/${window.location.host}`, "_self")
        } else {
          const toastId = toast.error(
            <div>
              Install ekstension Metamask ke browser Anda terlebih dahulu. Petunjuknya ada di<p className="text-blue-500" onClick={() => {
                toast.dismiss(toastId)
                navigate("/faq")
              }}> sini</p>
            </div>, {
            closeButton: true,
            autoClose: false
          }
          )
        }
      }
      setMetamaskLoading(false)
    } catch (error) {
      console.log("error", error);
      if (error?.code === 4001) {
        setMetamaskLoading(false)
        // di reject signing nya
        await logoutOfWeb3Modal();
      }
    }
  };

  useEffect(() => {
    const refreshToken = () => {
      console.log("zap refreshtoken")
      const intervalId = setInterval(async () => {
        if (Cookies.get("web3login") === "true" && AuthContext?.auth?.user) {
          const interval = intervalToDuration({
            start: new Date(), end: new Date(AuthContext.auth.expiresAt)
          })
          // console.log(interval, isPast(new Date(AuthContext.auth.expiresAt)), "zap interval")
          if (isPast(new Date(AuthContext?.auth?.expiresAtRefreshToken))) {
            await handleLogout()
          }
          // console.log("zap interval layout header", intervalId, interval)
          if ((interval.minutes <= 2 && interval.hours === 0) || isPast(new Date(AuthContext.auth.expiresAt))) {
            await AuthContext.refreshToken()
            clearInterval(intervalId)
          }
        } else {
          // console.log("zap refreshtoken clearInterval")
          clearInterval(intervalId)
        }
      }, 1000)
    }
    refreshToken()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [AuthContext?.auth])

  useEffect(() => {
    console.log('zap chainId', localChainId, usedChainId);
    if ((Cookies.get("web3login") && localChainId !== null) && localChainId !== usedChainId) {
      setChangeNetwork(true)
    } else {
      setChangeNetwork(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localChainId])

  const handleLogout = async () => {
    await AuthContext.logout();
    Cookies.remove("web3login");
    setSession(false)
    await logoutOfWeb3Modal();
  }

  const handleLogin = async () => {
    await setConnWallet(true)
    console.log('TES')
  }
  return (
    <div className="flex flex-col md:flex-row justify-center fhd:px-32 px-6 items-center min-h-screen gap-y-0 xl:gap-x-4 fhd:gap-x-32">
      <img src={IlusClaimEo} alt='' className="md:h-auto w-auto md:mb-0 mb-6"/>
      <div className="flex flex-col items-center justify-center mt-4">
        <p className="font-quicksand font-semibold md:text-5xl text-lg tracking-tight text-hitam mb-2 md:mb-4">Selamat Datang di Scan Utilitas</p>
        <p className="font-quicksand font-semibold md:text-base text-sm tracking-tight text-abu mb-8">bagian dari nft saya</p>
        <RoundedButton onClick={handleLogin} className="gap-2 grid grid-flow-col px-6 py-4 cursor-pointer">
          <MetamaskIcon />
          <ButtonText tx="Masuk Dengan Metamask" />
        </RoundedButton>
      </div>
    </div>
  )
}

export default LandingPage