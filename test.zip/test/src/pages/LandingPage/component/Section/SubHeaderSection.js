import SectionTitleText from "../../../../component/Text/SectionTitleText";
import ContentInfo from "../Info/ContentInfo";

const SubHeaderSection = ({dataInfo,...props}) => <div {...props} className="flex flex-col items-center md:px-16 px:0 mb-44">
    <SectionTitleText tx="Buat dan jual aset digitalmu" classstyle="md:mb-20 mb-10 text-center sm:text-left" />

    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {dataInfo?.map((prop, i) => <ContentInfo key={i} {...prop} />)}
    </div>
</div>

export default SubHeaderSection