import { useNavigate } from "react-router-dom";
import { walletCollectionImage } from "../../../../assets";
import RoundedButton from "../../../../component/Button/RoundedButton";
import ButtonText from "../../../../component/Text/ButtonText";
import SectionTitleText from "../../../../component/Text/SectionTitleText";

const WalletOfferingSection = () => {
    const navigate = useNavigate()
    return (<div className="md:flex flex-col items-center px-44 hidden">
    <SectionTitleText tx="Mau beli aset tapi males pakai uang Kripto?" classstyle={"mb-14"} />
    <p className="font-quicksand font-normal tracking-wider text-xl text-hitam mb-4">Kamu mau beli aset tapi tidak mau membeli dengan uang kripto karena merepotkan?</p>
    <p className="font-quicksand font-normal tracking-wider text-xl text-center text-hitam mb-4">Kami menyediakan berbagai macam kanal pembayaran seperti Bank, e-Wallet, QRIS dan Retail Outlet yang bisa kamu pilih sesuai keinginanmu.</p>
    <p className="font-quicksand font-normal tracking-wider text-xl text-hitam mb-5">Yuk buruan cari yang kamu mau dan beli sekarang juga!</p>
    <img src={walletCollectionImage} className="mt-16" />
    <RoundedButton onClick={() => navigate('/assets')} className="px-10 mb-64 mt-12">
        <ButtonText classstyle="text-xl" tx="Beli Sekarang" />
    </RoundedButton>
</div>)
}
export default WalletOfferingSection