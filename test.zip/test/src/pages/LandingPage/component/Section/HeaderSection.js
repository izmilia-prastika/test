import classNames from "classnames"
import { useNavigate } from "react-router-dom"
import { HumanForm, LandingPageHeaderBackgroundImg, LandingPageHeaderPattern2Img, LandingPageHeaderPatternImg } from "../../../../assets"
import RoundedButton from "../../../../component/Button/RoundedButton"
import ButtonText from "../../../../component/Text/ButtonText"

const HeaderSection = ({ responsive, ...props }) => {
    const navigate = useNavigate()
    const classHeader = classNames("grid justify-items-center md:pt-48 py pt-24", { "grid-flow-col gap-36 pl-28 pr-36": !responsive }, { "grid-cols-1 gap-6 px-8": responsive })
    const classTitleHeader = classNames({ "landing-page-header-title-text mb-5": !responsive }, { "text-lg font-bold font-quicksand text-center": responsive })
    const classTitleInfo = classNames({ "landing-page-header-sub-title-text mb-16": !responsive }, { "text-sm font-quicksand text-center mt-4 mb-8 text-gray-600": responsive })
    return (
        <div {...props} className="md:mb-36 mb-20" style={{ backgroundImage: `url(${LandingPageHeaderPatternImg})` }}>
            <div style={{ backgroundImage: `url(${LandingPageHeaderBackgroundImg})` }}>
                <div className={classHeader} style={{ backgroundImage: `url(${LandingPageHeaderPattern2Img})` }}>
                    <div className="flex flex-col self-center tex md:order-1 order-2" style={{ width: responsive ? "100%" : "660px", }}>
                        <p className={classTitleHeader}>Jual dan beli aset digital terbaik di NFT Saya</p>
                        <p className={classTitleInfo}>NFT Saya mempersembahkan NFT marketplace terbaik dan terlengkap di Indonesia dari pembuat atau pekerja seni terbaik yang ada di Indonesia maupun Mancanegara</p>
                        <div className="flex flex-row md:px-0 px-2">
                            <RoundedButton onClick={() => navigate('/assets')} className="md:px-8 px-0 mr-3 md:py-5 py-3 md:w-auto w-full">
                                <ButtonText classstyle="md:text-xl text-sm md:font-bold font-semibold" tx="Telusuri" />
                            </RoundedButton>
                            <RoundedButton onClick={() => navigate('/create-asset')} color="transparent" className="border-hitam_2 border-2 md:px-8 px-0 md:py-5 py-3 md:w-auto w-full">
                                <ButtonText classstyle="md:text-xl text-sm md:font-bold font-semibold" color="hitam_2" tx="Buat Asset" />
                            </RoundedButton>
                        </div>
                    </div>
                    <div className="md:order-2 order-1 md:px-0 px-12">
                        <img src={HumanForm} alt="Human" />
                    </div>
                </div>
            </div>
        </div>)
}

export default HeaderSection