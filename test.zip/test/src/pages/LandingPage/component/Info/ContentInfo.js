import React from "react"

const ContentInfo = ({ img, title, content, ...prop }) => <div {...prop} className="flex flex-col items-center px-0 md:px-32 md:mb-0 mb-6">
    <img className="mb-8 w-3/12" src={img} />
    <p className="md:text-xl text-base text-hitam font-quicksand font-bold mb:mb-4 mb-2 text-center">{title}</p>
    <p className="md:text-base text-sm text-hitam font-quicksand font-normal text-center px-16 md:px-0">{content}</p>
</div>

export default ContentInfo