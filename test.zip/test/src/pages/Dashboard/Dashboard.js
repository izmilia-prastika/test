import { useEffect, useState} from 'react'
import { NFTSayaLogo } from '../../assets';
import { useContext } from 'react';
// import authContext from '../../context/Auth/authContext';
// import Cookies from "js-cookie";
import InputWithLabel from '../../component/Input/InputWithLabel';
import RoundedButton from '../../component/Button/RoundedButton';
import ButtonText from '../../component/Text/ButtonText';
import { QrReader } from 'react-qr-reader';
import TabPanel from '../../component/Panel/TabPanel';
import TabView from '../../component/Panel/TabView';
import redeemContext from '../../context/Redeem/redeemContext';
import ModalDoneScan from '../../component/Modal/ModalDoneScan';
import { useForm } from 'react-hook-form'
import CodeValidation from '../../validation/codeValidation';
// import web3ModalContext from '../../context/Web3Modal/web3ModalContext';
// import { useNavigate } from 'react-router-dom';

const TeksLogo = ({handleLogout}) => {
  return (
    <div className='absolute bottom-6 items-center flex flex-col w-full md:px-12 px-6'>
      <div className='flex gap-x-2'>
        <p className='font-quicksand text-sm text-hitam_2'>Bagian dari</p>
        <img src={NFTSayaLogo} alt='' className='h-6 w-auto' />
      </div>
      {/* <p onClick={handleLogout} className='mt-1 font-quicksand text-sm text-center text-red-500 font-extrabold cursor-pointer'>Logout</p> */}
    </div>
  )
}

const InputCodeContent = ({ handleSubmitBtn }) => {
  const [input, setinput] = useState('')
  const { register, handleSubmit, control, formState: { errors} } = useForm({
    resolver: CodeValidation
  })

  return (
    <div className='justify-center items-center mt-6 flex flex-col'>
      <form onSubmit={handleSubmit(handleSubmitBtn)} className="w-full">
        <InputWithLabel
          onChange={e => setinput(e.target.value)}
          name='codeField'
          placeholder="Masukkan kode utilitas"
          className="w-full mb-6"
          register={register}
          errors={errors}
          control={control} />
        <RoundedButton type="submit" className="py-4 px-6 w-full mb-12 hijau">
          <ButtonText>
            Klaim Tiket
          </ButtonText>
        </RoundedButton>
      </form>
    </div >
  )
}


export default function Dashboard() {

  // const navigate = useNavigate()
  // const AuthContext = useContext(authContext)
  // const { web3Modal, injectedProvider} = useContext(web3ModalContext)
  // const Responsive = useContext(ResponsiveContext)
  const Redeem = useContext(redeemContext)
  const { redeemCode, canRedeem, isMaxReached, resetCode } = Redeem
  // const { setSession } = AuthContext
  const [showModalDone, setShowModalDone] = useState(false);
  const [showModalFail, setShowModalFail] = useState(false);
  const [showMax, setShowMax] = useState(false)
  const [activeIndex, setactiveIndex] = useState(0)
  const videoStyle = { width: "320px", height: "256px" }
  const videoStyleContainter = {width:'320px', height: "256px", padding: '0px', overflow: 'hidden'}
  const cameraFacing = {facingMode : 'environment'}
  const styleQR = { width: '100%', height: '100%', overflow: 'hidden'}
  
  // const logoutOfWeb3Modal = async () => {
  //   navigate('/')
  //   await web3Modal.clearCachedProvider();
  //   if (
  //     injectedProvider &&
  //     injectedProvider.provider &&
  //     typeof injectedProvider.provider.disconnect == "function"
  //     ) {
  //       await injectedProvider.provider.disconnect();
  //     }
  //     setTimeout(() => {
  //       window.location.reload();
  //     }, 1);
  //   };

    // const handleLogout = async () => {
    //   await AuthContext.logout();
    //   Cookies.remove("web3login");
    //   setSession(false)
    //   await logoutOfWeb3Modal();
    // }

  const handleSubmitBtn = (data) => {
    redeemCode(data.codeField);
  }

  useEffect(() => {
    if (canRedeem) {
      setShowModalDone(true)
    } else if (canRedeem === false && isMaxReached === false) {
      setShowModalFail(true)
    } else if (canRedeem === false && isMaxReached === true) {
      // console.log('TES')
      setShowModalFail(true)
      setShowMax(true)
    }
  }, [canRedeem, isMaxReached])

  useEffect(() => {
    if (showModalDone === false || showModalFail === false) {
      resetCode()
    }
  }, [showModalDone, showModalFail])


  return (
    <div className={"bg-abut_mobile_bg min-h-screen overflow-x-hidden md:overflow-x-visible items-center justify-center flex"}>
      <div className='bg-white md:h-view_card h-screen w-full lg:w-2/5 xl:w-2/5 fhd:w-1/4 justify-start items-center flex flex-col md:px-12 px-6 py-8 rounded-md shadow-xl relative'>
        <p className='font-quicksand text-2xl font-extrabold mb-2'>Klaim Utilitas</p>
        <p className='font-quicksand text-sm md:text-base text-center text-hitam_2 font-regular mb-4'>Silahkan klaim utilitas Anda dengan scan kode QR atau input kode</p>
        {/* <img src={IlusClaimEo} alt='' className='w-48 h-auto mb-2' /> */}
        <TabView activeIndex={activeIndex}
          onTabChange={(e) => {
            setactiveIndex(e)
          }}
        >
          <TabPanel header="Scan Kode QR">
            <div className='flex justify-center items-center h-full flex-col mb-2'>
              <div className='w-64 h-64 overflow-hidden mt-6 mb-6'>
                <QrReader
                  scanDelay={1500}
                  videoStyle={videoStyle}
                  constraints={cameraFacing}
                  videoContainerStyle={videoStyleContainter}
                  onResult={(result, error) => {
                    if (!!result) {
                      redeemCode(result?.text);
                    }

                    if (!!error) {
                      console.info(error);
                    }
                  }}
                  style={styleQR}
                />
              </div>
              <div>
                <p className='font-quicksand mb-4 text-hitam_2 text-center'>Arahkan kode QR ke dalam kotak</p>
              </div>
            </div>
          </TabPanel>
          <TabPanel header="Masukkan Kode">
            <InputCodeContent handleSubmitBtn={handleSubmitBtn} />
          </TabPanel>
        </TabView>
      <TeksLogo/>
      </div>
      <ModalDoneScan backDrop={false} show={showModalDone} setShow={setShowModalDone} />
      <ModalDoneScan backDrop={false} show={showModalFail} setShow={setShowModalFail} status={false} isMaxReached={showMax} />
    </div>
  )
}
