import AuctionLogo from './auction'
import PriceTagLogo from './price_tag'
import CircleCrossLogo from './circle_cross'
import UserLogo from './userLogo'
import CircleChecklistLogo from './circle_checklist'
import HeartLogoImg from './heart_logo'
import EthLogoImg from './eth_logo'
import MagnifierLogoImg from "./magnifier_logo";
import CheckboxChecklistLogoImg from "./checkbox_checklist";
import CheckboxEmptyLogoImg from "./checkbox_empty";
import LelangImg from "./LelangImg.png";
import BuyImg from "./BuyImg.png";
import MetamaskLogo from './metamaskLogo.png';
import BankBcaLogo from './bankBca.png';
import BankBniLogo from './bankBni.png';
import BankBriLogo from './bankBri.png';
import BankSampoernaLogo from './bankSampoerna.png';
import BankPermataLogo from './bankPermata.png';
import BankMandiriLogo from './bankMandiri.png';
import BankCIMBLogo from './bankCIMB.png';
import WalletDanaLogo from './walletDana.png';
import WalletOvoLogo from './walletOvo.png';
import WalletLinkajaLogo from './walletLinkaja.png';
import WalletQrisLogo from './walletQris.png';
import WalletShopeePayLogo from './walletShopeePay.png';
import IdrLogo from './idr.png';
import CoinFiatRoundLogo from './coin_fiat_round.png';
import HandCoinRoundLogo from './hand_coin_round.png';
import StarCoinRoundLogo from './star_coin_round.png';
import TagRoundLogo from './tag_round.png';
import EntropLogo from './entrop_logo.png';
import NFTSayaLogo from './new_logo_big.webp'

export {
    AuctionLogo,
    HeartLogoImg,
    EthLogoImg,
    MagnifierLogoImg,
    PriceTagLogo,
    UserLogo,
    CircleCrossLogo,
    CircleChecklistLogo,
    CheckboxChecklistLogoImg,
    CheckboxEmptyLogoImg,
    IdrLogo,
    LelangImg,
    BuyImg,
    MetamaskLogo,
    BankBcaLogo,
    BankBniLogo,
    BankBriLogo,
    BankCIMBLogo,
    BankMandiriLogo,
    BankSampoernaLogo,
    BankPermataLogo,
    WalletLinkajaLogo,
    WalletDanaLogo,
    WalletOvoLogo,
    WalletQrisLogo,
    WalletShopeePayLogo,
    CoinFiatRoundLogo,
    HandCoinRoundLogo,
    StarCoinRoundLogo,
    TagRoundLogo,
    EntropLogo,
    NFTSayaLogo,
}