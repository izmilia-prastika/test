import React from "react";

const EthLogoImg = (props) =>
    <div {...props}>
        <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4.99965 0L4.89044 0.432953V12.9963L4.99965 13.1234L9.99931 9.67628L4.99965 0Z" fill="#343434" />
            <path d="M4.99966 0L0 9.67628L4.99966 13.1235V7.0256V0Z" fill="#8C8C8C" />
            <path d="M4.99965 14.2275L4.93811 14.315V18.7903L4.99965 19L10.0023 10.7821L4.99965 14.2275Z" fill="#3C3C3B" />
            <path d="M4.99966 19V14.2275L0 10.7821L4.99966 19Z" fill="#8C8C8C" />
            <path d="M4.99963 13.1234L9.99922 9.67631L4.99963 7.02563V13.1234Z" fill="#141414" />
            <path d="M0 9.67631L4.99959 13.1234V7.02563L0 9.67631Z" fill="#393939" />
        </svg>
    </div>


export default EthLogoImg