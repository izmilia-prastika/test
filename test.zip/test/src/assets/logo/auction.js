const AuctionLogo = ({ height = "63", width = "63", ...props }) =>
    <div {...props}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10.727 21.748V24H23.8262V21.748H10.727ZM10.0873 0L1.59684 8.75819L3.14036 10.3526L4.29746 9.95402L7.00135 12.7398L0.826172 19.1097L2.36969 20.7019L8.54378 14.332L11.168 17.0389L10.8591 18.3136L12.4037 19.9058L20.8941 11.1476L19.3495 9.55541L18.116 9.87295L11.2455 2.7869L11.6308 1.59332L10.0873 0Z" fill="white" />
        </svg>
    </div>

export default AuctionLogo