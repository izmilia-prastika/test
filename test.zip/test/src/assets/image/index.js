import UserImage from './image-square.png'
import UserImage2 from './image-square.png'
import UserImage3 from './image-square.png'
import EmptyState from './empty-state.png'
import DoneScan from './done.webp'
import FailScan from './cancel.webp'
import LoginIlus from './login-ilust.webp'
import IlusClaimEo from './ilus-claim-eo.webp'

export {
    DoneScan,
    FailScan,
    IlusClaimEo,
    EmptyState,
    UserImage,
    UserImage2,
    UserImage3,
    LoginIlus
}