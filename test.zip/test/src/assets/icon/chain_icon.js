import React from "react";

const ChainIcon = (props) => {
    return (
        <div {...props}>
            <svg width="22" height="15" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.70117 7.63159H13.3854" stroke="#33711F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M13.3867 1.94727H14.3341C15.8416 1.94727 17.2875 2.54614 18.3535 3.61214C19.4195 4.67815 20.0183 6.12396 20.0183 7.63151C20.0183 9.13907 19.4195 10.5849 18.3535 11.6509C17.2875 12.7169 15.8416 13.3158 14.3341 13.3158H13.3867" stroke="#33711F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M7.70194 13.3158H6.75456C5.24701 13.3158 3.80119 12.7169 2.73519 11.6509C1.66919 10.5849 1.07031 9.13907 1.07031 7.63151C1.07031 6.12396 1.66919 4.67815 2.73519 3.61214C3.80119 2.54614 5.24701 1.94727 6.75456 1.94727H7.70194" stroke="#33711F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}

export default ChainIcon