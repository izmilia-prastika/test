import React from "react";

const ChevronUpIcon = (props) => {
    return (
        <div {...props}>
            <svg width="10" height="5" viewBox="0 0 10 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 4L4.5 1L9 4" stroke="#676767" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}

export default ChevronUpIcon