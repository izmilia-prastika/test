import React from "react";

const FolderListIcon = ({viewBox, size, onClick, color, ...props}) => {
    return (
        <div onClick={onClick} {...props}>
           <svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M2.49992 14.8334H16.6666V16.5H2.49992C1.58325 16.5 0.833252 15.75 0.833252 14.8334V4.00002H2.49992V14.8334ZM19.1666 4.00002V11.5C19.1666 12.4167 18.4166 13.1667 17.4999 13.1667H5.83325C4.91658 13.1667 4.16658 12.4167 4.16658 11.5L4.17492 2.33335C4.17492 1.41669 4.91658 0.666687 5.83325 0.666687H9.99992L11.6666 2.33335H17.4999C18.4166 2.33335 19.1666 3.08335 19.1666 4.00002ZM5.83325 11.5H17.4999V4.00002H10.9749L9.30825 2.33335H5.83325V11.5Z" fill="#CCCCCC"/>
</svg>
        </div>
    )
}

FolderListIcon.defaultProps = {
    viewBox: 24,
    size: 6,
    onClick: ()=>{},
    color: "#868686",
}

export default FolderListIcon