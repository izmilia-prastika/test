import React from "react";

const LeftButtonIcon = ({width="50",height="50",...props}) => {
    return (
        <div {...props}>
            <svg width={width} height={height} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g filter="url(#filter0_d_400_3014)">
                    <circle cx="18" cy="17" r="14" fill="white" />
                </g>
                <path d="M20 11L15 17.2962L20 23" stroke="#868686" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <defs>
                    <filter id="filter0_d_400_3014" x="0" y="0" width="36" height="36" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
                        <feFlood floodOpacity="0" result="BackgroundImageFix" />
                        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                        <feOffset dy="1" />
                        <feGaussianBlur stdDeviation="2" />
                        <feComposite in2="hardAlpha" operator="out" />
                        <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.16 0" />
                        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_400_3014" />
                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_400_3014" result="shape" />
                    </filter>
                </defs>
            </svg>
        </div>
    )
}

export default LeftButtonIcon