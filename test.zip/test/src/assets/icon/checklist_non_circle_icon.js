import React from "react"

const ChecklistNonCircle = ({ color = "#4AA82D", ...props }) => {
    return (
        <div {...props}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M15 10L10.1875 14L8 12.1818" stroke="#4AA82D" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
</svg>

        </div>
    )
}

export default ChecklistNonCircle