import React from "react";

const KebabDotIcon = (props) => {
    return (
        <div {...props}>
            <svg width="8" height="22.5" viewBox="0 0 12 33" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                <rect width="12" height="33" fill="url(#pattern0)" />
                <defs>
                    <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                        <use xlinkHref="#image0_4431_8153" transform="translate(-0.916667) scale(0.0286458 0.0104167)" />
                    </pattern>
                    <image id="image0_4431_8153" width="96" height="96" xlinkHref="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAABmJLR0QA/wD/AP+gvaeTAAACq0lEQVR4nO3bvWtTcRTG8efc2KAk6JhiFVycbcS9k44F3zahBiGdrCh28K1cbBHEUsGK2k4BwUWqEDed9A/Q0FFwsKWokxRTrC3Jz8E3EDRc70nPufb5rG0OhxxSyg1fgIiINiuxXiCJ42enthWLraMBMgiEfQD6vv9oSYBGW6QuUXOuFserlnsmkZkDVMYmh9ohTAiwq8OvLkLkUu3q+fsbslhK7g9Qrc70rJeWbwdINdELBTP599tPz84Or3dpNRVbrBfoZK20fAtJ33wACBheK33qAXBKfys9OesF/qYyNjkEYCLFiHJ54NCbxotn81o7aXP7J+hkHG9Fq/AawO6Uo5ZWmrm9D2+e+6yxl7bIeoE/kVbhGNK/+QDQVyi2DivM6Qq3B/j2r6bWMMVZytweAAj71UZJKKvNUub4AOjVGhSAnVqztLk9QACC1iwB2lqztLk9gADvFMdpzlLl+QCvtGaFEF5qzdLm9gBtkbrWrCiKnmjN0ub2ABI15wAsKIx6W/yYf6QwpyvcHqAWx6sQuaww6uL09MgXhTld4fpZUOP50/n+gYO9gBz4xxF3auOj11WXUub2E/BD/sOOESDcS/q6ILi7J7dyphs7aXL7MO53lSs3TgTgGjo/H1oAcKE2PvpgA9ZKLTMHAH4+IT2CIIOQ0I9f344tAmiISD1EzcdZ+kqSiIiIiIiIiIiIaHPI1ONoFjKGWMgYYSFjjIWMIRYyhljIGGMhY4yFjDkWMtZYyFhiIWOMhYwxFjLGWMgYYyFjjIWMAyxkHGAh4wQLGQdYyBARERERERERERFlVaYeR7OQMcRCxggLGWMsZAyxkDHEQsYYCxljLGTMsZCxxkLGEgsZYyxkjLGQMcZCxhgLGWMsZBxgIeMACxknWMg4wEKGiIj+J18Bnk9o6EBFogAAAAAASUVORK5CYII=" />
                </defs>
            </svg>
        </div>
    )
}

export default KebabDotIcon