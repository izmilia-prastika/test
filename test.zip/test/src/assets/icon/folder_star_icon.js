import React from "react";

const FolderStarIcon = ({viewBox, size, onClick, color, ...props}) => {
    return (
        <div onClick={onClick} {...props}>
            <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M15.6667 1.99998H9.00008L7.33342 0.333313H2.33341C1.41675 0.333313 0.666748 1.08331 0.666748 1.99998V12C0.666748 12.9166 1.41675 13.6666 2.33341 13.6666H15.6667C16.5834 13.6666 17.3334 12.9166 17.3334 12V3.66665C17.3334 2.74998 16.5834 1.99998 15.6667 1.99998ZM15.6667 12H2.33341V1.99998H6.64175L8.30842 3.66665H15.6667V12ZM9.90008 8.69998L9.32508 11.1666L11.5001 9.89165L13.6751 11.1666L13.1001 8.69998L15.0167 7.04165L12.4917 6.82498L11.5001 4.49998L10.5084 6.82498L7.98341 7.04165L9.90008 8.69998Z" fill="#CCCCCC"/>
</svg>

        </div>
    )
}

FolderStarIcon.defaultProps = {
    viewBox: 24,
    size: 6,
    onClick: ()=>{},
    color: "#868686",
}

export default FolderStarIcon