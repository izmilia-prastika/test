import React from "react";

const GrayFacebookIcon = ({ fill = "#33711F", width = "20", height = "20", ...props }) => {
    return (
        <div {...props}>
            <svg width="28" height="26" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 0H2C0.9 0 0 0.8 0 1.77778V14.2222C0 15.2009 0.9 16 2 16H9V9.77778H7V7.57778H9V5.75556C9 3.832 10.212 2.48089 12.766 2.48089L14.569 2.48267V4.79822H13.372C12.378 4.79822 12 5.46133 12 6.07644V7.57867H14.568L14 9.77778H12V16H16C17.1 16 18 15.2009 18 14.2222V1.77778C18 0.8 17.1 0 16 0Z" fill="#C6C6C6" />
            </svg>
        </div>
    )
}

export default GrayFacebookIcon