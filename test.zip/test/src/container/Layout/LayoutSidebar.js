import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {navSidebar, navTxn} from '../../router/_nav_sidebar'

const LayoutSidebar = () => {
    const location = useLocation()
    const {pathname} = location
    const [pathActive, setPathActive] = useState()
    const isSetting = pathname.includes('setting') 
    const isTxn = pathname.includes('history-txn')
    const navigate = useNavigate()
    useEffect(() => {
        if(isSetting){
            setPathActive(pathname)
        } else if(isTxn) {
            setPathActive(pathname)
        }
    }, [pathname, isSetting, isTxn])
    const handleToUrl = (url, urlName) => {
        navigate(url)
        setPathActive(urlName)
    }
    const createLinks = (routes) => {
        return (<ul className="list-none pl-6">
            {routes?.map(({title, content, url, urlName, name},key) => {
                if (title) {
                    return (<li key={key}>
                        <p className='text-hitam text-base font-quicksand font-semibold pb-5'>
                            {title}
                        </p>
                        {createLinks(content)}
                    </li>)
                } else {
                    return (
                        <li key={key} className="pb-6 cursor-pointer" onClick={() => handleToUrl(url, urlName)}>
                            <p className={`${pathActive === urlName ? "text-hijau_hutan font-semibold" : "text-hitam font-normal"} text-sm font-quicksand`}>
                                {name}
                            </p>
                        </li>
                    )
                }

            })}
        </ul>)
    }
    return (
        <nav className="w-72 px-6 py-11 min-h-screen setting-sidebar-background">
            {createLinks(isSetting ? navSidebar : navTxn)}
        </nav >

    )
}

export default LayoutSidebar