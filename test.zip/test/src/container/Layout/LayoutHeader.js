/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useContext, useEffect, useState, useCallback } from "react";
import Cookies from "js-cookie";
import { intervalToDuration, isPast } from "date-fns"
import { useLocation, useNavigate } from "react-router-dom";
import Button from "../../component/Button/Button";
import ButtonText from "../../component/Text/ButtonText";
import navs from "../../router/_nav";
import authContext from "../../context/Auth/authContext";
import accountContext from "../../context/Account/accountContext";
import ResponsiveContext from "../../context/Responsive/responsiveContext";
// import SpinCircleLogo from "../../assets/animation/spin_circle_logo";
import { ethers } from "ethers";
import ButtonLink from "../../component/Button/ButtonLink";
import { NFTSayaLogo, UserLogo } from "../../assets";
import UserIcon from "../../assets/icon/user_icon";
import StarIcon from "../../assets/icon/star_icon";
import SettingIcon from "../../assets/icon/setting_icon";
import LogoutIcon from "../../assets/icon/logout_icon";
import BuyIcon from "../../assets/icon/buy_icon";
// import ChevronRightIcon from "../../assets/icon/checvron_right_icon";
import { toast } from "react-toastify";
import CloseIcon from "../../assets/icon/close_icon";
import HamburgerIcon from "../../assets/icon/hamburger_icon";
import ChevronDownIcon from "../../assets/icon/chevron_down_icon";
import classNames from "classnames";
import ChevronUpBlackIcon from "../../assets/icon/chevron_up_black_icon";
import InputSmartSearch from "../../component/Input/InputSmartSearch";
// import HeaderMobileContext from "../../context/HeaderMobile/HeaderMobileContext";
import web3ModalContext from "../../context/Web3Modal/web3ModalContext";

import { POLYGON_MAINNET, POLYGON_MUMBAI, ETHEREUM_RINKEBY } from "../../utils/constants/metamaskConfig"
import env from "../../config/env"
import txnContext from "../../context/Txn/txnContext";
import { TXN_STATUS_PENDING } from "../../utils/constants/transactionLogStatus";
import CopyIcon from "../../assets/icon/copy_icon";
import MobileMenu from "../../component/Header/MobileMenu";
import NotifHeader from "../../component/Header/NotifHeader";
import IconNotification from "../../component/Header/Notification/IconNotification";


// const ListMobileMenu = ({ icon: Icon, name, onClick }) => {
//   // const headerContext = useContext(HeaderMobileContext)  
//   return(
//   <div className="flex flex-row mb-4 items-center" onClick={() => { headerContext.setShowMenu(false); onClick() }}>
//     {Icon &&
//       <Icon color={"#676767"}/>
//     }
//     <button className="px-0" onClick={onClick}>{" "}
//       <ButtonText classstyle="ml-2 text-sm font-semibold text-hitam2 font-quicksand" color="text-black" tx={name} />
//     </button>
//   </div>
// )}

// const ListCollapsMobileMenu = ({ icon: Icon, name, children, url, navigate }) => {
//   const headerContext = useContext(HeaderMobileContext) 
//   const {showCollaps, setShowCollaps, setShowMenu, setActiveName, activeName} = headerContext
//   const handleToggle = () => {
//       setShowCollaps(!showCollaps);
//       if(activeName !== name){
//         setActiveName(name)
//       }
//   }
//   return (
//     <>
//       <div className="flex flex-row mb-4 items-center" onClick={handleToggle}>
//         <div className="flex w-full">
//           <Icon />
//           <button className="px-0">{" "}
//             <ButtonText classstyle="ml-2 text-sm font-semibold text-hitam2 font-quicksand" color="text-black" tx={name} />
//           </button>
//         </div>
//         {(showCollaps && activeName === name ? <ChevronUpBlackIcon /> : <ChevronDownIcon />)}
//       </div>
//       {(showCollaps && activeName === name) && children.map(({ name, url }, idx) =>
//         <div className="bg-white pb-2" key={idx}>
//           <ul className="mb-3">
//             <li className="bg-white mb-2 ml-2 px-6 block whitespace-no-wrap">
//               <button className="px-0" onClick={() => { setShowMenu(false); navigate(url) }}>
//                 <ButtonText classstyle="font-normal text-sm" color="text-hitam" tx={name} />
//               </button>
//             </li>
//           </ul>
//         </div>)}
//     </>
//   )
// }

// const Menu = ({ data, title, headerContext, navigate }) => {
//   return (
//     <div className="px-4">
//       <p className="font-quicksand text-base text-abu86 mt-100 py-6">{title}</p>
//       {data.map(({ icon, name, url, collapse, children, onClick }, idx) => {
//         if (collapse) {
//           return <ListCollapsMobileMenu 
//             icon={icon} 
//             name={name} 
//             key={idx} 
//             children={children}
//             url={url} 
//             headerContext={headerContext}
//             navigate={navigate}/>
//         }
//         return <ListMobileMenu 
//           icon={icon} 
//           name={name} 
//           onClick={!!url ? () => navigate(url) : onClick} 
//           key={idx} 
//           headerContext={headerContext}/>
//       })}
//     </div>
//   )
// }

const LayoutHeader = () => {
  const location = useLocation()
  const navigate = useNavigate();
  const AuthContext = useContext(authContext);
  const AccountContext = useContext(accountContext);
  const responsive = useContext(ResponsiveContext)
  // const headerContext = useContext(HeaderMobileContext)
  const TxnContext = useContext(txnContext)
  const {
    session,
    setSession,
    metamaskLoading,
    setMetamaskLoading,
    // web3Connection,
    setWeb3Connection,
    // changeAccount,
    setChangeAccount,
    setChangeNetwork,
    setConnWallet,
    setWrongAccount
  } = AuthContext
  // const [menuParam, setMenuParam] = useState(0)
  const { web3Modal, injectedProvider, setInjectedProvider, localChainId, setLocalChainId } = useContext(web3ModalContext)

  const [isShowDropdown, setIsShowDropdown] = useState(false);
  const [activeTab, setActiveTab] = useState("");
  const [isShowDropdownProfile, setIsShowDropdownProfile] = useState(false);
  const [showBanner, setShowBanner] = useState(false)
  const [showNotif, setShowNotif] = useState(false)
  const [showNotifMobile, setShowNotifMobile] = useState(false)
  const [isFiatBanner, setTypeBanner] = useState(false)
  // const { triggerBanner } = useContext(HeaderMobileContext)
  const copyAddress = async (text) => {
    await navigator.clipboard.writeText(text);
    toast('Alamat berhasil disalin', {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  }
  let usedChainId

  if (env.NETWORK_NAME === "polygon") {
    usedChainId = POLYGON_MAINNET.chainId
  } else if (env.NETWORK_NAME === "mumbai") {
    usedChainId = POLYGON_MUMBAI.chainId
  } else if (env.NETWORK_NAME === "rinkeby") {
    usedChainId = ETHEREUM_RINKEBY.chainId
  }

  useEffect(async () => {
    // console.log(triggerBanner, "TES")
    if (AuthContext?.auth?.user?.id !== undefined) {
      const fetchLogs = await TxnContext.getTxn({
        first: 5,
        after: null,
        assetId: null,
        status: TXN_STATUS_PENDING,
        type: null,
        accountId: AuthContext?.auth?.user?.id,
      })
      // console.log(fetchLogs, "TES")
      if (fetchLogs?.nodes?.length === 0) {
        setShowBanner(false)
      } else {
        setShowBanner(true)
        if (fetchLogs?.nodes[0]?.isFiat === true) {
          setTypeBanner(true)
        }
      }
    }
  }, [location.pathname, AuthContext?.auth?.user?.id,])


  useEffect(() => {
    if (Cookies.get("web3login") === "true") {
      console.log("zap keset web3login")
      setSession(true)
    }
    AccountContext.getAllAccounts();
    if (Cookies.get("unResponsiveMetamask") === "true") {
      connect()
      Cookies.remove("unResponsiveMetamask")
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadWeb3Modal = useCallback(async () => {
    const connection = await web3Modal.connectTo("injected");
    const provider = new ethers.providers.Web3Provider(connection);
    setWeb3Connection(connection)
    setInjectedProvider(provider);
    const { chainId } = await provider.getNetwork();
    setLocalChainId(chainId);
    const signer = provider.getSigner();
    const userAddress = await signer.getAddress();
    const loggedAddress = JSON.parse(localStorage.getItem("auth"))?.user?.address
    // console.log("zap perbandingan userAddress", userAddress, JSON.parse(localStorage.getItem("auth"))?.user?.address)
    if (userAddress !== loggedAddress) {
      setWrongAccount(true)
    }
    connection.on("chainChanged", (chainId) => {
      setLocalChainId(parseInt(chainId));
      setInjectedProvider(new ethers.providers.Web3Provider(connection));
    });
    connection.on("accountsChanged", async (e) => {
      setChangeAccount(true)
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setInjectedProvider]);

  useEffect(() => {
    async function checkCache() {
      if (web3Modal.cachedProvider && session) {
        setMetamaskLoading(true)
        console.log("zap check cache metamask")
        const provider = new ethers.providers.Web3Provider(window.ethereum)
        let unlocked
        try {
          console.log("zap masuk try block")
          const timeoutId = setTimeout(async () => {
            // toast.error("zap metamask is not responding")
            clearTimeout(timeoutId)
            await handleLogout()
          }, 15000)
          const accounts = await provider.listAccounts()
          unlocked = accounts.length > 0
          clearTimeout(timeoutId)
          setMetamaskLoading(false)
        } catch (error) {
          console.log("zap masuk error block")
          unlocked = false
        }
        if (unlocked) {
          await loadWeb3Modal()
        } else {
          // toast.error("Cookies logged in but metamask not unlocked")
          await handleLogout()
        }
      }
    }
    checkCache();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const logoutOfWeb3Modal = async () => {
    navigate('/')
    await web3Modal.clearCachedProvider();
    if (
      injectedProvider &&
      injectedProvider.provider &&
      typeof injectedProvider.provider.disconnect == "function"
    ) {
      await injectedProvider.provider.disconnect();
    }
    setTimeout(() => {
      window.location.reload();
    }, 1);
  };

  const constructMessageHash = (userAddress) => {
    const messageHash = ethers.utils.solidityKeccak256(
      ["string"],
      [`I want to login with ${userAddress}`]
    );
    return messageHash;
  };

  const connect = async () => {
    try {
      setMetamaskLoading(true)
      if (typeof window.ethereum !== "undefined") {
        const connection = await web3Modal.connectTo("injected");
        setWeb3Connection(connection)
        const provider = new ethers.providers.Web3Provider(connection);
        const { chainId } = await provider.getNetwork();
        setInjectedProvider(provider);
        const signer = provider.getSigner();
        const userAddress = await signer.getAddress();
        const messageHash = constructMessageHash(userAddress);
        const signature = await signer.signMessage(messageHash);
        const input = {
          signature,
          userAddress,
        };
        await AuthContext.login(input);
        Cookies.set("web3login", true);
        setSession(true)
        setConnWallet(false)
        setLocalChainId(chainId);
      } else {
        if (responsive && env.DEV === "false") {
          window.open(`https://metamask.app.link/dapp/${window.location.host}`, "_self")
        } else {
          const toastId = toast.error(
            <div>
              Install ekstension Metamask ke browser Anda terlebih dahulu. Petunjuknya ada di<p className="text-blue-500" onClick={() => {
                toast.dismiss(toastId)
                navigate("/faq")
              }}> sini</p>
            </div>, {
            closeButton: true,
            autoClose: false
          }
          )
        }
      }
      setMetamaskLoading(false)
    } catch (error) {
      console.log("error", error);
      if (error?.code === 4001) {
        setMetamaskLoading(false)
        // di reject signing nya
        await logoutOfWeb3Modal();
      }
    }
  };

  useEffect(() => {
    const refreshToken = () => {
      console.log("zap refreshtoken")
      const intervalId = setInterval(async () => {
        if (Cookies.get("web3login") === "true" && AuthContext?.auth?.user) {
          const interval = intervalToDuration({
            start: new Date(), end: new Date(AuthContext.auth.expiresAt)
          })
          // console.log(interval, isPast(new Date(AuthContext.auth.expiresAt)), "zap interval")
          if (isPast(new Date(AuthContext?.auth?.expiresAtRefreshToken))) {
            await handleLogout()
          }
          // console.log("zap interval layout header", intervalId, interval)
          if ((interval.minutes <= 2 && interval.hours === 0) || isPast(new Date(AuthContext.auth.expiresAt))) {
            await AuthContext.refreshToken()
            clearInterval(intervalId)
          }
        } else {
          // console.log("zap refreshtoken clearInterval")
          clearInterval(intervalId)
        }
      }, 1000)
    }
    refreshToken()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [AuthContext?.auth])

  useEffect(() => {
    if ((Cookies.get("web3login") && localChainId !== null) && localChainId !== usedChainId) {
      setChangeNetwork(true)
    } else {
      setChangeNetwork(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localChainId])

  const createLinks = (routes, isDropdown) => {
    return routes.map((prop, key) => {
      if (prop.invisible) return null;
      if (prop.redirect) {
        return null;
      }
      if (isDropdown) {
        return (
          <li key={key} className="bg-white hover:bg-gray-200 py-2 px-2 block whitespace-no-wrap">
            <button className="px-0" onClick={() => {
              navigate(prop.url);
              setIsShowDropdown(false);
            }}>
              <ButtonText classstyle="font-normal text-sm px-2" color="hitam" tx={prop.name} />
            </button>
          </li>
        )
      }
      if (prop.collapse) {
        return (
          <div key={key} className="inline-block self-center relative"
            onMouseEnter={() => {
              setIsShowDropdown(true);
              setActiveTab(prop.name)
            }}
            onMouseLeave={() => {
              setIsShowDropdown(false)
              setActiveTab("")
            }}
          >
            <button className="px-0" onClick={() => !prop?.disabled && navigate(prop?.url)}>
              <ButtonText classstyle="font-bold lg:text-sm fhd:text-base hover:text-hijau_hutan" color="hitam_2" tx={prop.name} />
            </button>
            {
              <div
                onMouseEnter={() => {
                  setIsShowDropdown(true);
                  setActiveTab(prop.name)
                }}
                onMouseLeave={() => {
                  setIsShowDropdown(false);
                  setActiveTab("")
                }}
                className={`absolute z-30 rounded-lg px-2 ${isShowDropdown && activeTab === prop.name ? 'block' : 'hidden'}`}>
                <ul className="rounded-lg py-3 w-44 dropdown-navigator-background ">
                  {createLinks(prop.children, true)}
                </ul>
              </div>
            }
          </div>
        );
      }
      return (
        <button key={key} className="px-0" onClick={() => navigate(prop.url)}>{" "}
          <ButtonText classstyle="font-bold lg:text-sm fhd:text-base hover:text-hijau_hutan" color="hitam_2" tx={prop.name} />
        </button>
      );
    });
  };

  // const handleMenuMobile = useCallback(() => {
  //   const { setShowMenu, setShowSubMenu, showMenu } = headerContext
  //   setShowMenu(!showMenu)
  //   setShowSubMenu(false)
  // }, [headerContext])

  // const handleSubMenuMobile = useCallback((param) => {
  //   const { setShowMenu, setShowSubMenu, showSubMenu, setSubMenuParam } = headerContext
  //   setShowSubMenu(!showSubMenu)
  //   setShowMenu(true)
  //   setSubMenuParam(param)
  // }, [headerContext])

  // const handleHome = useCallback(() => { headerContext.setShowMenu(false); navigate('/') }, [navigate, headerContext])

  const handleCreateAsset = useCallback(() => navigate("/create-asset"), [navigate])

  const handleProfile = useCallback(() => {
    navigate("/profile-page#created");
    setIsShowDropdownProfile(false);
  }, [navigate])

  const handleToCollection = useCallback(() => {
    navigate("/my-collection");
    setIsShowDropdownProfile(false);
  }, [navigate])

  const handleToSetting = useCallback(() => {
    navigate("/setting/profile");
    setIsShowDropdownProfile(false);
  }, [navigate])

  const handleToTxn = useCallback(() => {
    navigate("/history-txn/pending");
    setIsShowDropdownProfile(false);
  }, [navigate])

  const handleLogout = async () => {
    await AuthContext.logout();
    Cookies.remove("web3login");
    setSession(false)
    await logoutOfWeb3Modal();
  }

  const listMenuOnLogin = [
    {
      name: 'Profil',
      icon: UserIcon,
      onClick: handleProfile,
    },
    {
      name: 'Koleksi Saya',
      icon: StarIcon,
      onClick: handleToCollection,
    },
    {
      name: 'Sejarah Transaksi',
      icon: BuyIcon,
      onClick: handleToTxn,
    },
    {
      name: 'Pengaturan',
      icon: SettingIcon,
      onClick: handleToSetting,
    },
    {
      name: 'Keluar',
      icon: LogoutIcon,
      onClick: handleLogout,
    }
  ]

  const handleLogin = async () => {
    await setConnWallet(true)
  }

  const toggleNotif = (e) => {
    e.stopPropagation()
    setShowNotif(!showNotif)
  }
  const toggleNotifMobile = (e) => {
    e.stopPropagation()
    setShowNotifMobile(!showNotifMobile)
  }

  const ButtonLogin = () => {
    // const backgroundColor = classNames({
    //   "bg-hijau_hutan": headerContext.showMenu,
    //   "bg-white": !headerContext.showMenu,
    // })
    // const labelColor = classNames({
    //   "text-hijau_hutan": !headerContext.showMenu,
    //   "text-white": headerContext.showMenu,
    // })
    return (
      // <Button onClick={handleLogin} classstyle="px-0 md:py-0 py-3 w-full rounded-full" color={backgroundColor}>
      //   <div className="grid grid-flow-col gap-3 items-center">
      //     <ButtonText classstyle="font-quicksand md:text-base text-sm font-semibold" color={labelColor} tx="Akun" />
      //     {!headerContext.showMenu && <ChevronRightIcon color="#4AA82D" />}
      //   </div>
      // </Button>
      <ButtonLink classstyle="px-0" onClick={handleLogin}>
        <UserLogo />
      </ButtonLink>
    )
  }

  const ButtonLoginMobile = () => {
    return (
      <Button onClick={handleLogin} color="bg-white" classstyle="text-hijau_hutan border border-hijau_hutan rounded-full font-quicksand md:py-2 py-3 md:px-7 w-full border-solid">
        <ButtonText classstyle="md:text-base text-sm font-semibold" color="text-hijau_hutan" tx="Masuk" />
      </Button>
    )
  }

  const ButtonCreateAsset = () => {
    const handleClick = () => {
      // headerContext.setShowMenu(false);
      handleCreateAsset();
    }
    return (
      <Button onClick={handleClick} classstyle="text-white bg-hijau_hutan hover:bg-hijau_tua rounded-full font-quicksand md:py-2 py-3 md:px-7 lg:px-6 w-full hijau_mint border-solid border-2 border-hijau_hutan hover:border-hijau_tua">
        <ButtonText classstyle="md:text-base text-sm font-semibold" color={classNames("hijau_hutan")} tx="Buat Aset" />
      </Button>
    )
  }



  // const MetaMaskSpinner = () => (
  //   <Button classstyle="rounded-full font-quicksand md:py-2 py-3 md:px-7 w-full" color={classNames("bg-hijau_mint border-solid border-2 border-hijau_hutan")}>
  //     <div className="flex flex-row">
  //       <SpinCircleLogo />
  //       <ButtonText classstyle="md:text-base text-sm font-semibold" color={classNames("text-hijau_hutan")} tx="Loading" />
  //     </div>
  //   </Button>
  // )

  return (
    <div className="overflow-visible sticky inset-0 w-full z-40">
      <nav className="bg-white md:px-20 px-0 shadow-header z-40 md:h-20 md:py-0 py-2 flex flex-col md:relative w-full justify-center">
        <div className="md:flex md:justify-between md:items-center">
          <div className="flex flex-row-reverse items-center justify-end">
            <div className="cursor-pointer w-full md:ml-0 ml-20" >
              {/* <p className="font-poppins font-semibold md:text-xl text-lg text-hijau_misty text-center">
                Logo
              </p> */}
              <img alt="nft saya" src={NFTSayaLogo} className="w-32" />
            </div>
            <div className="flex md:hidden">
              {/* <button type="button" className="py-3 mx-3 text-gray-500 dark:text-gray-200 hover:text-gray-600 dark:hover:text-gray-400 focus:outline-none focus:text-gray-600 dark:focus:text-gray-400"
                aria-label="toggle menu"> {
                  !headerContext.showMenu ? <HamburgerIcon /> : <CloseIcon size={6} viewBox={24} />}
              </button> */}
            </div>
            <div className="absolute md:hidden right-4 top-4">
              <IconNotification
                show={showNotifMobile}
                handleClick={toggleNotifMobile}
                setShow={setShowNotifMobile}
                isMobile={true}
              />
            </div>
          </div>
          <div className="items-center md:flex hidden">
            <li className="bg-white py-2 lg:mr-8 2xl:mr-12 block whitespace-no-wrap">
              <InputSmartSearch />
            </li>
            <div className="grid grid-flow-col gap-4 items-center">
              <div className="border-gray-200 pr-6 h-12 items-center grid grid-flow-col gap-8 flex-row">
                {createLinks(navs)}
              </div>
              <ButtonCreateAsset />
              <IconNotification
                handleClick={toggleNotif}
                show={showNotif}
                setShow={setShowNotif}
              // data={[]}
              />
              {web3Modal?.cachedProvider && session && !metamaskLoading ? (
                <>
                  {AuthContext?.auth?.user && (
                    <>
                      <div
                        onMouseEnter={() => {
                          setIsShowDropdownProfile(true);
                        }}
                        onMouseLeave={() => {
                          setIsShowDropdownProfile(false)
                        }}
                        className="inline-block self-center relative px-0">
                        <div className="flex items-end justify-center mt-0 -mr-4">
                          <div className="flex flex-col items-center">
                            <ButtonLink classstyle="px-0 py-1" onClick={handleProfile}>
                              <UserLogo />
                            </ButtonLink>
                            <p className="text-xs font-quicksand text-hitam_2 font-semibold">{AuthContext?.auth?.user?.address.substr(0, 5) + "..." + AuthContext?.auth?.user?.address?.substr(AuthContext?.auth?.user?.address.length - 4)}</p>
                          </div>
                          <CopyIcon size={4} className="cursor-pointer ml-1" onClick={() => copyAddress(AuthContext?.auth?.user?.address)} />
                        </div>
                        <div className={`absolute z-30 right-2 rounded-lg ${isShowDropdownProfile ? 'block' : 'hidden'}`}
                          onMouseEnter={() => {
                            setIsShowDropdownProfile(true);
                          }}
                          onMouseLeave={() => {
                            setIsShowDropdownProfile(false)
                          }}>
                          <ul className="rounded-lg py-3 w-44 dropdown-navigator-background ">
                            {listMenuOnLogin.filter((el) => { return el.name !== 'Pembelian' && el.name !== 'Penjualan' }).map(({ name, onClick }, key) =>
                              <li key={key} className="bg-white hover:bg-gray-200 py-2 pl-2 pr-4 flex whitespace-no-wrap items-center justify-center">
                                <button
                                  className="md:mx-0 md:my-0 w-full"
                                  onClick={onClick}>
                                  <div className="flex flex-row items-center px-2">
                                    {/* <Icon className="mr-2" /> */}
                                    <ButtonText classstyle="font-normal text-sm" color="hitam" text={name} />
                                  </div>
                                </button>
                              </li>)}
                          </ul>
                        </div>
                      </div>
                    </>
                  )}
                </>
              ) :
                <ButtonLogin />
              }
            </div>
          </div>
        </div>
      </nav>
      <MobileMenu
        AuthContext={AuthContext}
        ButtonCreateAsset={ButtonCreateAsset}
        ButtonLogin={ButtonLoginMobile}
      // Menu={Menu}
      // listMenuOnLogin={listMenuOnLogin}
      // toggleMenu={headerContext.showMenu}
      // setToggle={handleMenuMobile}
      // showSub={headerContext.showSubMenu}
      // setShowSub={handleSubMenuMobile}
      // menuParam={headerContext.subMenuParam}
      // headerContext={headerContext}
      // navigate={navigate}
      />
      <NotifHeader
        navigate={navigate}
        show={showBanner}
        setShow={setShowBanner}
        location={location}
        isFiat={isFiatBanner}
      />
    </div>
  );
};

export default LayoutHeader;
